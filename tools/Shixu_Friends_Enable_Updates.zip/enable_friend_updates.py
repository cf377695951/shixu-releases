"""One-time activation for an existing friend install. Never copies owner credentials."""
from pathlib import Path
import importlib.util,json,os,re,sys,time,subprocess
PUBLIC_CONFIG={'schema': 1, 'enabled': True, 'transport': 'https', 'manifest_url': 'https://raw.githubusercontent.com/cf377695951/shixu-releases/main/updates/stable.json', 'trusted_https_origins': ['https://raw.githubusercontent.com'], 'public_keys': {'shixu-public-20261029': {'n': '9cd12338ec818d18261e54703c99da6477a30a065324eb1749d241dd00ea14193470c605c909b3ddc099d53ed9f3d6b957f27ba72e2ac6b84c815d5d0c83ef02ea7670762fda72fe82940b090b4b3b925363c24d74e2b655b7b416245f78c576390b8be431c7b9bcea802d4b1d562d75dc8613745277c56735c48f9b981ca95b83c35e3b032cd3ac6b623b9b86d4ea84f30cb9d0cb6768cf0b3b4899c286dd6fd6325197518bb501af56b28f2aecf107766515735f9e8e4ccda3248011381a7289361dd97ccafaabd16c4893d85b92129649dac8b93c293a994f45a9833f9d1238783d6e09b3bb96a2822671fcb61261bdac30a7812c7e6ceffa0b45260b7333ef09ddb18fa58cc20efe1e09ebe0f904b00140d5d77eab1d36cf9db04b157a33fdf2681b85da4ba069425f943d1b48b8d10031421b66ac26bc9c6810e63501cc13059e83da5d85c8b5378fa7a566665de80b78d5dedf2abdabd0e89871b600f6a691597a517da6e8410464406725ee0334a99217944048adc0376ea331e38925', 'e': 65537}}, 'check_interval_seconds': 1800, 'channel_name': '朋友公开发行通道', 'note': '无需GitHub账户、Git或付费Token。HTTPS固定来源，RSA-SHA256签名及文件摘要校验；程序更新与公开金融数据联网刷新独立运行。'}
def enable(root=None,*,fetcher=None,stopper=None,launcher=None):
 root=Path(root or(Path(os.environ.get('LOCALAPPDATA',''))/'Willance'/'EventCalendarV1')).resolve()
 if not(root/'app.py').is_file()or not(root/'desktop/updater.py').is_file():raise RuntimeError('未找到已安装的时序；请先完整安装朋友版。')
 text=(root/'app.py').read_text(encoding='utf-8-sig');m=re.search(r"^VERSION\s*=\s*['\"](\d+\.\d+\.\d+)['\"]",text,re.M)
 if not m:raise RuntimeError('现有版本无法识别，原程序未改动。')
 path=root/'desktop/update_config.json'
 try:previous=json.loads(path.read_text(encoding='utf-8'))
 except FileNotFoundError:previous={}
 if previous.get('enabled')and previous.get('manifest_url')!=PUBLIC_CONFIG['manifest_url']:raise RuntimeError('此电脑已有其他更新通道，已保留。该工具仅供朋友版使用。')
 spec=importlib.util.spec_from_file_location('shixu_friend_bootstrap_updater',root/'desktop/updater.py');updater=importlib.util.module_from_spec(spec);sys.modules[spec.name]=updater;spec.loader.exec_module(updater)
 config_path=Path(__file__).resolve().with_name('PUBLIC_UPDATE_CONFIG.json')
 config_path.write_text(json.dumps(PUBLIC_CONFIG,ensure_ascii=False,indent=2),encoding='utf-8')
 manager=updater.UpdateManager(root,m[1],config_path=config_path,fetcher=fetcher)
 print('正在从时序公开发行通道读取并校验新版，请稍候…',flush=True)
 status=manager.check_and_download()
 if status.get('status')not in('ready','current'):raise RuntimeError(status.get('message')or'暂时无法下载更新，旧版和原更新配置已保留。')
 if stopper:stopper(root)
 else:
  sys.path.insert(0,str(root))
  from desktop.launcher import stop_server,runtime_dir,read_running
  ready=runtime_dir()/'ready.json';stop_server(ready);deadline=time.monotonic()+8
  while read_running(ready)and time.monotonic()<deadline:time.sleep(.1)
  if read_running(ready):raise RuntimeError('时序尚未退出；请点“退出应用”后重试。原更新配置已保留。')
 backup=root/'data/friend-channel-backups'/time.strftime('%Y%m%d-%H%M%S');backup.mkdir(parents=True,exist_ok=True)
 if path.exists():(backup/'update_config.json').write_bytes(path.read_bytes())
 updater.atomic_json(path,PUBLIC_CONFIG)
 print('更新已校验，朋友自动更新已启用。重新打开时序后新版生效。',flush=True)
 if launcher:launcher(root)
 elif os.name=='nt':
  python=root/'runtime/pythonw.exe'
  if not python.is_file():python=root/'runtime/python.exe'
  subprocess.Popen([str(python),str(root/'desktop/launcher.py')],cwd=root,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 return status
if __name__=='__main__':
 try:enable()
 except Exception as error:print('未完成：'+str(error),flush=True);sys.exit(1)
