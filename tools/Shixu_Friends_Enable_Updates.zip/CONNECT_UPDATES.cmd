@echo off
chcp 65001 >nul
set "SHIXU_UPGRADE_PY=%LOCALAPPDATA%\Willance\EventCalendarV1\runtime\python.exe"
if not exist "%SHIXU_UPGRADE_PY%" (
  echo 未找到已安装的时序，请先完整安装朋友版。
  pause
  exit /b 2
)
"%SHIXU_UPGRADE_PY%" "%~dp0enable_friend_updates.py"
if errorlevel 1 (
  echo 升级未完成，原程序可以继续使用。
  pause
  exit /b 1
)
pause
