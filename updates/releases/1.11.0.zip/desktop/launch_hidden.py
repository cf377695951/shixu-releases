"""Re-launch with pythonw on Windows, keeping the service console hidden."""
from pathlib import Path
import os
import subprocess
import sys

launcher = Path(__file__).resolve().with_name("launcher.py")
bundled = launcher.parent.parent / "runtime" / "pythonw.exe"
python = bundled if os.name == "nt" and bundled.is_file() else Path(sys.executable)
hidden = python.with_name("pythonw.exe") if os.name == "nt" else python
if not hidden.is_file():
    hidden = python
flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
subprocess.Popen([str(hidden), str(launcher), *sys.argv[1:]],
                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                 stderr=subprocess.DEVNULL, creationflags=flags)
