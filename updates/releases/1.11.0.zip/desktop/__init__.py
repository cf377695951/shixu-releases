"""Desktop launch and installation helpers for the investment calendar."""
