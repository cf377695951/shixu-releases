"""Signed, application-only updates; standard library and the user's existing Git.

A background check only downloads into .updates. The launcher may call
apply_pending() only after the owned calendar service has stopped. No scheduler,
credential storage, browser extension or original backup checkout is changed.
"""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import threading
import time
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
import uuid
import zipfile

APP_ID = 'willance-event-calendar'
MAX_MANIFEST = 2_000_000
MAX_PACKAGE = 40_000_000
MAX_EXPANDED = 100_000_000
MAX_FILES = 4096
ROOT_FILES = {
    'app.py', 'providers.py', 'timing_policy.py', 'ir_policy.py',
    'retention_policy.py', 'selection_policy.py', 'quotes.py', 'quote_service.py',
    'ipo.py', 'logos.py', 'additional_sources.py', 'hk_earnings.py',
    'ir_overrides.json', 'seed_verified.json', 'DATA_ACCURACY.md',
    'README_WINDOWS.md', 'START_WINDOWS.cmd', 'INSTALL_WINDOWS.cmd',
    'INSTALL_WINDOWS.ps1',
}
DESKTOP_FILES = {'__init__.py', 'launcher.py', 'launch_hidden.py', 'frozen_entry.py',
                 'install.py', 'updater.py', 'update_config.json'}


class UpdateError(Exception):
    """A non-sensitive, UI-safe update failure."""


def version(value: str) -> tuple[int, int, int]:
    if not isinstance(value, str) or not re.fullmatch(r'\d{1,5}\.\d{1,5}\.\d{1,5}', value):
        raise UpdateError('更新版本号无效')
    return tuple(map(int, value.split('.')))


def canonical_manifest(manifest: dict) -> bytes:
    return json.dumps({k: v for k, v in manifest.items() if k != 'signature'},
                      ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                      allow_nan=False).encode('utf-8')


def verify_signature(manifest: dict, keys: dict) -> None:
    """Strict EMSA-PKCS1-v1_5 SHA256 verification; no optional dependencies."""
    try:
        key = keys[manifest['key_id']]
        modulus = int(key['n'], 16)
        exponent = int(key.get('e', 65537))
        size = (modulus.bit_length() + 7) // 8
        if modulus.bit_length() < 2048 or exponent != 65537:
            raise ValueError()
        signature = base64.b64decode(manifest['signature'], validate=True)
        if len(signature) != size or int.from_bytes(signature, 'big') >= modulus:
            raise ValueError()
        encoded = pow(int.from_bytes(signature, 'big'), exponent, modulus).to_bytes(size, 'big')
        digest_info = bytes.fromhex('3031300d060960864801650304020105000420') + hashlib.sha256(canonical_manifest(manifest)).digest()
        padding = size - len(digest_info) - 3
        expected = b'\x00\x01' + b'\xff' * padding + b'\x00' + digest_info
        if padding < 8 or encoded != expected:
            raise ValueError()
    except (KeyError, TypeError, ValueError, OverflowError):
        raise UpdateError('更新签名校验失败，已拒绝安装') from None


def safe_path(value: str) -> str:
    if not isinstance(value, str) or not value or '\\' in value or '\x00' in value:
        raise UpdateError('更新文件路径无效')
    path = PurePosixPath(value)
    if path.is_absolute() or any(p in ('', '.', '..') or p != p.rstrip(' .') or re.fullmatch(r'(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', p) for p in value.split('/')) or ':' in value:
        raise UpdateError('更新文件路径越界')
    if value in ROOT_FILES:
        return value
    if len(path.parts) == 2 and path.parts[0] == 'desktop' and path.name in DESKTOP_FILES:
        return value
    if len(path.parts) >= 2 and path.parts[0] == 'web' and path.suffix.lower() in {'.html', '.css', '.js', '.svg', '.png', '.ico', '.woff2'}:
        return value
    if len(path.parts) >= 2 and path.parts[0] == 'branding' and path.suffix.lower() in {'.json', '.svg', '.png', '.jpg', '.jpeg', '.webp', '.ico'}:
        return value
    raise UpdateError('更新包包含不允许修改的文件')


def validate_manifest(manifest: dict, config: dict) -> None:
    if not isinstance(manifest, dict) or manifest.get('schema') != 1 or manifest.get('app') != APP_ID:
        raise UpdateError('更新清单格式无效')
    git_trust = config.get('transport') == 'git' and config.get('trust') == 'authenticated_git'
    if git_trust:
        if manifest.get('integrity') != 'authenticated_git':
            raise UpdateError('更新清单与仓库信任模式不匹配')
        _repo_identity(config.get('git', {}).get('repository', ''))
    else:
        verify_signature(manifest, config.get('public_keys', {}))
    version(manifest.get('version'))
    files = manifest.get('files')
    if not isinstance(files, dict) or not 1 <= len(files) <= MAX_FILES:
        raise UpdateError('更新清单文件数无效')
    if len({name.casefold() for name in files}) != len(files):
        raise UpdateError('更新清单存在 Windows 文件名冲突')
    total = 0
    for name, metadata in files.items():
        safe_path(name)
        if not isinstance(metadata, dict) or type(metadata.get('size')) is not int or metadata['size'] < 0:
            raise UpdateError('更新文件大小无效')
        if not re.fullmatch('[0-9a-f]{64}', str(metadata.get('sha256', ''))):
            raise UpdateError('更新文件摘要无效')
        total += metadata['size']
    if total > MAX_EXPANDED:
        raise UpdateError('更新包展开后过大')
    required = manifest.get('base_files', {})
    if not isinstance(required, dict) or len(required) > MAX_FILES:
        raise UpdateError('增量更新基础清单无效')
    if len({name.casefold() for name in required}) != len(required):
        raise UpdateError('增量更新基础清单存在Windows文件名冲突')
    for name, metadata in required.items():
        safe_path(name)
        if not name.startswith('branding/') or name.casefold() in {item.casefold() for item in files}:
            raise UpdateError('增量更新基础路径无效')
        if not isinstance(metadata, dict) or type(metadata.get('size')) is not int or metadata['size'] < 0:
            raise UpdateError('增量更新基础大小无效')
        if not re.fullmatch('[0-9a-f]{64}', str(metadata.get('sha256', ''))):
            raise UpdateError('增量更新基础摘要无效')
    if 'minimum_version' in manifest:
        version(manifest['minimum_version'])
    deleted = manifest.get('delete', [])
    if not isinstance(deleted, list) or len(deleted) > MAX_FILES or not all(isinstance(name, str) for name in deleted):
        raise UpdateError('更新清单删除列表无效')
    if len({name.casefold() for name in deleted}) != len(deleted):
        raise UpdateError('更新删除列表存在 Windows 文件名冲突')
    for name in deleted:
        safe_path(name)
        if name.casefold() in {item.casefold() for item in files}:
            raise UpdateError('更新清单文件操作冲突')
    package = manifest.get('package')
    if not isinstance(package, dict) or type(package.get('size')) is not int or not 1 <= package['size'] <= MAX_PACKAGE:
        raise UpdateError('更新包大小无效')
    if not re.fullmatch('[0-9a-f]{64}', str(package.get('sha256', ''))):
        raise UpdateError('更新包摘要无效')
    if git_trust:
        prefix = config.get('git', {}).get('release_prefix', 'app-updates/event-calendar/releases')
        if package.get('path') != prefix + '/' + manifest['version'] + '.zip':
            raise UpdateError('更新包不在固定发布目录内')


def verify_base_files(root: Path, files: dict) -> None:
    """A delta never silently relies on missing or changed legacy assets."""
    root = Path(root).resolve()
    if not isinstance(files, dict) or len(files) > MAX_FILES:
        raise UpdateError('增量更新基础清单无效')
    for name, metadata in files.items():
        safe_path(name)
        if not name.startswith('branding/') or not isinstance(metadata, dict):
            raise UpdateError('增量更新基础路径无效')
        target = root / name
        current = target
        while current != root:
            if current.is_symlink() or getattr(current, 'is_junction', lambda: False)():
                raise UpdateError('增量更新基础不能使用符号链接')
            current = current.parent
        try:
            if not target.is_file() or target.stat().st_size != metadata['size'] or hashlib.sha256(target.read_bytes()).hexdigest() != metadata['sha256']:
                raise UpdateError('增量更新需要完整V1.4图标资源；保留当前版本，请先修复基础安装')
        except (OSError, KeyError, TypeError):
            raise UpdateError('增量更新基础资源未就绪，保留当前版本') from None


def verify_installed_baseline(root: Path) -> None:
    """Startup guard also protects updates applied by the older V1.4 updater.

    Development checkouts and complete releases have no delta guard file.
    A distributed delta always installs this whitelisted, hashed JSON file.
    """
    path = Path(root) / 'branding' / 'update-base-v15.json'
    if not path.exists():
        return
    if path.is_symlink() or path.stat().st_size > MAX_MANIFEST:
        raise UpdateError('增量更新启动校验文件无效')
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        if value.get('schema') != 1:
            raise ValueError()
        files = value['files']
    except (ValueError, KeyError, TypeError, OSError):
        raise UpdateError('增量更新启动校验文件无效') from None
    verify_base_files(root, files)


def verify_update_requirements(root: Path, current_version: str, manifest: dict) -> None:
    minimum = manifest.get('minimum_version')
    if minimum and version(current_version) < version(minimum):
        raise UpdateError('此增量更新需要V' + minimum + '或更高基础版本，保留当前版本')
    verify_base_files(root, manifest.get('base_files', {}))


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(temp, path)


def _repo_identity(url: str) -> str:
    if url.startswith('git@github.com:'):
        value = url[len('git@github.com:'):]
    else:
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or parsed.hostname != 'github.com' or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise UpdateError('更新仓库地址不符合配置')
        value = parsed.path.lstrip('/')
    value = value.removesuffix('.git').strip('/')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', value):
        raise UpdateError('更新仓库地址无效')
    return value.lower()


class _NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise UpdateError('更新源发生未授权跳转')


class UpdateManager:
    def __init__(self, root: Path, current_version: str, config_path: Path | None = None, *, fetcher=None):
        self.root = Path(root).resolve()
        self.current_version = current_version
        version(current_version)
        self.directory = self.root / '.updates'
        if self.directory.is_symlink() or getattr(self.directory, 'is_junction', lambda: False)():
            raise UpdateError('更新目录不能使用符号链接或目录联接')
        self.config_path = config_path or self.root / 'desktop' / 'update_config.json'
        try:
            self.config = json.loads(self.config_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            self.config = {'enabled': False}
        self._lock = threading.RLock()
        self._thread = None
        self._fetcher = fetcher
        self._git_base = None
        self._git_commit = None
        self._state = {'state': 'idle' if self.config.get('enabled') else 'unconfigured',
                       'current_version': current_version, 'message': '尚未检查更新',
                       'ready_version': None, 'last_checked_at': None}
        try:
            saved = json.loads((self.directory / 'status.json').read_text(encoding='utf-8'))
            for key in ('last_checked_at', 'ready_version', 'message'):
                self._state[key] = saved.get(key)
            if self._pending().exists():
                manifest = json.loads(self._pending().read_text(encoding='utf-8'))
                validate_manifest(manifest, self.config)
                if version(manifest['version']) > version(current_version):
                    self._state.update(state='ready', ready_version=manifest['version'], message='新版已下载，将在下次启动时更新')
        except (OSError, ValueError, TypeError, UpdateError):
            pass

        _history_archive(self)

    def _pending(self) -> Path:
        return self.directory / 'pending.json'

    def status(self) -> dict:
        with self._lock:
            result = dict(self._state)
            result.update(status=result['state'], latest_version=result.get('ready_version') or self.current_version,
                          error=result.get('message') if result['state'] == 'error' else None,
                          checked_at=datetime.fromtimestamp(result['last_checked_at'], timezone.utc).isoformat() if result.get('last_checked_at') else None)
            return result

    def _set(self, **values):
        with self._lock:
            self._state.update(values)
            atomic_json(self.directory / 'status.json', self._state)

    def start_background(self, force: bool = False) -> bool:
        with self._lock:
            if self.config.get('updates_paused') and not force:return False
            if force and self.config.get('updates_paused'):
                self.config.pop('updates_paused',None);atomic_json(self.config_path,self.config)
            if not self.config.get('enabled') or self._thread and self._thread.is_alive():
                return False
            last = self._state.get('last_checked_at') or 0
            if not force and time.time() - last < max(300, min(1800,self.config.get('check_interval_seconds', 21600))):
                return False
            self._thread = threading.Thread(target=self.check_and_download, name='calendar-update', daemon=True)
            self._thread.start()
            return True

    def _run_git(self, args: list[str], *, cwd: Path | None = None, timeout: int = 20) -> bytes:
        environment = dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='never')
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        try:
            result = subprocess.run(['git', *args], cwd=cwd, env=environment,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL, timeout=timeout,
                                    creationflags=flags)
        except FileNotFoundError:
            raise UpdateError('未找到 Git；自动更新暂不可用') from None
        except subprocess.TimeoutExpired:
            raise UpdateError('更新连接超时，保留当前版本') from None
        if result.returncode:
            raise UpdateError('无法访问更新仓库，请检查网络与原有 Git 授权')
        return result.stdout

    def _prepare_git(self):
        git = self.config.get('git', {})
        remote = git.get('repository', '')
        expected = _repo_identity(remote)
        source = Path(git.get('credential_source', ''))
        if not source.is_dir():
            raise UpdateError('未找到原有 Git 授权目录，当前版本继续使用')
        actual = self._run_git(['-C', str(source), 'remote', 'get-url', 'origin']).decode('utf-8').strip()
        if _repo_identity(actual) != expected:
            raise UpdateError('Git 授权目录不是指定更新仓库，已停止检查')
        # Reuse credential-helper configuration, never request/extract/store tokens.
        helper_result = subprocess.run(['git', '-C', str(source), 'config', '--get-urlmatch', 'credential.helper', remote],
                                       stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                       timeout=5, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        helpers = helper_result.stdout.decode('utf-8').splitlines() if helper_result.returncode == 0 else []
        mirror = self.directory / 'repository.git'
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not (mirror / 'HEAD').exists():
            self._run_git(['init', '--bare', str(mirror)])
        self._run_git(['--git-dir', str(mirror), 'config', 'remote.origin.url', remote])
        self._run_git(['--git-dir', str(mirror), 'config', 'remote.origin.promisor', 'true'])
        self._run_git(['--git-dir', str(mirror), 'config', 'remote.origin.partialclonefilter', 'blob:none'])
        no_hooks = self.directory / 'no-hooks'
        no_hooks.mkdir(exist_ok=True)
        base = ['-c', 'credential.interactive=false', '-c', 'core.hooksPath=' + str(no_hooks)]
        if helpers:
            base += ['-c', 'credential.helper=']
            for helper in helpers:
                base += ['-c', 'credential.helper=' + helper]
        self._git_base = base + ['--git-dir', str(mirror)]
        branch = git.get('branch', 'main')
        if not re.fullmatch(r'[A-Za-z0-9_./-]+', branch) or branch.startswith('-') or '..' in branch:
            raise UpdateError('更新分支无效')
        self._run_git(self._git_base + ['fetch', '--no-tags', '--depth=1', '--filter=blob:none', 'origin', branch],
                      timeout=min(60, max(5, git.get('fetch_timeout_seconds', 20))))
        self._git_commit = self._run_git(self._git_base + ['rev-parse', 'FETCH_HEAD^{commit}']).decode('ascii').strip()
        if not re.fullmatch('[0-9a-f]{40,64}', self._git_commit):
            raise UpdateError('更新仓库未返回有效提交')

    def _read_transport(self, location: str, maximum: int) -> bytes:
        if self._fetcher:
            data = self._fetcher(location, maximum)
        elif self.config.get('transport') == 'git':
            # Both manifest and package stay in the same fetched commit.
            if not re.fullmatch(r'[A-Za-z0-9_./-]+', location) or location.startswith('/') or '..' in location.split('/'):
                raise UpdateError('更新仓库文件路径无效')
            if self._git_base is None:
                self._prepare_git()
            size = self._run_git(self._git_base + ['cat-file', '-s', self._git_commit + ':' + location])
            if int(size) > maximum:
                raise UpdateError('更新源返回内容过大')
            data = self._run_git(self._git_base + ['show', self._git_commit + ':' + location])
        else:
            parsed = urlsplit(location)
            origin = parsed.scheme + '://' + (parsed.netloc or '')
            if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.fragment or origin not in self.config.get('trusted_https_origins', []):
                raise UpdateError('更新地址不在受信来源内')
            with build_opener(_NoRedirects()).open(Request(location, headers={'User-Agent': 'WillanceCalendarUpdate/1.2', 'Accept': 'application/json, application/zip'}), timeout=15) as response:
                data = response.read(maximum + 1)
        if not isinstance(data, bytes) or len(data) > maximum:
            raise UpdateError('更新源返回内容过大')
        return data

    def check_and_download(self) -> dict:
        if not self.config.get('enabled'):
            return self.status()
        try:
            self._set(state='checking', message='正在后台检查新版', last_checked_at=time.time())
            self._git_base = None  # A fresh fetch per check, never the source checkout.
            self._git_commit = None
            location = self.config.get('git', {}).get('manifest_path') if self.config.get('transport') == 'git' else self.config.get('manifest_url')
            manifest = json.loads(self._read_transport(location, MAX_MANIFEST))
            validate_manifest(manifest, self.config)
            if self._pending().exists():
                previous = json.loads(self._pending().read_text(encoding='utf-8'))
                validate_manifest(previous, self.config)
                if version(previous['version']) >= version(manifest['version']):
                    self._set(state='ready', ready_version=previous['version'], message='新版已下载，将在下次启动时更新')
                    return self.status()
            if version(manifest['version']) <= version(self.current_version):
                self._set(state='current', message='当前已是最新版本', ready_version=None)
                return self.status()
            verify_update_requirements(self.root, self.current_version, manifest)
            self._set(state='downloading', message='正在后台下载新版，日历可继续使用')
            package = manifest['package']
            raw = self._read_transport(package.get('path') if self.config.get('transport') == 'git' else package.get('url'), package['size'])
            if len(raw) != package['size'] or hashlib.sha256(raw).hexdigest() != package['sha256']:
                raise UpdateError('更新包完整性校验失败，保留当前版本')
            staged_zip = self.directory / 'package.zip'
            staged_zip.write_bytes(raw)
            staged = self.directory / ('staged-' + manifest['version'])
            self._extract_verified(staged_zip, manifest, staged)
            atomic_json(self._pending(), manifest)
            self._set(state='ready', ready_version=manifest['version'], message='新版已下载，将在下次启动时更新')
        except Exception as error:
            message = str(error) if isinstance(error, UpdateError) else '更新暂不可用，保留当前版本'
            self._set(state='error', message=message)
        return self.status()

    def stage_local(self, package_path: Path, manifest_data: dict, *, trusted_local: bool = False) -> dict:
        """Bootstrap only: user-downloaded local repair bundle, never an HTTP route."""
        if trusted_local is not True:
            raise UpdateError('本地升级包需要明确的受信调用')
        validate_manifest(manifest_data, self.config)
        verify_update_requirements(self.root, self.current_version, manifest_data)
        if version(manifest_data['version']) <= version(self.current_version):
            raise UpdateError('本地升级版本必须高于当前版本')
        package = manifest_data['package']
        path = Path(package_path)
        if path.stat().st_size != package['size'] or hashlib.sha256(path.read_bytes()).hexdigest() != package['sha256']:
            raise UpdateError('本地升级包完整性校验失败')
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        destination = self.directory / 'package.zip'
        if path.resolve() != destination.resolve():
            shutil.copy2(path, destination)
        self._extract_verified(destination, manifest_data, self.directory / ('staged-' + manifest_data['version']))
        atomic_json(self._pending(), manifest_data)
        self._set(state='ready', ready_version=manifest_data['version'], message='新版已准备，将在下次启动时更新')
        return self.status()

    def _target(self, name: str) -> Path:
        target = self.root / safe_path(name)
        current = target
        while current != self.root:
            if current.is_symlink() or getattr(current, 'is_junction', lambda: False)():
                raise UpdateError('安装目录包含符号链接，已停止更新')
            current = current.parent
        return target

    def _extract_verified(self, archive: Path, manifest: dict, destination: Path):
        if destination.is_symlink() or getattr(destination, 'is_junction', lambda: False)():
            raise UpdateError('更新暂存目录不能使用符号链接或目录联接')
        if destination.exists():
            shutil.rmtree(destination)
        destination.mkdir(parents=True, mode=0o700)
        try:
            with zipfile.ZipFile(archive) as zipped:
                entries = zipped.infolist()
                if len(entries) != len(manifest['files']) or len({i.filename for i in entries}) != len(entries):
                    raise UpdateError('更新包文件清单不一致')
                for info in entries:
                    name = safe_path(info.filename)
                    if info.is_dir() or stat.S_ISLNK(info.external_attr >> 16):
                        raise UpdateError('更新包不允许目录或符号链接条目')
                    metadata = manifest['files'].get(name)
                    if not metadata or info.file_size != metadata['size']:
                        raise UpdateError('更新包文件大小不一致')
                    raw = zipped.read(info)
                    if hashlib.sha256(raw).hexdigest() != metadata['sha256']:
                        raise UpdateError('更新包文件摘要不一致')
                    target = destination / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(raw)
        except Exception:
            shutil.rmtree(destination, ignore_errors=True)
            raise

    def apply_pending(self) -> str | None:
        """Call under startup_lock, after owned service stopped, before start_server.

        Per-file changes are journaled with exact old bytes. Interrupted promotion
        is rolled back on the next call before any server is started.
        """
        if (self.directory / 'transaction.json').exists():
            self.rollback_last()
        if (self.directory/'rollback-request.json').exists():return _history_apply(self)
        if not self._pending().exists():
            return None
        manifest = json.loads(self._pending().read_text(encoding='utf-8'))
        validate_manifest(manifest, self.config)
        verify_update_requirements(self.root, self.current_version, manifest)
        if version(manifest['version']) <= version(self.current_version):
            self._pending().unlink(missing_ok=True)
            return None
        staged = self.directory / ('staged-' + manifest['version'])
        # Reverify staged bytes immediately before applying, not just on download.
        for name, metadata in manifest['files'].items():
            path = staged / name
            if path.is_symlink() or not path.is_file() or path.stat().st_size != metadata['size'] or hashlib.sha256(path.read_bytes()).hexdigest() != metadata['sha256']:
                raise UpdateError('待安装文件已变化，已停止更新')
            self._target(name)
        if not _history_archive(self):raise UpdateError(self._history_error)
        backup = self.directory / 'rollback'
        if backup.exists():
            shutil.rmtree(backup)
        backup.mkdir(parents=True)
        names = list(manifest['files']) + list(manifest.get('delete', []))
        journal = {'from_version': self.current_version, 'to_version': manifest['version'], 'files': []}
        for name in names:
            target = self._target(name)
            existed = target.exists()
            if existed:
                if not target.is_file() or target.is_symlink():
                    raise UpdateError('安装目标不是普通文件')
                saved = backup / name
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
            journal['files'].append({'path': name, 'existed': existed})
        atomic_json(self.directory / 'transaction.json', journal)
        try:
            for name in names:
                target = self._target(name)
                target.parent.mkdir(parents=True, exist_ok=True)
                if name in manifest['files']:
                    temp = target.with_name(target.name + '.update-tmp')
                    shutil.copy2(staged / name, temp)
                    os.replace(temp, target)
                else:
                    target.unlink(missing_ok=True)
            self._set(state='applied', message='新版文件已更新，正在启动验证', ready_version=manifest['version'])
            return manifest['version']
        except Exception:
            self.rollback_last()
            raise UpdateError('更新应用失败，已恢复原版本') from None

    def confirm_started(self, running_version: str | None = None):
        """Call only after health reports the new version; keeps one backup."""
        transaction = self.directory / 'transaction.json'
        if running_version is not None:
            version(running_version)
            if transaction.exists() and json.loads(transaction.read_text(encoding='utf-8'))['to_version'] != running_version:
                raise UpdateError('新版服务版本验证未通过')
            self.current_version = running_version
        if transaction.exists():
            _history_archive(self)
            os.replace(transaction, self.directory / 'last-successful-update.json')
        self._pending().unlink(missing_ok=True)
        self._set(state='current', current_version=self.current_version, ready_version=None, message='当前已是最新版本')

    def rollback_last(self) -> bool:
        journal_path = self.directory / 'transaction.json'
        if not journal_path.exists():
            return False
        journal = json.loads(journal_path.read_text(encoding='utf-8'))
        for item in reversed(journal['files']):
            name = safe_path(item['path'])
            target = self._target(name)
            target.with_name(target.name + '.update-tmp').unlink(missing_ok=True)
            if item['existed']:
                saved = self.directory / 'rollback' / name
                if not saved.is_file() or saved.is_symlink():
                    raise UpdateError('更新回退副本不完整，未启动损坏版本')
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved, target)
            else:
                target.unlink(missing_ok=True)
        journal_path.unlink(missing_ok=True)
        self._pending().unlink(missing_ok=True)
        self.current_version = journal['from_version']
        self._set(state='rolled_back', current_version=self.current_version, ready_version=None, message='新版启动未通过，已恢复原版本')
        return True


# Versioned application backups contain program files only, never user data.
def _history_archive(manager):
    """Never discard an earlier backup if archiving fails."""
    path=manager.directory/'transaction.json'
    if not path.exists():path=manager.directory/'last-successful-update.json'
    if not path.exists():return True
    try:
        if path.is_symlink() or path.stat().st_size>200000:raise UpdateError('备份日志无效')
        journal=json.loads(path.read_text(encoding='utf-8'));version(journal['from_version']);version(journal['to_version'])
        backup=manager.directory/'rollback';items=journal.get('files')
        if not isinstance(items,list) or not 1<=len(items)<=MAX_FILES:raise UpdateError('备份清单无效')
        rows=[];content={};total=0
        for item in items:
            name=safe_path(item['path']);existed=item.get('existed')is True
            row={'path':name,'existed':existed}
            if existed:
                saved=backup/name
                if saved.is_symlink() or not saved.is_file():raise UpdateError('原版本备份丢失')
                total+=saved.stat().st_size
                if total>MAX_EXPANDED:raise UpdateError('原版本备份过大')
                data=saved.read_bytes();row.update(size=len(data),sha256=hashlib.sha256(data).hexdigest());content[name]=data
            rows.append(row)
        # A first installation has no older application to archive.
        if 'app.py'not in content:return True
        tag=journal['from_version']+'-before-'+journal['to_version']+'-'+hashlib.sha256(content['app.py']).hexdigest()[:12]
        folder=manager.directory/'history'
        if folder.is_symlink():raise UpdateError('备份目录无效')
        folder.mkdir(parents=True,exist_ok=True);meta=folder/(tag+'.json');target=folder/(tag+'.zip')
        if meta.exists():
            old=json.loads(meta.read_text(encoding='utf-8'))
            if target.is_symlink()or not target.is_file()or target.stat().st_size!=old['size']or hashlib.sha256(target.read_bytes()).hexdigest()!=old['sha256']:raise UpdateError('历史备份校验失败')
            return True
        temp=folder/(tag+'.'+uuid.uuid4().hex+'.tmp')
        with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
            for name,data in content.items():z.writestr(name,data)
        os.replace(temp,target);raw=target.read_bytes()
        atomic_json(meta,{'schema':1,'id':tag,'version':journal['from_version'],'replaced_by':journal['to_version'],'created_at':datetime.now(timezone.utc).isoformat(),'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'files':rows})
        manager._history_error=None;return True
    except (OSError,ValueError,TypeError,KeyError,UpdateError) as error:
        manager._history_error='历史备份未完成，保留原备份并暂停安装下一版：'+str(error)[:120]
        return False

def _history_metadata(manager,identifier):
    if not isinstance(identifier,str) or not re.fullmatch(r'[0-9.]+-before-[0-9.]+-[a-f0-9]{12}',identifier):raise UpdateError('备份编号无效')
    folder=manager.directory/'history';path=folder/(identifier+'.json')
    if folder.is_symlink() or path.is_symlink() or not path.is_file()or path.stat().st_size>200000:raise UpdateError('未找到有效版本备份')
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema')!=1 or data.get('id')!=identifier:raise UpdateError('备份记录不一致')
    version(data['version']);return data

def _history_list(manager):
    _history_archive(manager);folder=manager.directory/'history';items=[]
    if folder.exists()and not folder.is_symlink():
        for path in sorted(folder.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:100]:
            try:
                m=_history_metadata(manager,path.stem);items.append({k:m[k]for k in('id','version','replaced_by','created_at','size')})
            except (OSError,ValueError,KeyError,UpdateError):continue
    return {'items':items,'current_version':manager.current_version,'updates_paused':bool(manager.config.get('updates_paused')),'backup_error':getattr(manager,'_history_error',None),'note':'只回退程序文件，个人日程、移除规则、收藏、提醒和持仓代码不变。旧版可能不显示新功能，原数据保留。回退后暂停自动升级，手动检查更新可恢复。'}

def _history_request(manager,identifier):
    m=_history_metadata(manager,identifier)
    if version(m['version'])>=version(manager.current_version):raise UpdateError('请选择更早的程序版本')
    path=manager.directory/'history'/(identifier+'.zip')
    if path.is_symlink() or not path.is_file()or path.stat().st_size!=m['size']or hashlib.sha256(path.read_bytes()).hexdigest()!=m['sha256']:raise UpdateError('备份校验失败，未安排回退')
    atomic_json(manager.directory/'rollback-request.json',{'id':identifier,'version':m['version']})
    return {'state':'rollback_ready','version':m['version'],'message':'已安排回退；退出并关闭旧日历窗口，再重新打开。个人数据保持不变。'}

def _history_apply(manager):
    request=manager.directory/'rollback-request.json'
    if request.is_symlink() or request.stat().st_size>4096:raise UpdateError('回退请求无效')
    record=json.loads(request.read_text(encoding='utf-8'));m=_history_metadata(manager,record.get('id'))
    package=manager.directory/'history'/(m['id']+'.zip')
    if package.is_symlink()or package.stat().st_size!=m['size']or hashlib.sha256(package.read_bytes()).hexdigest()!=m['sha256']:raise UpdateError('备份校验失败，保留当前版本')
    rows=m['files'];content={};total=0
    if not isinstance(rows,list)or not 1<=len(rows)<=MAX_FILES:raise UpdateError('备份清单无效')
    with zipfile.ZipFile(package)as z:
        if len(z.namelist())!=len(set(z.namelist())):raise UpdateError('备份有重复文件')
        expected={safe_path(x['path'])for x in rows if x.get('existed')}
        if set(z.namelist())!=expected:raise UpdateError('备份文件不一致')
        for row in rows:
            name=safe_path(row['path']);manager._target(name)
            if row.get('existed'):
                info=z.getinfo(name);total+=info.file_size
                if total>MAX_EXPANDED or stat.S_ISLNK(info.external_attr>>16):raise UpdateError('备份内容无效')
                raw=z.read(name)
                if len(raw)!=row['size']or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise UpdateError('备份文件校验失败')
                content[name]=raw
    if not _history_archive(manager):raise UpdateError(manager._history_error)
    backup=manager.directory/'rollback'
    if backup.exists():shutil.rmtree(backup)
    backup.mkdir(parents=True)
    # Keep this updater to honor the pause flag in older restored apps.
    # Keep the user's current channel configuration instead of restoring paths.
    rows=[r for r in rows if r['path']not in ('desktop/updater.py','desktop/update_config.json')]
    journal={'from_version':manager.current_version,'to_version':m['version'],'files':[],'manual_rollback':True}
    for row in rows:
        name=row['path'];target=manager._target(name);existed=target.exists()
        if existed:
            if not target.is_file()or target.is_symlink():raise UpdateError('回退目标不是普通文件')
            saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
        journal['files'].append({'path':name,'existed':existed})
    atomic_json(manager.directory/'transaction.json',journal)
    try:
        for row in rows:
            target=manager._target(row['path']);target.parent.mkdir(parents=True,exist_ok=True)
            if row.get('existed'):
                temp=target.with_name(target.name+'.update-tmp');temp.write_bytes(content[row['path']]);os.replace(temp,target)
            else:target.unlink(missing_ok=True)
        manager.config['updates_paused']=True;atomic_json(manager.config_path,manager.config)
        request.unlink(missing_ok=True);manager._pending().unlink(missing_ok=True)
        manager._set(state='applied',ready_version=m['version'],message='程序已回退，正在启动验证；自动升级已暂停')
        return m['version']
    except Exception:
        manager.rollback_last();request.unlink(missing_ok=True);raise UpdateError('回退未完成，已恢复当前版本')from None

UpdateManager.history=_history_list
UpdateManager.request_rollback=_history_request
