"""One-click per-user installer using only Python and built-in Windows COM."""
from __future__ import annotations

import base64
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
APP_FOLDER = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Willance" / "EventCalendarV1"
FILES = ('app.py', 'providers.py', 'timing_policy.py', 'ir_policy.py', 'retention_policy.py', 'ir_overrides.json', 'selection_policy.py', 'quotes.py', 'quote_service.py', 'ipo.py', 'logos.py', 'branding', 'watchlist.default.json', 'initial_quotes.json', 'additional_sources.py', 'hk_earnings.py', 'initial_snapshot.json', 'DATA_ACCURACY.md', 'seed_verified.json', 'web', 'desktop',
         'START_WINDOWS.cmd', 'INSTALL_WINDOWS.cmd', 'INSTALL_WINDOWS.ps1', 'README_WINDOWS.md')
SHORTCUT = '时序.lnk'
LEGACY_SHORTCUTS = ('时序投资日历 V1.lnk', '退出时序投资日历 V1.lnk', 'Willance Event Calendar V1.lnk')
STOP_SHORTCUT = '退出时序投资日历 V1.lnk'  # legacy cleanup only; never created


def ps_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def run_powershell(script: str) -> str:
    encoded = base64.b64encode(script.encode('utf-16-le')).decode('ascii')
    result = subprocess.run(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        creationflags=subprocess.CREATE_NO_WINDOW, timeout=25,
    )
    if result.returncode:
        detail = result.stderr.decode('utf-8-sig', errors='replace').strip()
        raise RuntimeError(detail[:800] or '无法更新桌面快捷方式；原入口已保留，可直接运行 START_WINDOWS.cmd。')
    return result.stdout.decode('utf-8-sig', errors='replace').strip()


def stop_calendar() -> None:
    from desktop.launcher import read_running, runtime_dir, stop_server
    ready = runtime_dir() / 'ready.json'
    stop_server(ready)
    deadline = time.monotonic() + 5
    while read_running(ready) and time.monotonic() < deadline:
        time.sleep(.1)
    if read_running(ready):
        raise RuntimeError('日历服务尚未退出。请先在日历内退出，再安装。')


def _shortcut_identity(executable: Path, app_folder: Path, icon_path: Path | None = None) -> list[str]:
    """Identity checks shared by migration and uninstall, never filename-only."""
    root = Path(app_folder).resolve()
    launcher = root / 'desktop' / 'launcher.py'
    icon = icon_path or root / 'branding' / 'shixu.ico'
    argument = '"' + str(launcher) + '"'
    targets = [str(executable), str(root/'runtime'/'pythonw.exe'), str(root/'runtime'/'python.exe')]
    approved = ','.join(ps_quote(x) for x in targets)
    return [
        "$ErrorActionPreference='Stop'", "[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)",
        "$desktop=[Environment]::GetFolderPath('DesktopDirectory')", "$shell=New-Object -ComObject WScript.Shell",
        "$desktops=@($desktop);if($env:USERPROFILE){$desktops+=@(Join-Path $env:USERPROFILE 'Desktop')};foreach($od in @($env:OneDrive,$env:OneDriveConsumer,$env:OneDriveCommercial)){if($od){$desktops+=@(Join-Path $od 'Desktop')}}",
        "$root="+ps_quote(str(root)), "$exe="+ps_quote(str(executable)), "$arg="+ps_quote(argument), "$icon="+ps_quote(str(icon)),
        "$approved=@("+approved+")", "$launchPath="+ps_quote(str(launcher)),
        "$pythonInfo=Join-Path $root 'desktop\\python-path.txt'",
        "if(Test-Path -LiteralPath $pythonInfo){$prior=(Get-Content -LiteralPath $pythonInfo -Raw).Trim();if(([IO.Path]::GetFileName($prior)) -in @('python.exe','pythonw.exe')){$approved+=@($prior)}}",
        "function Norm([string]$p){try{return [IO.Path]::GetFullPath($p).TrimEnd('\\').ToLowerInvariant()}catch{return ''}}",
        # Exact launcher path plus installer working directory/description can
        # identify old links after Python changed; filename alone never can.
        "function Owned([string]$p){if(-not(Test-Path -LiteralPath $p)){return $false};$x=$shell.CreateShortcut($p);$target=Norm($x.TargetPath);$linkArgs=([string]$x.Arguments).Trim();$argsMatch=($linkArgs -ieq $arg -or $linkArgs -ieq ($arg+' --stop') -or $linkArgs -ieq $launchPath -or $linkArgs -ieq ($launchPath+' --stop'));if(-not $argsMatch){return $false};$ok=$false;foreach($a in $approved){if($target -eq (Norm $a)){$ok=$true}};if(-not $ok){$pythonName=[IO.Path]::GetFileName($x.TargetPath);$ok=($pythonName -in @('python.exe','pythonw.exe')) -and ((Norm $x.WorkingDirectory) -eq (Norm $root)) -and ($x.Description -in @('Willance investment event calendar V1','Stop only Willance event calendar V1','时序'))};return $ok}",
        "$desktops=@($desktops|Where-Object {$_ -and (Test-Path -LiteralPath $_ -PathType Container)}|Select-Object -Unique)",
    ]


def shortcut_script(executable: Path, app_folder: Path | None = None, icon_path: Path | None = None) -> str:
    """Create the new link before removing only verified legacy app links."""
    root = Path(app_folder or APP_FOLDER).resolve()
    legacy = ','.join(ps_quote(x) for x in LEGACY_SHORTCUTS)
    return "\n".join(_shortcut_identity(executable, root, icon_path) + [
        "$new=Join-Path $desktop '时序.lnk'", "if((Test-Path -LiteralPath $new) -and -not(Owned $new)){throw '桌面已有同名的其他快捷方式，已保留它和原日历入口。'}",
        "if(-not(Test-Path -LiteralPath $icon)){throw '时序图标未就绪，已保留原日历入口。'}",
        "$current=$false;if(Test-Path -LiteralPath $new){$existing=$shell.CreateShortcut($new);$current=((Norm $existing.TargetPath) -eq (Norm $exe)) -and ($existing.Arguments -eq $arg) -and ($existing.IconLocation -eq ($icon+',0')) -and ((Norm $existing.WorkingDirectory) -eq (Norm $root)) -and ($existing.Description -eq '时序')}",
        "if(-not $current){$tmp=Join-Path $desktop ('.shixu-'+[guid]::NewGuid().ToString('N')+'.lnk');try{$link=$shell.CreateShortcut($tmp);$link.TargetPath=$exe;$link.Arguments=$arg;$link.WorkingDirectory=$root;$link.Description='时序';$link.WindowStyle=7;$link.IconLocation=$icon+',0';$link.Save();if((Test-Path -LiteralPath $new) -and -not(Owned $new)){throw '桌面同名入口已变化，未覆盖。'};Move-Item -LiteralPath $tmp -Destination $new -Force}finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}}",
        "$removed=@();$preserved=@();$unmatched=@();foreach($folder in $desktops){foreach($name in @("+legacy+")){$p=Join-Path $folder $name;if(Owned $p){try{Remove-Item -LiteralPath $p -Force;$removed+=@($p)}catch{$preserved+=@($p)}}elseif(Test-Path -LiteralPath $p){$unmatched+=@($p)}}}",
        "[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)", "@{status='ready';shortcut=$new;removed=$removed;preserved=$preserved;unmatched=$unmatched;icon=$icon;desktop=$desktop}|ConvertTo-Json -Compress",
    ])


def migrate_shortcuts(app_folder: Path, executable: Path) -> dict:
    """Idempotent user-desktop branding migration, without reinstalling files."""
    if os.name != 'nt':
        return {'status': 'unsupported', 'note': '桌面快捷方式仅在Windows更新'}
    # A content-addressed icon avoids Explorer retaining a previous icon for an
    # unchanged filename. No global icon-cache deletion or registry mutation.
    icon = app_folder / 'branding' / 'shixu.ico'
    digest = hashlib.sha256(icon.read_bytes()).hexdigest()
    cache = app_folder / 'desktop' / 'icon-cache'
    cache.mkdir(parents=True, exist_ok=True)
    icon_path = cache / ('shixu-' + digest[:16] + '.ico')
    if not icon_path.is_file() or hashlib.sha256(icon_path.read_bytes()).hexdigest() != digest:
        shutil.copy2(icon, icon_path)
    output = run_powershell(shortcut_script(executable, app_folder, icon_path))
    result = json.loads(output)
    if not isinstance(result, dict) or result.get('status') != 'ready':
        raise RuntimeError('桌面入口尚未更新；原入口已保留。')
    # The stamp records what succeeded, never replaces inspecting actual links.
    state = app_folder / 'desktop' / 'branding-state.json'
    payload = {**result, 'version': '1.11.0', 'icon_sha256': digest}
    state.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    try:
        shell = ctypes.WinDLL('shell32', use_last_error=True)
        shell.SHChangeNotify.argtypes = [ctypes.c_long, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
        shell.SHChangeNotify.restype = None
        for event, changed in [(0x2000, result.get('shortcut')), *((0x4, path) for path in (result.get('removed') or []))]:
            if changed:
                name = ctypes.create_unicode_buffer(str(changed))
                shell.SHChangeNotify(event, 0x5, ctypes.cast(name, ctypes.c_void_p), None)
    except (AttributeError, OSError):
        pass  # Link creation, not shell notification, determines success.
    return result


def uninstall_shortcut_script(executable: Path, app_folder: Path) -> str:
    names = ','.join(ps_quote(x) for x in (SHORTCUT, *LEGACY_SHORTCUTS))
    return '\n'.join(_shortcut_identity(executable, app_folder) + [
        "foreach($name in @("+names+")){$path=Join-Path $desktop $name;if(Owned $path){Remove-Item -LiteralPath $path -Force}}",
    ])


def install() -> None:
    if os.name != 'nt':
        raise RuntimeError('只支持在 Windows 安装。')
    for name in FILES:
        if not (ROOT / name).exists():
            raise RuntimeError(f'安装包不完整：{name}。请完整解压 ZIP 后重试。')
    stop_calendar()
    if ROOT.resolve() != APP_FOLDER.resolve():
        APP_FOLDER.mkdir(parents=True, exist_ok=True)
        for name in (*FILES, 'runtime', 'RUNTIME_SOURCE.json'):
            source = ROOT / name
            if not source.exists():
                continue
            destination = APP_FOLDER / name
            if source.is_dir():
                shutil.copytree(source, destination, dirs_exist_ok=True,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            else:
                shutil.copy2(source, destination)
    executable = APP_FOLDER / 'runtime' / 'pythonw.exe'
    if not executable.is_file():
        executable = Path(sys.executable).with_name('pythonw.exe')
        if not executable.is_file():
            executable = Path(sys.executable)
    # Preserve the previously recorded interpreter until ownership verification
    # has cleaned old links that may still point to that external Python.
    migrate_shortcuts(APP_FOLDER, executable)
    (APP_FOLDER / 'desktop' / 'python-path.txt').write_text(str(executable), encoding='utf-8')
    (APP_FOLDER / 'desktop' / 'installation.json').write_text(
        json.dumps({'version': '1.11.0', 'install_dir': str(APP_FOLDER),
                    'shortcut_names': [SHORTCUT]}, ensure_ascii=False, indent=2), encoding='utf-8')
    ctypes.windll.user32.MessageBoxW(None, '安装完成，桌面快捷方式已创建。\n双击桌面的“时序”打开日历。', '时序', 0x40)


def uninstall() -> None:
    if os.name != 'nt':
        raise RuntimeError('只支持在 Windows 卸载。')
    if ROOT.resolve() == APP_FOLDER.resolve():
        raise RuntimeError('请从原解压包运行 START_WINDOWS.cmd --uninstall；不要从正在使用的安装目录删除程序。')
    stop_calendar()
    run_powershell(uninstall_shortcut_script(Path(sys.executable), APP_FOLDER))
    if APP_FOLDER.exists():
        shutil.rmtree(APP_FOLDER)
    ctypes.windll.user32.MessageBoxW(None, '本日历、缓存和桌面快捷方式已移除。Python、Edge 和其他后台程序未改动。', '时序', 0x40)


if __name__ == '__main__':
    install()
