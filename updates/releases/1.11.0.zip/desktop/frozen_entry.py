"""Optional PyInstaller entry. Does not imply that a binary has been built."""
import runpy
import sys

if '--calendar-server' in sys.argv:
    sys.argv.remove('--calendar-server')
    runpy.run_module('app', run_name='__main__')
else:
    from launcher import main
    raise SystemExit(main())
