"""Hourly, read-only total-market-cap quotes from Tencent Finance.

The quote service itself is the primary data source. Field 45 is its total
market cap in 100m local currency; field 44 is float cap and is never substituted.
The unit is independently checked against returned shares * quoted price when
that share count is present. No company-level values are summed across tickers.
"""
from __future__ import annotations

import concurrent.futures
import copy
import datetime as dt
from decimal import Decimal
import json
import math
import os
from pathlib import Path
import re
import threading
import urllib.parse
import urllib.request

UTC = dt.timezone.utc
BJ = dt.timezone(dt.timedelta(hours=8), 'Asia/Shanghai')
TTL_SECONDS = 3600
HTTP_TIMEOUT = 12
MAX_RESPONSE = 2 * 1024 * 1024
MAX_CACHE = 40 * 1024 * 1024
BATCH_SIZE = 80
MAX_WORKERS = 4
HOST = 'qt.gtimg.cn'
SOURCE_NAME = '腾讯财经总市值行情'
_LOCK = threading.RLock()
_MARKETS = {'A股':'A股','中国':'A股','沪深京':'A股','CN':'A股','美股':'美股','美国':'美股','US':'美股','港股':'港股','香港':'港股','HK':'港股'}


def _now():
    return dt.datetime.now(UTC)


def _stamp(value=None):
    return (value or _now()).isoformat(timespec='seconds')


def _number(value):
    try:
        result = float(str(value).replace(',', '').strip())
        return result if math.isfinite(result) and result > 0 else None
    except (TypeError, ValueError):
        return None


def quote_key(company_or_market, ticker=None):
    """Canonical keys: A股:300750, 港股:00700, 美股:AAPL."""
    if isinstance(company_or_market, dict):
        ticker = company_or_market.get('ticker') or company_or_market.get('code')
        market = company_or_market.get('market')
    else:
        market = company_or_market
    market = _MARKETS.get(str(market), str(market))
    ticker = str(ticker or '').strip().upper()
    if market == 'A股':
        ticker = re.sub(r'^(?:SH|SZ|BJ)', '', ticker)
        ticker = re.sub(r'\.(?:SH|SZ|BJ)$', '', ticker)
        if not re.fullmatch(r'\d{6}', ticker):
            raise ValueError('A股代码必须为六位数字')
    elif market == '港股':
        ticker = re.sub(r'^(?:R_)?HK', '', ticker)
        ticker = re.sub(r'\.HK$', '', ticker)
        if not re.fullmatch(r'\d{1,5}', ticker):
            raise ValueError('港股代码无效')
        ticker = ticker.zfill(5)
    elif market == '美股':
        ticker = re.sub(r'^US(?=[A-Z])', '', ticker) if str(company_or_market).startswith('us') else ticker
        if not re.fullmatch(r'[A-Z][A-Z0-9.\-_]{0,19}', ticker):
            raise ValueError('美股代码无效')
    else:
        raise ValueError('市值市场未支持')
    return market + ':' + ticker


def _symbol(key):
    market, ticker = key.split(':', 1)
    if market == 'A股':
        # New Beijing listings use 920; legacy NEEQ/BSE codes remain 4/8.
        prefix = 'bj' if ticker.startswith(('4','8','920')) else 'sh' if ticker.startswith(('5','6','9')) else 'sz'
        return prefix + ticker
    if market == '港股':
        return 'hk' + ticker
    return 'us' + ticker


def _ny_timezone(local):
    if local.year < 2007:
        raise ValueError('美东历史时区不在支持范围')
    march = dt.date(local.year,3,1)
    november = dt.date(local.year,11,1)
    start = march + dt.timedelta(days=(6-march.weekday())%7+7)
    end = november + dt.timedelta(days=(6-november.weekday())%7)
    if (local.date()==start and local.hour==2) or (local.date()==end and local.hour==1):
        raise ValueError('美东夏令时切换时点歧义')
    daylight = dt.datetime.combine(start,dt.time(3)) <= local < dt.datetime.combine(end,dt.time(2))
    return dt.timezone(dt.timedelta(hours=-4 if daylight else -5))


def _quote_time(raw, market):
    patterns = ['%Y%m%d%H%M%S','%Y/%m/%d %H:%M:%S','%Y-%m-%d %H:%M:%S']
    for pattern in patterns:
        try:
            local = dt.datetime.strptime(raw,pattern)
            timezone = _ny_timezone(local) if market=='美股' else BJ
            return local.replace(tzinfo=timezone).astimezone(BJ)
        except ValueError:
            continue
    raise ValueError('行情未提供可解析的事实时刻')


def _url(symbols):
    if not symbols or len(symbols)>BATCH_SIZE or not all(re.fullmatch(r'(?:sh|sz|bj)\d{6}|hk\d{5}|us[A-Z][A-Z0-9.\-_]{0,19}', x) for x in symbols):
        raise ValueError('行情请求证券代码无效')
    return 'https://' + HOST + '/q=' + ','.join(symbols)


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p=urllib.parse.urlsplit(newurl)
        if p.scheme!='https' or p.hostname!=HOST or p.username or p.password or p.port not in (None,443):
            raise ValueError('行情不允许越域重定向')
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def _fetch(symbols):
    request=urllib.request.Request(_url(symbols),headers={'User-Agent':'EventAtlas/1.1 (read-only personal calendar)','Referer':'https://gu.qq.com/','Accept':'text/plain','Accept-Encoding':'identity'})
    with urllib.request.build_opener(_SafeRedirect).open(request,timeout=HTTP_TIMEOUT) as response:
        p=urllib.parse.urlsplit(response.geturl())
        if p.scheme!='https' or p.hostname!=HOST:
            raise ValueError('行情响应主机不符')
        data=response.read(MAX_RESPONSE+1)
        if len(data)>MAX_RESPONSE:
            raise ValueError('行情响应超出2MiB限额')
        return data.decode('gb18030')


def parse_tencent(text, symbol_to_key, checked_at=None):
    """Parse only requested symbols. Return quotes and invalid-symbol reasons."""
    stamp=checked_at or _stamp()
    quotes, errors = {}, {}
    found=set()
    for match in re.finditer(r'v_([A-Za-z0-9_.\-]+)\s*=\s*"([^"\r\n]*)"\s*;',text):
        symbol=match.group(1)
        if symbol not in symbol_to_key:
            continue
        found.add(symbol)
        key=symbol_to_key[symbol]
        market,ticker=key.split(':',1)
        fields=match.group(2).split('~')
        try:
            if len(fields)<46 or not fields[1] or not fields[2]:
                raise ValueError('来源没有返回完整证券行情')
            expected_type={'A股':{'1','51','62','0'},'港股':{'100'},'美股':{'200'}}[market]
            if fields[0] not in expected_type:
                raise ValueError('来源行情市场类型不符')
            returned=fields[2]
            if market=='美股': returned=re.sub(r'\.(?:OQ|N|AM|O|P)$','',returned)
            if returned.upper()!=ticker:
                raise ValueError('行情代码与请求不符')
            price, cap_units = _number(fields[3]), _number(fields[45])
            if price is None or cap_units is None:
                raise ValueError('来源暂未提供正值总市值/报价，不以流通市值替代')
            currency={'A股':'CNY','港股':'HKD','美股':'USD'}[market]
            explicit=[x for x in fields if x in ('CNY','HKD','USD')]
            if explicit and currency not in explicit:
                raise ValueError('来源币种与市场不符')
            exact_cap=Decimal(fields[45].replace(',','').strip())*Decimal(100_000_000)
            cap=int(exact_cap) if exact_cap==exact_cap.to_integral_value() else float(exact_cap)
            if not math.isfinite(cap):
                raise ValueError('总市值非有限数')
            asof=_quote_time(fields[30],market)
            if asof.astimezone(UTC)>_now()+dt.timedelta(days=1):
                raise ValueError('行情事实日期异常超前')
            share_index={'A股':73,'港股':69,'美股':62}[market]
            shares=_number(fields[share_index]) if len(fields)>share_index else None
            validation='来源总市值字段45；原单位亿'+currency
            if shares:
                calculated=shares*price
                # Rounded cap fields are normally very close. Refuse a unit/schema
                # mismatch; ADR/foreign share-count ambiguity is not guessed away.
                if abs(calculated-cap)>max(3_000_000,cap*.05):
                    raise ValueError('总市值与源总股本×报价不一致，拒绝猜测单位或跨股类口径')
                validation+='；已与源总股本×报价交叉校验'
            scope='腾讯来源总市值口径；不跨证券代码相加，同一公司不同股类可能重复代表同一家公司。'
            if market in ('A股','港股'):
                scope+='若存在A/H等不同股类，不将本字段宣称为各股类按各自价格加总后的公司估值。'
            quotes[key]={'ticker':ticker,'market':market,'name':fields[1],'security_name':fields[1],
                'market_cap':cap,'currency':currency,'cap_asof':asof.isoformat(timespec='seconds'),
                'cap_source_checked_at':stamp,'source_checked_at':stamp,'source_url':_url([symbol]),
                'source_name':SOURCE_NAME,'cap_source_url':_url([symbol]),'method':'source_total_market_cap',
                'cap_method':'source_total_market_cap','cap_scope':scope,'validation':validation,
                'price_asof':asof.isoformat(timespec='seconds'),'quote_timezone':'Asia/Shanghai',
                'original_quote_time':fields[30],'original_timezone':'America/New_York' if market=='美股' else 'Asia/Shanghai',
                'data_stale':False,'cap_stale':False,'status':'ok','cache_used':False}
        except (ValueError,KeyError,IndexError) as exc:
            errors[key]=str(exc)
    for symbol in set(symbol_to_key)-found:
        errors[symbol_to_key[symbol]]='来源未返回该证券，程序将在后续刷新自动重试'
    return {'quotes':quotes,'errors':errors}


def _read_cache(path):
    try:
        if path.stat().st_size>MAX_CACHE: return {}
        content=json.loads(path.read_text(encoding='utf-8'))
        values=content.get('quotes',{})
        if not isinstance(values,dict): return {}
        output={}
        for key,q in values.items():
            if not isinstance(q,dict) or quote_key(q)!=key or not _number(q.get('market_cap')): continue
            when=dt.datetime.fromisoformat(q['source_checked_at'])
            if when.tzinfo is None: continue
            output[key]=q
        return output
    except (OSError,ValueError,KeyError,TypeError): return {}


def _write_cache(path,quotes):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+f'.{os.getpid()}.{threading.get_ident()}.tmp')
    temp.write_text(json.dumps({'quotes':quotes},ensure_ascii=False,allow_nan=False),encoding='utf-8')
    os.replace(temp,path)


def refresh_quotes(companies,cache_dir,force=False):
    """Fetch all supported requested tickers in bounded concurrent batches.

    Fresh source reads have a one-hour TTL, including outside normal sessions;
    the desktop service must call this hourly while it runs. An old last-trade
    time is retained as evidence, even when a vendor read succeeds now.
    """
    path=Path(cache_dir)/'total_market_caps.json'
    with _LOCK:
        old=_read_cache(path)
        requested={}; invalid=[]
        for company in companies:
            if not isinstance(company,dict): continue
            try:
                key=quote_key(company)
                requested[key]=_symbol(key)
            except ValueError as exc:
                invalid.append(str(company.get('ticker') or company.get('code') or '')+': '+str(exc))
        now=_now(); output={}; needing=[]
        for key,symbol in requested.items():
            q=old.get(key)
            if q and not force:
                age=(now-dt.datetime.fromisoformat(q['source_checked_at'])).total_seconds()
                if 0<=age<TTL_SECONDS:
                    output[key]=copy.deepcopy(q);output[key]['cache_used']=True
                    continue
            needing.append((key,symbol))
        batches=[needing[i:i+BATCH_SIZE] for i in range(0,len(needing),BATCH_SIZE)]
        failures={}
        def run(batch):
            mapping={symbol:key for key,symbol in batch}
            try:
                return parse_tencent(_fetch(list(mapping)),mapping)
            except Exception as exc:
                return {'quotes':{},'errors':{key:type(exc).__name__+': '+str(exc)[:160] for key in mapping.values()}}
        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            for result in pool.map(run,batches):
                output.update(result['quotes']); failures.update(result['errors'])
        for key,error in failures.items():
            if key in old:
                q=copy.deepcopy(old[key]);q.update(data_stale=True,cap_stale=True,status='cached',cache_used=True,error=error)
                output[key]=q
        merged=dict(old);merged.update(output)
        if output:_write_cache(path,merged)
        fresh=sum(not q.get('data_stale') for q in output.values())
        checked=[q.get('source_checked_at') for q in output.values() if q.get('source_checked_at')]
        missing=[key for key in requested if key not in output]
        source={'id':'hourly-total-market-cap','name':SOURCE_NAME,'status':'partial' if failures or invalid else 'ok' if output or not requested else 'error',
            'last_success':max(checked,default=None),'checked_at':_stamp(),'refresh_interval_seconds':TTL_SECONDS,
            'coverage':f'按所选事件证券批量获取A/美/港总市值，覆盖{fresh}/{len(requested)}个代码；字段45为总市值，字段44流通市值不替代；行情实际时点各条保留，程序自动补齐/每小时重试，无需用户手填。',
            'requested_count':len(requested),'available_count':len(output),'fresh_count':fresh,
            'missing_count':len(missing),'stale_count':sum(bool(q.get('data_stale')) for q in output.values()),
            'missing':missing,'errors':failures,'invalid':invalid,'source_url':'https://gu.qq.com/',
            'cache_used':bool(requested) and not batches,
            'error':f'{len(failures)}个行情未刷新、{len(invalid)}个代码未支持；保留原缓存和证据时点并继续自动重试。' if failures or invalid else None}
        return {'quotes':output,'source':source,'fetched_at':_stamp()}
