"""Source-checked IR public times. Earnings calls never replace earnings releases."""
from __future__ import annotations
import copy
import datetime as dt
import json
from pathlib import Path

def add_verified_ir_events(events):
    try:overrides=json.loads((Path(__file__).parent/'ir_overrides.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):return list(events)
    result={e['id']:copy.deepcopy(e) for e in events}
    for key,info in overrides.items():
        try:
            market,ticker,source_day=key.split(':',2)
            start=dt.datetime.fromisoformat(info['start_at'])
            if start.tzinfo is None:continue
            originals=[e for e in events if e.get('market')==market and (e.get('company') or {}).get('ticker')==ticker and str((e.get('details') or {}).get('美东财报日期') or (e.get('details') or {}).get('original_date') or e.get('date'))[:10]==source_day]
            if not originals:continue
            company=copy.deepcopy(originals[0].get('company') or {'name':ticker,'ticker':ticker})
            kind=info.get('kind') or info.get('event_type')
            if kind!='earnings_call':continue
            eid='ir-call-'+ticker+'-'+source_day
            result[eid]={'id':eid,'title':info.get('title') or company.get('name',ticker)+' · 业绩电话会','category':'earnings','event_type':'earnings_call','market':market,'date':start.date().isoformat(),'time':start.strftime('%H:%M'),'timezone':'Asia/Shanghai','start_at':info['start_at'],'end_at':info.get('end_at'),'time_precision':'exact' if not info.get('end_at') else 'range','status':'confirmed','company':company,'source_url':info['source_url'],'source_name':info['source_name'],'source_checked_at':info.get('source_checked_at'),'details':{'事件类型':'业绩电话会/直播，并非财报发布时刻','时间说明':info.get('timing_note',''),'官方原始日期':info.get('original_date') or source_day,'官方原始时间':info.get('original_time') or info.get('original_start'),'官方原始结束时间':info.get('original_end'),'官方原始时区':info.get('original_timezone'),'日程状态':'本次官方IR核实快照，保留来源核实时间；不能据此推断其他季度的电话会时间'}}
        except (ValueError,KeyError,TypeError):continue
    return list(result.values())
