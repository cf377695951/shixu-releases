@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
if exist "%~dp0runtime\pythonw.exe" (
  start "" "%~dp0runtime\pythonw.exe" "%~dp0desktop\launcher.py" %*
  exit /b 0
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -c "import sys;sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
  if not errorlevel 1 (
    py -3 "%~dp0desktop\launch_hidden.py" %*
    exit /b !errorlevel!
  )
)
where python >nul 2>nul
if not errorlevel 1 (
  python -c "import sys;sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>nul
  if not errorlevel 1 (
    python "%~dp0desktop\launch_hidden.py" %*
    exit /b !errorlevel!
  )
)
echo The bundled Python runtime is missing and no Python 3.11+ was found.
echo Install from https://www.python.org/downloads/windows/
echo Then run this launcher again. No program has been installed automatically.
pause
exit /b 1
