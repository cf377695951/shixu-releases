"""HKEX board-meeting calendar: official published rows, not a full earnings feed.

Python standard library only. The issuer's notified board-meeting date is
confirmed by this table; it is not a confirmed publication time or a guarantee
that the meeting/date cannot change. No account, order or notification access.
"""
from __future__ import annotations

import concurrent.futures
import copy
import datetime as dt
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import ssl
import threading
import urllib.parse
import urllib.request

UTC = dt.timezone.utc
HTTP_TIMEOUT = 12
MAX_BYTES = 4 * 1024 * 1024
MAX_CACHE_BYTES = 20 * 1024 * 1024
CACHE_SECONDS = 15 * 60
HOST = "www3.hkexnews.hk"
SOURCES = (
    ("hkex_board_main", "HKEX主板业绩董事会官方汇总", "https://www3.hkexnews.hk/reports/bmn/ebmn.htm", "主板"),
    ("hkex_board_gem", "HKEX GEM业绩董事会官方汇总", "https://www3.hkexnews.hk/reports/bmn/ebmngem.htm", "GEM"),
)
COVERAGE = "HKEX官方董事会通知汇总；遍历当前表内全部相关行，官方明确可能不完整；仅确认业绩董事会日期，非精确财报公布时间，须复核发行人原公告。未知市值不估填。"


def _now_iso():
    return dt.datetime.now(UTC).isoformat(timespec="seconds")


def _validate_url(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != "https" or parsed.hostname != HOST
            or parsed.username or parsed.password or parsed.port not in (None, 443)):
        raise ValueError("只允许HKEX官方指定HTTPS主机，拒绝越域重定向")
    return url


class _SameHostRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _fetch_html(url):
    _validate_url(url)
    request = urllib.request.Request(url, headers={
        "User-Agent": "EventAtlas-Calendar/1.0 (personal read-only calendar)",
        "Accept": "text/html",
        "Accept-Encoding": "identity",
    })
    opener = urllib.request.build_opener(
        urllib.request.HTTPSHandler(context=ssl.create_default_context()),
        _SameHostRedirect(),
    )
    with opener.open(request, timeout=HTTP_TIMEOUT) as response:
        _validate_url(response.geturl())
        body = response.read(MAX_BYTES + 1)
        if len(body) > MAX_BYTES:
            raise ValueError("HKEX响应超过4MiB，未作为完整表格接收")
        encoding = response.headers.get_content_charset() or "utf-8"
        return body.decode(encoding, errors="strict").lstrip("\ufeff")


def _clean(value):
    return re.sub(r"\s+", " ", value.replace("\xa0", " ")).strip()


class _Rows(HTMLParser):
    """Collect cells without executing scripts; tolerate HKEX's unclosed TD."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows = []
        self.row = None
        self.cell = None
        self.text = []
        self.ignored = 0

    def _finish_cell(self):
        if self.cell is not None and self.row is not None:
            self.row.append(_clean("".join(self.cell)))
        self.cell = None

    def _finish_row(self):
        self._finish_cell()
        if self.row is not None:
            self.rows.append(self.row)
        self.row = None

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in ("script", "style"):
            self.ignored += 1
            return
        if self.ignored:
            return
        if tag == "tr":
            self._finish_row()
            self.row = []
        elif tag in ("td", "th"):
            self._finish_cell()
            self.cell = [] if self.row is not None else None
        elif tag == "br":
            self.text.append(" ")
            if self.cell is not None:
                self.cell.append(" ")

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in ("script", "style"):
            self.ignored = max(0, self.ignored - 1)
            return
        if self.ignored:
            return
        if tag in ("td", "th"):
            self._finish_cell()
        elif tag == "tr":
            self._finish_row()

    def handle_data(self, data):
        if self.ignored:
            return
        self.text.append(data)
        if self.cell is not None:
            self.cell.append(data)

    def close(self):
        super().close()
        self._finish_row()


_EARNINGS = re.compile(r"\b(?:RESULTS?|QUARTER|QTR|ANNUAL|INTERIM|RES)\b", re.I)
_DATE = re.compile(r"\d{2}/\d{2}/\d{4}\Z")


def _parse_html(document, source_id, source_name, source_url, board, checked_at):
    parser = _Rows()
    parser.feed(document)
    parser.close()
    full_text = _clean(" ".join(parser.text))
    if "Board Meeting Notifications" not in full_text:
        raise ValueError("HKEX响应缺少董事会通知标识，可能返回错误页")
    asof_match = re.search(r"\bDate\s*:\s*(\d{2}/\d{2}/\d{4})", full_text)
    if not asof_match:
        raise ValueError("HKEX表格缺少官方资料日期")
    source_asof = dt.datetime.strptime(asof_match.group(1), "%d/%m/%Y").date().isoformat()
    header = None
    for row in parser.rows:
        upper = [cell.upper() for cell in row]
        if "BM DATE" in upper and "PURPOSE" in upper and "CODE" in upper:
            header = {label: index for index, label in enumerate(upper) if label}
            break
    if not header or "STOCK SHORT NAME" not in header:
        raise ValueError("HKEX表头结构变化，未将响应当作完整数据")
    events = []
    relevant_rows = 0
    dated_rows = 0
    for row in parser.rows:
        if not row or not _DATE.fullmatch(row[0]):
            if row and re.match(r"\d", row[0]) and len(row) > max(header.values()):
                raise ValueError("HKEX日期格式变化，拒绝静默丢失数据行")
            continue
        dated_rows += 1
        if len(row) <= max(header.values()):
            raise ValueError("HKEX数据行列数不完整，拒绝静默丢失")
        meeting_date = dt.datetime.strptime(row[header["BM DATE"]], "%d/%m/%Y").date().isoformat()
        name = row[header["STOCK SHORT NAME"]]
        code = row[header["CODE"]]
        purpose = row[header["PURPOSE"]]
        period = row[header["PERIOD"]] if "PERIOD" in header else ""
        if not _EARNINGS.search(purpose):
            continue
        if not name or not re.fullmatch(r"\d{1,5}", code):
            raise ValueError("HKEX业绩董事会行缺少有效公司名或证券代码")
        relevant_rows += 1
        security_code = code.zfill(5)
        digest = hashlib.sha256("|".join((source_id, security_code, meeting_date, purpose, period)).encode()).hexdigest()[:20]
        events.append({
            "id": "hk-bmn-" + digest,
            "title": name + " 业绩董事会",
            "category": "earnings",
            "market": "港股",
            "date": meeting_date,
            "time": None,
            "timezone": "Asia/Hong_Kong",
            "all_day": True,
            "status": "confirmed",
            "source_url": source_url,
            "source_name": source_name,
            "source_checked_at": checked_at,
            "source_asof": source_asof,
            "company": {"name": name, "ticker": security_code + ".HK", "market_cap": None, "currency": "HKD", "cap_asof": None},
            "details": {
                "board": board,
                "purpose": purpose,
                "period": period,
                "source_asof": source_asof,
                "source_asof_original": asof_match.group(1),
                "all_day": True,
                "date_basis": "香港当地董事会日期；跨多日会议仅列开始日，未提供精确会议或财报发布时间",
                "confirmation_scope": "仅确认官方汇总列示的业绩董事会安排；不等于财报已公布或保证当天某个时刻公布，日程仍可能变更",
                "coverage": "当前官方汇总表非穷尽全市场名单；应复核发行人原始公告",
                "market_cap_status": "市值未接入，不估填、不以0代替未知",
            },
        })
    unique = {event["id"]: event for event in events}
    return {"events": sorted(unique.values(), key=lambda e: (e["date"], e["company"]["ticker"], e["id"])),
            "source_asof": source_asof, "source_asof_original": asof_match.group(1),
            "dated_rows": dated_rows, "earnings_rows": relevant_rows}


def _read_cache(path):
    try:
        if path.stat().st_size > MAX_CACHE_BYTES:
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        if (not isinstance(data, dict) or data.get("version") != 1 or not isinstance(data.get("events"), list)
                or not isinstance(data.get("source"), dict)):
            return None
        if not all(isinstance(event, dict) and isinstance(event.get("id"), str)
                   and isinstance(event.get("date"), str) and isinstance(event.get("company"), dict)
                   for event in data["events"]):
            return None
        saved = dt.datetime.fromisoformat(data["saved_at"])
        if saved.tzinfo is None:
            return None
        return data
    except (OSError, ValueError, TypeError, KeyError):
        return None


def _write_cache(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def _refresh_source(spec, cache_dir):
    source_id, name, url, board = spec
    path = Path(cache_dir) / (source_id + ".json")
    old = _read_cache(path)
    checked_at = _now_iso()
    if old:
        age = (dt.datetime.now(UTC) - dt.datetime.fromisoformat(old["saved_at"])).total_seconds()
        if 0 <= age < CACHE_SECONDS:
            source = dict(old["source"], cache_used=True, last_success=old["saved_at"])
            return copy.deepcopy(old["events"]), source
    try:
        result = _parse_html(_fetch_html(url), source_id, name, url, board, checked_at)
        source = {"id": source_id, "name": name, "status": "ok", "url": url,
                  "last_success": checked_at, "source_asof": result["source_asof"],
                  "source_asof_original": result["source_asof_original"],
                  "coverage": COVERAGE, "event_count": len(result["events"]),
                  "dated_rows": result["dated_rows"], "earnings_rows": result["earnings_rows"],
                  "cache_used": False, "error": None}
        _write_cache(path, {"version": 1, "saved_at": checked_at, "events": result["events"], "source": source})
        return result["events"], source
    except Exception as exc:
        error = f"{type(exc).__name__}: {str(exc)[:240]}"
        if old:
            events = copy.deepcopy(old["events"])
            for event in events:
                event["data_stale"] = True
                event.setdefault("details", {})["刷新状态"] = "联网刷新失败，保留上次成功缓存；不可当作最新确认"
            return events, dict(old["source"], status="cached", last_success=old["saved_at"], cache_used=True, error=error)
        return [], {"id": source_id, "name": name, "status": "error", "url": url,
                    "last_success": None, "source_asof": None, "coverage": COVERAGE,
                    "event_count": 0, "cache_used": False, "error": error}


def refresh_hk(start_date, end_date, cache_dir):
    """Return requested dates, while caching *all* rows from both official tables."""
    start = dt.date.fromisoformat(str(start_date)).isoformat()
    end = dt.date.fromisoformat(str(end_date)).isoformat()
    if start > end:
        raise ValueError("起始日期不能晚于结束日期")
    all_events, sources = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(_refresh_source, spec, cache_dir) for spec in SOURCES]
        for future in futures:
            events, source = future.result()
            all_events.extend(event for event in events if start <= event.get("date", "") <= end)
            sources.append(source)
    unique = {event["id"]: event for event in all_events}
    return {"events": sorted(unique.values(), key=lambda e: (e["date"], e["company"]["ticker"], e["id"])),
            "sources": sources, "fetched_at": _now_iso()}
