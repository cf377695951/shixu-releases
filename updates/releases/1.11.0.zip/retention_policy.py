"""A failed source cannot erase previously observed schedules. Evidence stays old."""
from __future__ import annotations
import copy
import re

def event_source(event,start,end):
    eid=str(event.get('id',''));url=str(event.get('source_url',''))
    if eid.startswith('nasdaq-'):return f'nasdaq-{start}-{end}'
    if eid.startswith('east-earnings-'):return f'east-earnings-{start}-{end}'
    if eid.startswith('east-unlock-'):return f'east-unlock-{start}-{end}'
    if event.get('category')=='ipo':return 'ipo-'+('bse' if event.get('ipo_market')=='北交所' else 'main')+'-'+str(event.get('ipo_kind'))
    if 'bls.gov' in url:return 'bls'
    if 'bea.gov' in url:return 'bea'
    if 'stats.gov.cn' in url:return 'nbs-calendar'
    if 'deribit.com' in url:return 'deribit-'+('ETH' if 'ETH' in str(event.get('title','')) else 'BTC')
    if 'hkexnews.hk' in url:return 'hkex_board_gem' if 'gem' in url else 'hkex_board_main'
    if eid.startswith('fed-public-'):
        original=(event.get('details') or {}).get('官方美东日期') or event.get('date','')
        return 'fed-public-'+str(original)[:7]
    return None

def retain_failed_sources(result,previous,start,end):
    current={e['id']:e for e in result.get('events',[])}
    prior_sources={s.get('id'):s for s in previous.get('sources',[])}
    statuses={s.get('id'):s for s in result.get('sources',[])}
    retained={}
    for item in previous.get('events',[]):
        if item['id'] in current:continue
        source_id=event_source(item,start,end);source=statuses.get(source_id)
        if not source or source.get('status') not in ('error','failed','cached'):continue
        event=copy.deepcopy(item);event['data_stale']=True
        event.setdefault('details',{})['刷新状态']='该来源本次联网失败，保留上次已获取日程；原核实时间未变，不代表最新公告'
        current[event['id']]=event;retained[source_id]=retained.get(source_id,0)+1
    for source_id,count in retained.items():
        source=statuses[source_id];old=prior_sources.get(source_id,{})
        source.update(status='cached',retained_stale_records=source.get('retained_stale_records',0)+count)
        source['last_success']=source.get('last_success') or old.get('last_success')
        source['cache_used']=True
    result['events']=list(current.values())
    return result
