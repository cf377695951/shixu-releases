"""App-owned market-cap refresh loop; no operating-system task or auto-start."""
from __future__ import annotations
import copy
import datetime as dt
import json
import math
from pathlib import Path
import threading
import time
from quotes import refresh_quotes,quote_key,_ny_timezone

UTC=dt.timezone.utc
BJ=dt.timezone(dt.timedelta(hours=8))
INTERVAL=1800
RETRY=900

class QuoteService:
    def __init__(self,cache_dir,companies,holidays=None,offline=False):
        self.cache=Path(cache_dir);self.cache.mkdir(parents=True,exist_ok=True)
        self.companies=companies;self.holidays=holidays or [];self.offline=offline
        self.lock=threading.RLock();self.values={};self.source={};self.running=False;self.closed=False
        # Published quote objects are immutable. A completed batch advances the
        # revision so readers can reuse projections until actual data changes.
        self.revision=0
        self.last_attempt=0.;self.last_market={};self.stop=threading.Event();self.timer=None
        for file in [Path(__file__).parent/'initial_quotes.json',self.cache/'quote_state.json']:
            try:
                if file.stat().st_size>40*1024*1024:continue
                data=json.loads(file.read_text(encoding='utf-8'))
                for key,q in data.get('quotes',{}).items():
                    if dt.datetime.fromisoformat(q['source_checked_at']).tzinfo is not None and quote_key(q)==key and math.isfinite(float(q['market_cap'])) and q['market_cap']>0:
                        old=self.values.get(key)
                        if not old or q.get('source_checked_at','')>old.get('source_checked_at',''):self.values[key]=q
                if data.get('source'):self.source=data['source']
            except (OSError,ValueError,KeyError,TypeError):continue
        target=self.cache/'total_market_caps.json'
        if self.values and not target.exists():self._write(target,{'quotes':self.values})
    def _write(self,path,data):
        temp=path.with_name(path.name+'.service.tmp')
        temp.write_text(json.dumps(data,ensure_ascii=False,allow_nan=False),encoding='utf-8');temp.replace(path)
    def start(self):
        if self.offline or self.timer:return
        self.timer=threading.Thread(target=self._clock,name='calendar-cap-clock',daemon=True);self.timer.start()
    def close(self):self.closed=True;self.stop.set()
    def _clock(self):
        while not self.stop.wait(30):
            if self.closed:return
            try:self.request()
            except Exception as exc:
                with self.lock:self.source=dict(self.source,status='error',error='市值后台检查失败，将自动重试：'+str(exc)[:150])
    def _market_open(self,market,now=None):
        now=(now or dt.datetime.now(BJ)).astimezone(BJ)
        if market=='美股':
            rough=(now.astimezone(UTC)-dt.timedelta(hours=5)).replace(tzinfo=None)
            local=now.astimezone(_ny_timezone(rough))
        else:local=now
        day=local.date().isoformat();mins=local.hour*60+local.minute
        if local.weekday()>4:return False
        closed=any(e.get('market')==market and e.get('date')==day and (e.get('details') or {}).get('session')=='closed' for e in self.holidays)
        if closed:return False
        half=any(e.get('market')==market and e.get('date')==day and (e.get('details') or {}).get('session') in ('early_close','half_day') for e in self.holidays)
        if market=='美股':return 570<=mins<(780 if half else 960)
        if market=='港股':return 570<=mins<720 or (not half and 780<=mins<960)
        return 570<=mins<690 or 780<=mins<900
    def request(self,force=False):
        if self.offline or self.closed:return False
        ticks=time.monotonic()
        # Polling/status requests must not scan thousands of companies when a
        # batch is already running or its retry interval has not elapsed.
        with self.lock:
            if self.running:return False
            if not force and self.last_attempt and ticks-self.last_attempt<RETRY:return False
        companies=self.companies();now=dt.datetime.now(UTC);ticks=time.monotonic()
        open_markets={m:self._market_open(m) for m in ('A股','美股','港股')}
        with self.lock:
            if self.running:return False
            missing=[];due=[]
            for company in companies:
                try:key=quote_key(company)
                except ValueError:continue
                market=key.split(':',1)[0]
                q=self.values.get(key)
                if not q:missing.append(company)
                else:
                    try:age=(now-dt.datetime.fromisoformat(q['source_checked_at'])).total_seconds()
                    except (ValueError,TypeError,KeyError):age=INTERVAL+1
                    if force or (open_markets.get(market,False) and age>=INTERVAL):due.append(company)
            if force:chosen=companies
            elif self.last_attempt and ticks-self.last_attempt<RETRY:return False
            else:chosen=missing+due
            if not chosen:return False
            self.running=True;self.last_attempt=ticks
            threading.Thread(target=self._refresh,args=(chosen,),name='calendar-market-caps',daemon=True).start()
            return True
    def _refresh(self,companies):
        try:
            result=refresh_quotes(companies,self.cache,force=True)
            with self.lock:
                self.values.update(result.get('quotes',{}));previous_success=self.source.get('last_success');self.source=result.get('source',{})
                if not self.source.get('last_success'):self.source['last_success']=previous_success
                self.revision+=1
                state={'quotes':dict(self.values),'source':dict(self.source)}
            # Slow Windows disks/antivirus must not hold the reader lock while
            # serializing and writing the complete market-cap cache.
            self._write(self.cache/'quote_state.json',state)
        except Exception as exc:
            with self.lock:self.source=dict(self.source,status='error',error='市值刷新失败，已保留上次行情并将自动重试：'+str(exc)[:180])
        finally:
            with self.lock:self.running=False
    def snapshot(self):
        """One consistent read of immutable quote records, without disk I/O."""
        with self.lock:return self.revision,dict(self.values)
    def decorate(self,events,quotes=None):
        if quotes is None:_,quotes=self.snapshot()
        for e in events:
            c=e.get('company')
            if not c:continue
            try:key=quote_key(dict(c,market=e.get('market')))
            except ValueError:continue
            q=quotes.get(key)
            if not q:
                c['quotes_status']='retrying';c['cap_status']='retrying'
                c['cap_update_note']='程序正在自动联网补齐；数据源失败会自动重试，无需手动填写'
                continue
            for field in ('market_cap','currency','cap_asof','cap_source_url','cap_source_checked_at','cap_stale','cap_scope','cap_method'):
                c[field]=q.get(field)
            c['quotes_status']=q.get('status','ok');c['security_name']=q.get('security_name')
            e.setdefault('details',{})['市值口径']=q.get('cap_scope','')
            e['details']['市值行情时点（北京时间）']=q.get('cap_asof')
            e['details']['市值数据源']=q.get('source_name')
            e['details']['市值自动刷新']='交易时每30分钟后台读取；非交易时保留最近行情，失败自动重试；行情时点和程序读取时点分别保留'
        return events
    def status(self):
        with self.lock:
            source=copy.deepcopy(self.source); count=len(self.values);running=self.running
            last_success=max([q.get('source_checked_at') or '' for q in self.values.values()],default='') or source.get('last_success')
            if last_success:source['last_success']=last_success
        if source.get('errors'):source['errors_summary']=f"{len(source['errors'])}个代码本次未更新，自动重试";source.pop('errors',None)
        source.pop('missing',None)
        return {'refreshing':running,'last_success':source.get('last_success'),'next_refresh':None,
                'interval_seconds':INTERVAL,'available_count':count,'error':source.get('error'),'source':source,'offline':self.offline,'note':'交易时每30分钟刷新；未接通代码自动重试，非交易时保留最近行情'}
