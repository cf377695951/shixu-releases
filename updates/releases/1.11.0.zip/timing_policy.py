"""V1.1 time-evidence policy. All main-calendar times are Beijing (UTC+8).

An official meeting date is not a monetary-policy release timestamp. A trading
session is not a company's promised earnings publication window. Missing timing
is placed in pending rather than assigned an invented minute.
"""
from __future__ import annotations
import calendar
from concurrent.futures import ThreadPoolExecutor
import copy
import datetime as dt
import html
import json
import os
from pathlib import Path
import re
import threading
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

UTC=dt.timezone.utc
BJ=dt.timezone(dt.timedelta(hours=8),'Asia/Shanghai')
FED_ROOT='https://www.federalreserve.gov'
FED_URL=FED_ROOT+'/newsevents/{year}-{month}.htm'
# These four schedule times were checked against the corresponding Fed monthly
# calendars on 2026-10-28. Never replace this evidence date with a later read time.
FIXTURE_CHECKED_AT='2026-10-28T11:58:46+00:00'
MONTHS={name.lower():i for i,name in enumerate(calendar.month_name) if name}
FIXTURE=((2026,10,28,14,0,'decision'),(2026,10,28,14,30,'press'),
         (2026,12,9,14,0,'decision'),(2026,12,9,14,30,'press'))


def _now():return dt.datetime.now(UTC).isoformat(timespec='seconds')

def _tz(name, local):
    name={'US/Eastern':'America/New_York','US-Eastern':'America/New_York','GMT':'UTC','UTC+8':'Asia/Shanghai','UTC+08:00':'Asia/Shanghai'}.get(name,name)
    if name in ('UTC','Etc/UTC'):return UTC
    if name in ('Asia/Shanghai','Asia/Hong_Kong'):return BJ
    try:return ZoneInfo(name)
    except ZoneInfoNotFoundError:
        if name!='America/New_York' or local.year<2007:raise ValueError('来源时区缺少可靠转换规则')
        march=dt.date(local.year,3,1);nov=dt.date(local.year,11,1)
        start=march+dt.timedelta(days=(6-march.weekday())%7+7)
        end=nov+dt.timedelta(days=(6-nov.weekday())%7)
        if (local.date()==start and local.hour==2) or (local.date()==end and local.hour==1):
            raise ValueError('美东夏令时切换时刻不明确，需源UTC偏移')
        is_dst=dt.datetime.combine(start,dt.time(3))<=local<dt.datetime.combine(end,dt.time(2))
        return dt.timezone(dt.timedelta(hours=-4 if is_dst else -5))


def local_datetime(date, time, timezone):
    if not re.fullmatch(r'\d{2}:\d{2}(?::\d{2})?',str(time)):raise ValueError('不是明确的时刻')
    d=dt.date.fromisoformat(str(date)[:10]);t=dt.time.fromisoformat(time)
    naive=dt.datetime.combine(d,t)
    zone=_tz(timezone,naive)
    first=naive.replace(tzinfo=zone,fold=0);second=naive.replace(tzinfo=zone,fold=1)
    if first.utcoffset()!=second.utcoffset():raise ValueError('夏令时切换时刻存在歧义或不存在，请使用明确UTC偏移')
    return first.astimezone(BJ)


def _iso(value):
    parsed=dt.datetime.fromisoformat(str(value).replace('Z','+00:00'))
    if parsed.tzinfo is None:raise ValueError('时间戳必须附UTC偏移')
    return parsed.astimezone(BJ)


def _window_label(start,end):
    if end is None:return start.strftime('%H:%M')
    if end<=start:raise ValueError('时间范围结束须晚于开始')
    if start.date()==end.date():return start.strftime('%H:%M')+'–'+end.strftime('%H:%M')
    if end.date()==start.date()+dt.timedelta(days=1):
        if end.time()==dt.time(0):return start.strftime('%H:%M')+'–24:00'
        return start.strftime('%H:%M')+'–次日'+end.strftime('%H:%M')
    return start.strftime('%m/%d %H:%M')+'–'+end.strftime('%m/%d %H:%M')


def _place(event,start,end=None,precision='exact',explanation=None):
    e=copy.deepcopy(event)
    details=e.setdefault('details',{})
    for key in ('date_basis','日期显示口径','时间显示口径'):
        details.pop(key,None)
    for key in list(details):
        value=details[key]
        if isinstance(value,str) and any(p in value for p in ('全天日程保留当地日期','跨国全天日程保留当地日期','不平移为北京时间','不作跨时区平移','纽约全天日期不平移')):
            details.pop(key,None)
    details.setdefault('原始日期',str(e.get('date','')))
    details.setdefault('原始时刻',str(e.get('time','')))
    details.setdefault('原始时区',str(e.get('timezone','')))
    e.update(date=start.date().isoformat(),time=_window_label(start,end),timezone='Asia/Shanghai',
             start_at=start.isoformat(timespec='seconds'),end_at=end.isoformat(timespec='seconds') if end else None,
             end_date=end.date().isoformat() if end else start.date().isoformat(),date_end=end.date().isoformat() if end else start.date().isoformat(),time_precision=precision,
             time_label=_window_label(start,end)+' 北京时间（UTC+8）',time_display=_window_label(start,end)+' 北京时间（UTC+8）'+(' · 仅日期级安排' if precision=='date_range' else ' · 平台预计宽时段' if precision=='broad_window' else ''),date_basis='beijing_time')
    if e.get('session_windows'):
        sessions=[]
        for segment in e['session_windows']:
            if not isinstance(segment,dict):raise ValueError('分段时段结构无效')
            begin=_iso(segment.get('start_at') or segment.get('start'))
            finish=_iso(segment.get('end_at') or segment.get('end'))
            if finish<=begin:raise ValueError('分段时段结束不晚于开始')
            sessions.append((begin,finish,segment))
        sessions.sort(key=lambda x:x[0])
        if any(sessions[i][0]<sessions[i-1][1] for i in range(1,len(sessions))):raise ValueError('分段时段发生重叠')
        if not sessions:raise ValueError('分段时段为空')
        labels=[_window_label(a,b) for a,b,_ in sessions]
        e['session_windows']=[dict(raw,start=a.isoformat(timespec='seconds'),end=b.isoformat(timespec='seconds'),start_at=a.isoformat(timespec='seconds'),end_at=b.isoformat(timespec='seconds'),label=label) for (a,b,raw),label in zip(sessions,labels)]
        e.update(date=sessions[0][0].date().isoformat(),start_at=sessions[0][0].isoformat(timespec='seconds'),end_at=sessions[-1][1].isoformat(timespec='seconds'),end_date=sessions[-1][1].date().isoformat(),date_end=sessions[-1][1].date().isoformat(),time=' / '.join(labels),time_label=' / '.join(labels)+' 北京时间（UTC+8）',time_display=' / '.join(labels)+' 北京时间（UTC+8）',time_precision='range')
        details['分段时段说明']='仅所列各段为申报/交易窗口，段间（包括午休）不属于该窗口；start_at/end_at为整体覆盖边界。'
    e['all_day']=e['time_precision']=='date_range'
    e['display_time']=e['time_display']
    if explanation:details['时间口径']=explanation
    if e.get('session_windows'):details['时间口径']='分段有效时段以北京时间列示；整体首末边界不表示午间连续开放。'
    details['显示时区']='北京时间（UTC+8）'
    return e


def _fomc_event(year,month,day,hour,minute,kind,checked_at,source_url):
    source_date=dt.date(year,month,day).isoformat();t=f'{hour:02d}:{minute:02d}'
    e={'id':f'fed-public-{source_date}-{kind}','title':'FOMC利率决议公布' if kind=='decision' else ('FOMC新闻发布会' if kind=='press' else 'FOMC会议纪要公布'),
       'category':'macro','market':'美国','date':source_date,'time':t,'timezone':'America/New_York',
       'source_url':source_url,'source_name':'美联储官方月度公开日历','status':'confirmed','source_checked_at':checked_at,
       'details':{'事件类型':'利率决议公开发布' if kind=='decision' else ('新闻发布会开始' if kind=='press' else '会议纪要公开发布'),
                  '官方美东日期':source_date,'官方美东时间':t,'官方时区':'America/New_York',
                  '会议日期与公布时点':'仅列公开决议/记者会/纪要时点；内部会议首末日不再作为重复决议放入主日历',
                  '安排状态':'官方当前公布安排，日后仍可能更改；不代表政策结果'}}
    return _place(e,local_datetime(source_date,t,'America/New_York'),explanation='已从官方美东明确时刻换算北京时间，包含当日夏令时规则。')


def build_fomc_events():
    """Known official public times; snapshot only, not an inference from meeting days."""
    return [_fomc_event(y,m,d,h,n,k,FIXTURE_CHECKED_AT,FED_URL.format(year=y,month=calendar.month_name[m].lower())) for y,m,d,h,n,k in FIXTURE]


def _plain(text):return re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]*>',' ',text))).strip()


def parse_fed_monthly(text,year,month,checked_at=None):
    """Parse actual time/date columns only within the Fed FOMC monthly section."""
    heading=re.search(r'<h4[^>]*>\s*FOMC Meetings\s*</h4>',text,re.I)
    if not heading:raise ValueError('Fed月历未找到FOMC栏，不能据此推定无事件')
    rest=text[heading.end():]
    following=re.search(r'<h4\b',rest,re.I)
    if following:rest=rest[:following.start()]
    # Official no-JS rows use three explicit columns. Ignore link dates and all
    # other release calendars so a timestamp cannot attach to a wrong event.
    row_pattern=r'<div[^>]*class="col-xs-2"[^>]*>((?:(?!<div\b).)*?)</div>\s*<div[^>]*class="col-xs-7"[^>]*>((?:(?!<div\b).)*?)</div>\s*<div[^>]*class="col-xs-3"[^>]*>((?:(?!<div\b).)*?)</div>'
    output=[]
    for row in re.finditer(row_pattern,rest,re.S|re.I):
        time_text,title_text,dates=_plain(row[1]),_plain(row[2]),_plain(row[3])
        if 'FOMC Press Conference' in title_text:kind='press'
        elif re.search(r'\bFOMC Meeting\b',title_text):kind='decision'
        elif 'FOMC Minutes' in title_text:kind='minutes'
        else:continue
        match=re.fullmatch(r'(\d{1,2}):(\d{2})\s*([ap])\.?m\.?',time_text,re.I)
        if not match or not re.fullmatch(r'\d{1,2}(?:\s*,\s*\d{1,2})*',dates):raise ValueError('Fed FOMC公开时刻/日期格式变化，拒绝猜测')
        hour=int(match[1]);minute=int(match[2])
        if not 1<=hour<=12 or minute>59:raise ValueError('Fed时间非法')
        hour=hour%12+(12 if match[3].lower()=='p' else 0)
        for raw_day in dates.split(','):
            day=int(raw_day.strip());dt.date(year,month,day)
            output.append(_fomc_event(year,month,day,hour,minute,kind,checked_at or _now(),FED_URL.format(year=year,month=calendar.month_name[month].lower())))
    if not output:raise ValueError('Fed FOMC栏无可核明确时刻，未视作成功刷新')
    return list({e['id']:e for e in output}.values())


class _FedRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        p=urllib.parse.urlsplit(newurl)
        if p.scheme!='https' or p.hostname!='www.federalreserve.gov':raise ValueError('Fed月历重定向越过官方源')
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def _fetch_fed(year,month):
    url=FED_URL.format(year=year,month=calendar.month_name[month].lower())
    request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (EventAtlas personal calendar)','Accept':'text/html','Accept-Encoding':'identity'})
    with urllib.request.build_opener(_FedRedirect()).open(request,timeout=12) as response:
        body=response.read(4*1024*1024+1)
        if len(body)>4*1024*1024:raise ValueError('Fed月历响应超限')
    return parse_fed_monthly(body.decode('utf-8-sig'),year,month,checked_at=_now())


def refresh_fomc(start_date,end_date,cache_dir):
    """Real monthly refresh, bounded and isolated, no inferred future time slots."""
    start=dt.date.fromisoformat(start_date);end=dt.date.fromisoformat(end_date)
    if end<start or (end-start).days>64:raise ValueError('按月刷新FOMC，范围上限65天')
    folder=Path(cache_dir);folder.mkdir(parents=True,exist_ok=True)
    first=(start-dt.timedelta(days=1)).replace(day=1);last=end.replace(day=1)
    months=[];current=first
    while current<=last:
        months.append((current.year,current.month))
        current=(current.replace(day=28)+dt.timedelta(days=4)).replace(day=1)
    def load(pair):
        y,m=pair;path=folder/f'fed-public-{y}-{m:02d}.json';old=None
        try:
            if path.stat().st_size<=4*1024*1024:old=json.loads(path.read_text(encoding='utf-8'))
            if old and (dt.datetime.now(UTC)-dt.datetime.fromisoformat(old['last_success'])).total_seconds()<900:return old['events'],dict(old['source'],cache_used=True)
        except (OSError,ValueError,TypeError,KeyError):old=None
        try:
            items=_fetch_fed(y,m);checked=_now()
            source={'id':f'fed-public-{y}-{m:02d}','name':f'Fed {y}-{m:02d}公开时点','status':'ok','last_success':checked,'source_url':FED_URL.format(year=y,month=calendar.month_name[m].lower()),'coverage':'官方月历实际列明的决议、记者会与纪要时刻，不从两日会期外推','event_count':len(items),'error':None}
            data={'events':items,'source':source,'last_success':checked}
            temporary=path.with_name(path.name+f'.{os.getpid()}.{threading.get_ident()}.tmp');temporary.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');os.replace(temporary,path)
            return items,source
        except Exception as exc:
            items=copy.deepcopy(old.get('events',[])) if old else [e for e in build_fomc_events() if e['details']['官方美东日期'].startswith(f'{y}-{m:02d}')]
            for e in items:e['data_stale']=True;e.setdefault('details',{})['刷新状态']='本次官方月历刷新失败，保留原核实快照；未冒称最新确认'
            return items,{'id':f'fed-public-{y}-{m:02d}','name':f'Fed {y}-{m:02d}公开时点','status':'cached' if items else 'error','last_success':old.get('last_success') if old else (FIXTURE_CHECKED_AT if items else None),'source_url':FED_URL.format(year=y,month=calendar.month_name[m].lower()),'coverage':'未用未公布月份/HTTP失败推断无FOMC事件','event_count':len(items),'error':str(exc)[:250]}
    with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(load,months))
    events={e['id']:e for items,_ in results for e in items if start_date<=e['date']<=end_date}
    return {'events':sorted(events.values(),key=lambda e:(e['date'],e['start_at'],e['id'])),'sources':[s for _,s in results],'fetched_at':_now()}


def _original_earnings_date(e):
    details=e.get('details') or {}
    source_day=details.get('美东财报日期') or details.get('source_date') or details.get('original_date')
    if source_day:return dt.date.fromisoformat(str(source_day)[:10])
    day=dt.date.fromisoformat(e['date'])
    if e.get('date_basis')=='beijing_day_from_after_hours':day-=dt.timedelta(days=1)
    return day


def _pending(e,reason):
    e=copy.deepcopy(e);e['timing_status']='pending';e['pending_reason']=reason
    if not isinstance(e.get('details'),dict):e['details']={}
    e['details']['时间核验状态']=reason
    return e


def normalize_events(events,allow_date_level=True):
    """Return {events,pending}; main events have a proved point/range in UTC+8.

    Date-level China/HK notices get the full 00:00–24:00 date envelope, explicitly
    marked date_range, never an invented hour. Nasdaq phase tags get a broad
    local-calendar-day bound, not an invented post-close half hour.
    """
    main={};pending=[];old_fed=[]
    for raw in events:
        e=copy.deepcopy(raw);details=e.get('details') or {}
        try:
            if not isinstance(details,dict):raise ValueError('详情结构无效')
            e['details']=details
            # Old two-day meeting markers have no release time and are removed.
            old_fed_marker=('fomccalendars.htm' in str(e.get('source_url','')) or str(e.get('id','')).startswith('fed-fomc-')) and not e.get('start_at') and not e.get('time')
            if old_fed_marker:
                old_fed.append(e);continue
            if e.get('start_at'):
                out=_place(e,_iso(e['start_at']),_iso(e['end_at']) if e.get('end_at') else None,e.get('time_precision') or ('range' if e.get('end_at') else 'exact'),details.get('时间口径'))
            elif re.fullmatch(r'\d{2}:\d{2}(?::\d{2})?',str(e.get('time',''))):
                out=_place(e,local_datetime(e['date'],e['time'],e.get('timezone')),explanation=details.get('时间口径') or '来源给出明确时刻，统一以北京时间（UTC+8）展示。')
            elif e.get('category')=='earnings' and e.get('market')=='美股':
                if not e.get('timezone'):raise ValueError('美股披露时段缺少来源时区')
                phase=str(details.get('发布时段') or e.get('release_phase') or e.get('time') or '')
                day=_original_earnings_date(e)
                if '盘前' in phase or phase in ('pre-market','before-market','time-pre-market'):
                    start=local_datetime(day.isoformat(),'00:00','America/New_York');end=local_datetime(day.isoformat(),'09:30','America/New_York')
                    explanation='平台只提供该美东日期盘前标签：显示该当地日00:00至常规开盘09:30的宽范围；不承诺具体公司在某一小时内披露。'
                elif '盘后' in phase or phase in ('after-hours','after-market','time-after-hours'):
                    start=local_datetime(day.isoformat(),'16:00','America/New_York');end=local_datetime((day+dt.timedelta(days=1)).isoformat(),'00:00','America/New_York')
                    explanation='平台只提供该美东日期盘后标签：显示常规收盘16:00至该当地日结束的宽范围；不是某公司已确认的半小时/一小时披露窗口。'
                else:
                    pending.append(_pending(e,'来源没有具体发布时间或可核实的盘前/盘后范围，移入时间待核列表，不占主日历。'));continue
                e['status']='estimated';out=_place(e,start,end,'broad_window',explanation)
            elif allow_date_level and (e.get('category') in ('holiday','season','politics','unlock','ipo') or (e.get('category')=='earnings' and e.get('market') in ('A股','港股'))):
                day=dt.date.fromisoformat(e['date']);zone=e.get('timezone')
                if not zone:raise ValueError('日期级范围缺少来源时区')
                if e.get('category')=='holiday' and zone=='America/New_York' and e.get('market') in ('美股','美国'):
                    start=local_datetime(day.isoformat(),'09:30',zone);end=local_datetime(day.isoformat(),'16:00',zone)
                    out=_place(e,start,end,'range','美国现金股票常规交易时段休市：原美东09:30–16:00已转换为北京时段；不是纽约全天日期直接当作北京日期。')
                    out['details']['时段依据']='https://www.nasdaq.com/market-activity/stock-market-holiday-schedule'
                    main[out['id']]=out;continue
                start=local_datetime(day.isoformat(),'00:00',zone);end=local_datetime((day+dt.timedelta(days=1)).isoformat(),'00:00',zone)
                explanation='来源仅确认日历日期，范围是该源日期的完整24小时换算到北京；不表示已确认某一小时的公布时刻。'
                if e.get('category')=='politics' and zone=='America/New_York':explanation+=' 这是官方当地投票日的日期范围，不是所有州投票站统一开放时段。'
                if e.get('category')=='earnings':
                    if '日期级披露安排' not in e['title']:e['title']+='（日期级披露安排）'
                    explanation='来源仅确认披露/业绩董事会日期：北京00:00–24:00日期级范围；董事会日期不等于精确财报发布时间。'
                out=_place(e,start,end,'date_range',explanation)
            else:
                pending.append(_pending(e,'未获得具体时刻或有证据的时间范围，未给该日期虚构发布时刻。'));continue
            main[out['id']]=out
        except (ValueError,KeyError,TypeError,OverflowError) as exc:
            pending.append(_pending(e,'时间证据校验失败：'+str(exc)))
    fixtures=build_fomc_events()
    replaced_months=set()
    for old in old_fed:
        old_day=str((old.get('details') or {}).get('会议结束（美东日期）') or old.get('date',''))[:10]
        month=old_day[:7]
        found=[e for e in fixtures if e['details']['官方美东日期'].startswith(month)]
        if found:
            if month not in replaced_months:
                for out in found:main.setdefault(out['id'],out)
                replaced_months.add(month)
        else:
            pending.append(_pending(old,'原始记录仅为内部会议日期；尚无本场官方公开发布时刻，已从主日历移出。'))
    return {'events':sorted(main.values(),key=lambda e:(e['date'],e['start_at'],e['id'])),'pending':pending}
