(function () {
  'use strict';
  // Diagnostics stay inside this application. No event text, securities,
  // holdings, account data, query strings or credentials are recorded.
  const started=performance.now(),measures=new Map(),payloads=new Map();
  const longTasks=[],frames=[],lags=[];
  let currentPhase='启动',paintPending=false,lastPaint=0,sessionToken=null,previousRun=null,saving=false;
  const bounded=(list,value,max=60)=>{list.push(value);if(list.length>max)list.splice(0,list.length-max);};
  const safeLabel=value=>String(value||'未标注').replace(/[?&#].*$/,'').slice(0,80);
  const round=value=>Math.round(value*100)/100;
  function mark(label,milliseconds){
    if(!Number.isFinite(milliseconds)||milliseconds<0)return;
    label=safeLabel(label);let item=measures.get(label);
    if(!item){if(measures.size>=40)measures.delete(measures.keys().next().value);item={count:0,total_ms:0,max_ms:0,last_ms:0};measures.set(label,item);}
    item.count++;item.total_ms+=milliseconds;item.max_ms=Math.max(item.max_ms,milliseconds);item.last_ms=milliseconds;
  }
  function probePaint(){
    if(paintPending||document.hidden)return;
    paintPending=true;const from=performance.now();
    requestAnimationFrame(()=>{lastPaint=performance.now()-from;paintPending=false;mark('下一帧等待',lastPaint);});
  }
  function measure(label,callback){const from=performance.now();try{return callback();}finally{mark(label,performance.now()-from);probePaint();}}
  function payload(label,bytes,count){
    label=safeLabel(label);if(!label.startsWith('/api/'))return;
    if(payloads.size>=16&&!payloads.has(label))payloads.delete(payloads.keys().next().value);
    const old=payloads.get(label)||{requests:0,max_bytes:0,last_bytes:0,last_items:0};
    old.requests++;old.max_bytes=Math.max(old.max_bytes,Number(bytes)||0);old.last_bytes=Number(bytes)||0;old.last_items=Number(count)||0;payloads.set(label,old);
  }
  function phase(label){currentPhase=safeLabel(label);}
  function observe(type,callback){try{if(typeof PerformanceObserver==='function'&&PerformanceObserver.supportedEntryTypes.includes(type)){const observer=new PerformanceObserver(list=>list.getEntries().forEach(callback));observer.observe({type,buffered:true});}}catch{}}
  observe('longtask',entry=>bounded(longTasks,{at_ms:round(entry.startTime),duration_ms:round(entry.duration),phase:currentPhase}));
  observe('long-animation-frame',entry=>{
    const scripts=(entry.scripts||[]).slice(0,4).map(script=>({file:String(script.sourceURL||'').split('/').pop().split('?')[0].slice(0,80),function:String(script.sourceFunctionName||'').slice(0,80),duration_ms:round(script.duration||0)}));
    bounded(frames,{at_ms:round(entry.startTime),duration_ms:round(entry.duration),blocking_ms:round(entry.blockingDuration||0),scripts},30);
  });
  let expected=performance.now()+500;
  const heartbeat=setInterval(()=>{const now=performance.now(),delay=Math.max(0,now-expected);expected=now+500;if(!document.hidden)bounded(lags,{at_ms:round(now-started),lag_ms:round(delay),phase:currentPhase});},500);
  document.addEventListener('visibilitychange',()=>{expected=performance.now()+500;});
  function snapshot(light=false){
    const heap=light?null:performance.memory;
    return {schema:1,app_version:'1.7.0',captured_at:new Date().toISOString(),uptime_ms:round(performance.now()-started),phase:currentPhase,
      measures:Object.fromEntries([...measures].map(([key,item])=>[key,{count:item.count,average_ms:round(item.total_ms/item.count),max_ms:round(item.max_ms),last_ms:round(item.last_ms)}])),
      payloads:Object.fromEntries(payloads),long_tasks:longTasks.slice(),long_animation_frames:frames.slice(),heartbeat:lags.slice(),
      renderer:{visibility:document.visibilityState,dom_nodes:light?null:document.getElementsByTagName('*').length,visible_detail_rows:light?null:document.querySelectorAll('#detailContent .company-row,#dialogContent .company-row').length,viewport:[innerWidth,innerHeight],pixel_ratio:devicePixelRatio,heap_used_mb:heap?round(heap.usedJSHeapSize/1048576):null,heap_limit_mb:heap?round(heap.jsHeapSizeLimit/1048576):null},
      note:'仅本机性能指标；不包含公司/证券、持仓、账户、搜索词或凭据。长任务含页面首次加载，请结合操作时间判断。'};
  }
  async function saveLocal(){
    if(!sessionToken||saving||document.hidden)return;
    saving=true;
    try{await fetch('/api/performance',{method:'POST',headers:{'Content-Type':'application/json','X-Calendar-Token':sessionToken},body:JSON.stringify(snapshot(true)),keepalive:true});}catch{}finally{saving=false;}
  }
  async function setSession(token){
    sessionToken=token;
    try{const response=await fetch('/api/performance',{credentials:'same-origin',cache:'no-store'});if(response.ok)previousRun=(await response.json()).previous||null;}catch{}
    saveLocal();
  }
  window.CalendarPerformance=Object.freeze({measure,mark,payload,phase,snapshot,setSession});
  function show(){
    const target=document.getElementById('diagnosticSummary');if(!target)return;
    const data=snapshot(),maxTask=Math.max(0,...data.long_tasks.map(x=>x.duration_ms)),maxLag=Math.max(0,...data.heartbeat.map(x=>x.lag_ms));
    const text=['运行版本：V'+data.app_version,'页面节点：'+data.renderer.dom_nodes+'；详情行：'+data.renderer.visible_detail_rows,'JS堆内存：'+(data.renderer.heap_used_mb===null?'浏览器未提供':data.renderer.heap_used_mb+' MB'),'已记录长任务：'+data.long_tasks.length+'；最长 '+maxTask+' ms','近期事件循环最大延迟：'+maxLag+' ms','当前阶段：'+data.phase,''];
    for(const [label,item] of Object.entries(data.measures))text.push(label+'：最近 '+item.last_ms+' ms；最大 '+item.max_ms+' ms');
    if(previousRun)text.push('上次保存的阶段：'+String(previousRun.phase||'未标注')+'；保存于 '+String(previousRun.captured_at||''));
    text.push('');for(const [label,item] of Object.entries(data.payloads))text.push(label+'：最近 '+(item.last_bytes/1024).toFixed(1)+' KB；'+item.last_items+'项');
    text.push('');
    for(const item of [...data.long_tasks].sort((a,b)=>b.duration_ms-a.duration_ms).slice(0,5))text.push('长任务 '+item.duration_ms+' ms；阶段 '+item.phase);
    for(const frame of [...data.long_animation_frames].sort((a,b)=>b.blocking_ms-a.blocking_ms).slice(0,5)){text.push('长帧 '+frame.duration_ms+' ms；阻塞 '+frame.blocking_ms+' ms');for(const script of frame.scripts)text.push('  '+script.file+' '+script.function+' '+script.duration_ms+' ms');}
    text.push('','指标包含首次加载。遇到卡顿后可导出诊断文件，文件只保存在本机。');target.textContent=text.join('\n');
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const refresh=document.getElementById('refreshDiagnostic');
    const dialog=document.getElementById('diagnosticDialog'),button=document.getElementById('diagnosticButton'),close=document.getElementById('closeDiagnostic'),save=document.getElementById('exportDiagnostic');
    if(button)button.addEventListener('click',()=>{show();if(dialog&&!dialog.open)dialog.showModal();});
    if(close)close.addEventListener('click',()=>dialog.close());
    if(save)save.addEventListener('click',()=>{const raw=JSON.stringify({...snapshot(),previous_run:previousRun},null,2),blob=new Blob([raw],{type:'application/json'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='calendar-performance-'+new Date().toISOString().slice(0,10)+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
    if(refresh)refresh.addEventListener('click',show);
    const saveTimer=setInterval(saveLocal,15000);
    window.addEventListener('pagehide',()=>{saveLocal();clearInterval(heartbeat);clearInterval(saveTimer);},{once:true});
  });
}());
