(function(){
  'use strict';
  const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fold=v=>String(v||'').normalize('NFKC').toLocaleLowerCase();
  const labels={main:'主快讯',tradfi:'财经',binance:'币安公告',korea:'韩所公告',tier2:'二线上新',tier3:'三线上新',alpha:'币安Alpha',earn:'理财提醒',pricechange:'价格异动',major:'大幅波动',oi:'OI异动',cz:'CZ与何一'};
  const groups={news:['main','tradfi'],exchange:['binance','korea','tier2','tier3','alpha','earn'],market:['pricechange','major','oi','cz']};
  const formatter=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
  function link(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password?u.href:null;}catch{return null;}}
  function clock(value){const d=new Date(value);if(!Number.isFinite(d.getTime()))return{date:'日期未确认',time:'--:--:--'};const p=formatter.formatToParts(d),pick=t=>p.find(x=>x.type===t).value;return{date:pick('month')+'月'+pick('day')+'日',time:pick('hour')+':'+pick('minute')+':'+pick('second')};}
  function remainingText(item,text){const body=String(text||'');return body.startsWith(item.title)?body.slice(item.title.length).trim():body;}
  function cardMarkup(item){const when=clock(item.published_at),url=link(item.url),preview=remainingText(item,item.preview),tags=(item.channels||[]).slice(0,2).map(c=>'<span class="news-tag tag-'+esc(c)+'">'+esc(labels[c]||c)+'</span>').join('');return '<article class="news-card" data-news-card="'+esc(item.id)+'"><header><time datetime="'+esc(item.published_at)+'" title="北京时间 UTC+8">'+when.time+'</time><div>'+tags+(item.live?'<span class="news-live-tag">实时</span>':'')+'</div></header><button class="news-story-title" data-news-story="'+esc(item.id)+'" type="button">'+esc(item.title)+'</button>'+(preview?'<p class="news-preview">'+esc(preview)+'</p>':'')+'<footer><span class="news-source" title="方程式转述，未代表官方核验">'+esc(item.source||'方程式快讯')+'</span><span class="news-coins">'+(item.coins||[]).slice(0,4).map(c=>'<b>'+esc(c)+'</b>').join('')+'</span>'+(url?'<a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">原文 ↗</a>':'')+'</footer></article>';}
  function normalizedLive(value,now=Date.now()){
    if(!value||typeof value!=='object'||typeof value.news_title!=='string'||!Number.isFinite(value.timestamp)||value.timestamp*1000>now+300000||value.timestamp*1000<now-86400000)return null;
    const body=value.news_title.slice(0,6000).trim();if(!body)return null;const url=link(value.url);return{id:'live:'+value.timestamp+':'+body.slice(0,80),url,source_url:url,published_at:new Date(value.timestamp*1000).toISOString(),title:body.split('\n')[0].slice(0,240),preview:body.slice(0,320),body,source:String(value.source_name||'方程式实时').slice(0,80),channels:['main'],coins:(Array.isArray(value.coins_included)?value.coins_included:[]).filter(x=>typeof x==='string'&&/^[a-z0-9._-]{1,20}$/i.test(x)).slice(0,15).map(x=>x.toUpperCase()),live:true};
  }
  function composeColumns(data,live,filters){
    const columns=(data.columns||[]).map(c=>({...c,items:(c.items||[]).slice()})),news=columns.find(c=>c.id==='news');if(!news||!['all','main'].includes(filters.channel))return columns;
    const existing=(data.columns||[]).flatMap(c=>c.items||[]),urls=new Set(existing.flatMap(x=>[x.url,x.source_url].filter(Boolean))),titles=new Set(existing.map(x=>fold(x.title)));
    const extras=live.filter(x=>!urls.has(x.url)&&!titles.has(fold(x.title))&&(!filters.query||fold(x.body+' '+x.source+' '+x.coins.join(' ')).includes(fold(filters.query)))&&(!filters.coin||x.coins.includes(filters.coin.toUpperCase())||fold(x.body).includes(fold(filters.coin))));
    if(news.page===0){news.items=[...extras,...news.items].sort((a,b)=>b.published_at.localeCompare(a.published_at)).slice(0,20);news.total+=extras.length;}
    return columns;
  }
  function detailMarkup(item,status='cached',error=''){
    const when=clock(item.published_at),url=link(item.url),source=link(item.source_url),body=remainingText(item,item.body||item.preview||item.title);return '<div class="news-detail-meta"><span>'+when.date+' '+when.time+' 北京时间 UTC+8</span><span>'+esc(item.source||'方程式快讯')+'</span></div><h2 id="newsDetailTitle">'+esc(item.title)+'</h2>'+(body?'<p class="news-detail-body">'+esc(body)+'</p>':'')+'<div class="news-detail-links">'+(url?'<a class="data-refresh-button" href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+(item.live?'打开消息出处':'打开方程式原文')+' ↗</a>':'')+(source&&source!==url?'<a class="button" href="'+esc(source)+'" target="_blank" rel="noopener noreferrer">消息出处 ↗</a>':'')+'</div><p class="news-detail-status" role="status">'+esc(item.text_truncated?'正文较长，已展示部分内容，可打开原文阅读全部。':error||({refreshing:'正在后台核对完整快讯，已有内容可继续阅读。',ready:'已取得这条快讯的接口正文。',offline:'当前显示本机缓存。',live:'主频道实时转述；可打开来源核对。'}[status]||'当前显示已读取的快讯。'))+'</p><small class="news-detail-note">内容由方程式抓取与翻译；快讯转述与日历里的官方数值核验分别标注。</small>';
  }
  function create(options){
    const $=id=>document.getElementById(id),get=options.getJson;
    const s={active:false,paused:false,data:null,pending:null,live:new Map(),acceptedLive:new Set(),focus:'all',channel:'all',query:'',coin:'',pages:{},controller:null,serial:0,timer:null,ws:null,heartbeat:null,reconnect:null,wsRetry:0,stream:'待连接',detailSerial:0,detailTimer:null,selected:null,revision:null};
    $('newsChannel').innerHTML='<option value="all">全部频道</option>'+Object.entries(labels).map(([k,v])=>'<option value="'+k+'">'+v+'</option>').join('');
    function active(){return s.active&&!s.paused&&!document.hidden&&!options.isAppClosed();}
    function stopStream(){clearInterval(s.heartbeat);clearTimeout(s.reconnect);s.heartbeat=null;s.reconnect=null;const ws=s.ws;s.ws=null;if(ws){ws.onclose=null;ws.onerror=null;ws.onmessage=null;ws.close();}}
    function stop(){clearTimeout(s.timer);clearTimeout(s.detailTimer);s.serial++;if(s.controller)s.controller.abort();s.controller=null;stopStream();}
    function streamStatus(text,connected=false){s.stream=text;$('newsStreamStatus').textContent=text;$('newsStreamStatus').classList.toggle('connected',connected);}
    function showIncoming(){const columns=composeColumns(s.pending||s.data||{},[...s.live.values()],s),old=new Set([...(s.data?.columns||[]).flatMap(c=>c.items||[]).map(x=>x.id),...s.acceptedLive]);let count=columns.flatMap(c=>c.items||[]).filter(x=>!old.has(x.id)).length;const latest=[...s.live.values()].sort((a,b)=>b.published_at.localeCompare(a.published_at))[0];$('newsIncoming').hidden=!count;$('newsIncomingText').textContent=count+' 条新快讯'+(latest?' · '+latest.title.slice(0,75):'');}
    function render(data){
      if(!data)return;
      const columns=composeColumns(data,[...s.live.values()],s);s.acceptedLive=new Set(columns.flatMap(c=>c.items||[]).filter(x=>x.live).map(x=>x.id));$('newsColumns').classList.toggle('single',columns.length===1);
      $('newsColumns').innerHTML=columns.map(col=>{let previous='';const rows=col.items.map(item=>{const day=clock(item.published_at).date,heading=previous!==day?'<div class="news-day-label">'+day+'</div>':'';previous=day;return heading+cardMarkup(item);}).join('');const errors=(data.sources||[]).filter(x=>col.channels.includes(x.key)&&x.status==='error');return '<section class="news-column column-'+col.id+'" aria-label="'+esc(col.label)+'"><header class="news-column-header"><div><span class="news-column-dot"></span><h3>'+esc(col.label)+'</h3><b>'+col.total+'</b></div><small>'+col.channels.map(x=>esc(labels[x])).join(' · ')+'</small></header>'+(errors.length?'<p class="news-column-warning">'+errors.length+' 个频道本轮读取未完成，保留缓存。</p>':'')+'<div class="news-column-list">'+(rows||'<div class="news-empty">'+(data.refreshing?'正在后台读取这个分区…':s.query||s.coin?'最近快讯中没有匹配内容':'这个分区暂未读到快讯')+'</div>')+'</div><nav class="news-pagination" aria-label="'+esc(col.label)+'分页"><button class="button" data-news-page="'+col.id+'" data-page="'+(col.page-1)+'" '+(!col.page?'disabled':'')+'>上一页</button><span>'+(col.page+1)+' / '+col.pages+' 页</span><button class="button" data-news-page="'+col.id+'" data-page="'+(col.page+1)+'" '+(col.page+1>=col.pages?'disabled':'')+'>下一页</button></nav></section>';}).join('');
      s.revision=data.revision;showStatus(data);showIncoming();
    }
    function showStatus(data){const errors=(data.sources||[]).filter(x=>x.status==='error'),last=(data.sources||[]).map(x=>x.last_success_at).filter(Boolean).sort().pop();$('newsSummary').textContent=(data.total||0)+' 条最近快讯 · '+(data.offline?'缓存展示':data.refreshing?'后台更新中':'按时间倒序')+' · '+(s.query||s.coin?'筛选已读取内容':'多频道同条去重');$('newsReadTime').textContent=last?'上次读取 '+clock(last).date+' '+clock(last).time:'';$('newsError').hidden=!errors.length;$('newsError').textContent=errors.length?'部分频道本轮未更新，正在使用上次快讯。网络恢复后会自动重试。涉及：'+errors.slice(0,4).map(x=>x.label).join('、'):'';$('newsRefresh').disabled=Boolean(data.refreshing);}
    function filters(){return new URLSearchParams({focus:s.focus,channel:s.channel,q:s.query,coin:s.coin,...Object.fromEntries(Object.entries(s.pages).map(([k,v])=>[k+'_page',String(v)]))});}
    async function load(force=false,accept=false){
      if(!s.active||options.isAppClosed())return;clearTimeout(s.timer);if(s.controller)s.controller.abort();const serial=++s.serial;s.controller=new AbortController();const params=filters();if(force)params.set('refresh','1');
      try{
        const data=await get('/api/news?'+params,{signal:s.controller.signal});if(serial!==s.serial||!s.active)return;
        if(data.offline){stopStream();streamStatus('本机缓存模式');}else connect();
        if(!s.data||accept){s.data=data;s.pending=null;render(data);}else if(data.revision!==s.data.revision){s.pending=data;showStatus(data);showIncoming();}else showStatus(data);
        if(active())s.timer=setTimeout(()=>load(),data.refreshing?2000:60000);
      }catch(error){if(error.name==='AbortError'||serial!==s.serial)return;$('newsError').hidden=false;$('newsError').textContent='快讯暂时无法读取，已有内容保留；可稍后刷新。';if(active())s.timer=setTimeout(()=>load(),60000);}
    }
    function connect(){
      if(!active()||s.ws||s.data?.offline)return;
      if(typeof window.WebSocket!=='function'){streamStatus('每分钟更新');return;}
      streamStatus('连接主快讯…');const ws=new window.WebSocket('wss://api.eqn.news/public/ws');s.ws=ws;
      ws.onopen=()=>{if(s.ws!==ws)return;s.wsRetry=0;streamStatus('主快讯实时连接',true);s.heartbeat=setInterval(()=>{if(ws.readyState===1)ws.send('ping');},30000);};
      ws.onmessage=event=>{if(s.ws!==ws||typeof event.data!=='string'||event.data==='pong'||event.data.length>40000)return;try{const item=normalizedLive(JSON.parse(event.data));if(!item)return;s.live.set(item.id,item);while(s.live.size>30)s.live.delete(s.live.keys().next().value);showIncoming();}catch{}};
      ws.onerror=()=>{streamStatus('每分钟更新 · 实时重连中');};
      ws.onclose=event=>{if(s.ws!==ws)return;s.ws=null;clearInterval(s.heartbeat);streamStatus('每分钟更新 · 实时重连中');if(active()){const base=[1008,1013].includes(event.code)?30000:Math.min(30000,1000*2**Math.min(s.wsRetry++,5));s.reconnect=setTimeout(connect,base+Math.random()*400);}};
    }
    function find(id){return s.live.get(id)||(s.pending||s.data)?.columns?.flatMap(x=>x.items||[]).find(x=>x.id===id)||s.data?.columns?.flatMap(x=>x.items||[]).find(x=>x.id===id);}
    async function openStory(id){const item=find(id);if(!item)return;s.selected=id;const serial=++s.detailSerial;clearTimeout(s.detailTimer);$('newsDetailContent').innerHTML=detailMarkup(item,item.live?'live':'cached');if(!$('newsDetailDialog').open)$('newsDetailDialog').showModal();if(item.live)return;const deadline=Date.now()+20000;async function read(){try{const data=await get('/api/news/detail?'+new URLSearchParams({id}));if(serial!==s.detailSerial||!$('newsDetailDialog').open)return;$('newsDetailContent').innerHTML=detailMarkup(data.item,data.status,data.error);if(data.status==='refreshing'&&Date.now()<deadline)s.detailTimer=setTimeout(read,1500);}catch{if(serial===s.detailSerial)$('newsDetailContent').innerHTML=detailMarkup(item,'partial','接口暂未完成，已有快讯可继续阅读，也可打开原文。');}}await read();}
    function applyFilters(){s.pages={};s.data=null;s.pending=null;s.revision=null;$('newsIncoming').hidden=true;document.querySelectorAll('[data-news-focus]').forEach(x=>x.classList.toggle('active',x.dataset.newsFocus===s.focus));load(false,true);}
    function setActive(value){if(s.active===value)return;s.active=value;$('newsView').hidden=!value;$('newsHomeButton').classList.toggle('active',value);if(value){load(false,!s.data);}else{stop();if($('newsDetailDialog').open)$('newsDetailDialog').close();}}
    $('newsHomeButton').addEventListener('click',()=>{options.onOpen();setActive(true);});
    $('newsFocus').addEventListener('click',e=>{const b=e.target.closest('[data-news-focus]');if(b){s.focus=b.dataset.newsFocus;s.channel='all';$('newsChannel').value='all';applyFilters();}});
    $('newsChannel').addEventListener('change',e=>{s.channel=e.target.value;s.focus='all';applyFilters();});
    let inputTimer;$('newsSearch').addEventListener('input',e=>{s.query=e.target.value.slice(0,120);clearTimeout(inputTimer);inputTimer=setTimeout(applyFilters,240);});$('newsCoin').addEventListener('input',e=>{s.coin=e.target.value.trim().toUpperCase();clearTimeout(inputTimer);inputTimer=setTimeout(applyFilters,240);});
    $('newsPause').addEventListener('click',()=>{s.paused=!s.paused;$('newsPause').textContent=s.paused?'继续接收':'暂停接收';if(s.paused){stop();streamStatus('已暂停接收');}else{load(true,true);connect();}});
    $('newsRefresh').addEventListener('click',()=>load(true,true));$('newsIncoming').addEventListener('click',()=>{if(s.pending){s.data=s.pending;s.pending=null;}if(s.data)render(s.data);$('newsIncoming').hidden=true;});
    $('newsColumns').addEventListener('click',e=>{const story=e.target.closest('[data-news-story]'),page=e.target.closest('[data-news-page]');if(story)openStory(story.dataset.newsStory);if(page&&!page.disabled){s.pages[page.dataset.newsPage]=Number(page.dataset.page);load(false,true);}});
    $('closeNewsDetail').addEventListener('click',()=>$('newsDetailDialog').close());$('newsDetailDialog').addEventListener('close',()=>{s.detailSerial++;clearTimeout(s.detailTimer);});
    document.addEventListener('visibilitychange',()=>{if(!s.active)return;if(document.hidden)stop();else if(!s.paused){load();connect();}});
    return{setActive,close:stop,load,state:s};
  }
  window.ShixuNews={create,cardMarkup,detailMarkup,clock,normalizedLive,composeColumns};
}());
