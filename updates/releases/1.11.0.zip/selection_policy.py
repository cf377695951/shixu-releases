"""Dated user display policy, 2026-10-28. No orders or notifications."""
from __future__ import annotations
import copy
import re
import math
import datetime as dt
from urllib.parse import urlsplit

DEFAULT_UNLOCK_RATIO=0.20
DERIBIT_EXPIRY_POLICY_URL='https://support.deribit.com/hc/en-us/articles/25944688876957-Contract-Introduction-Policy'
OPTIONS_FOCUS_NOTE='Deribit BTC / ETH 期权仅在主日历显示月度、季度到期：每月最后一个周五16:00（北京时间）；按交易所已列示合约筛选，不据此预测涨跌。'


def last_friday(year,month):
    """Deribit's monthly/quarterly expiry day, without creating any event."""
    next_month=dt.date(year+1,1,1) if month==12 else dt.date(year,month+1,1)
    last=next_month-dt.timedelta(days=1)
    return last-dt.timedelta(days=(last.weekday()-4)%7)


def option_expiry_focus(event):
    """Classify only known Deribit BTC/ETH source records for display focus.

    This is an attention filter over existing listed expiries, not a provider or
    an OI/volume ranking. Unrelated venues keep their own, unmodified schedules.
    An overlapping quarter/month/week/day is one expiry with the highest tier.
    """
    if event.get('category')!='options': return None
    try: host=(urlsplit(str(event.get('source_url') or '')).hostname or '').lower()
    except ValueError: return None
    if host!='deribit.com' and not host.endswith('.deribit.com'): return None
    identifier=str(event.get('id') or '')
    match=re.match(r'^deribit-(BTC|ETH)-',identifier,re.I)
    if not match:
        match=re.match(r'^(BTC|ETH)\s*期权',str(event.get('title') or ''),re.I)
    if not match: return None
    asset=match.group(1).upper()
    result={'expiry_tier':'unverified','expiry_label':'到期时间待核验',
            'expiry_note':'交易所记录缺少一致的精确到期时刻，未纳入月度 / 季度关注日。',
            'expiry_venue':'Deribit','expiry_asset':asset}
    if event.get('status')!='confirmed' or event.get('time_precision') in ('date_only','window','unknown'):
        return result
    instants=[]
    for value in (event.get('timestamp_utc'),event.get('start_at')):
        if not value: continue
        try:
            instant=dt.datetime.fromisoformat(str(value).replace('Z','+00:00'))
            if instant.tzinfo is None or instant.utcoffset() is None: return result
            instants.append(instant.astimezone(dt.timezone.utc))
        except (ValueError,TypeError,OverflowError): return result
    if not instants or any(x!=instants[0] for x in instants[1:]): return result
    expiry=instants[0]
    china=expiry.astimezone(dt.timezone(dt.timedelta(hours=8)))
    if (expiry.time()!=dt.time(8) or event.get('date')!=china.date().isoformat()
            or event.get('time') not in (None,'','16:00','16:00:00')):
        return result
    day=china.date()
    if day==last_friday(day.year,day.month):
        tier='quarterly' if day.month in (3,6,9,12) else 'monthly'
    else: tier='weekly' if day.weekday()==4 else 'daily'
    labels={'quarterly':'季度到期','monthly':'月度到期','weekly':'普通周度到期','daily':'日度到期'}
    result.update(expiry_tier=tier,expiry_label=labels[tier],expiry_at_utc=expiry.isoformat(),
                  expiry_note=('每月最后一个周五16:00（北京时间）；3、6、9、12月按季度到期标注，同一到期不重复列月度。'
                               if tier in ('monthly','quarterly') else '普通日度 / 周度到期不进入主日历；原始合约事件与已收藏详情仍保留。'))
    return result

def is_st(event):
    if event.get('category')!='earnings' or event.get('market')!='A股': return False
    company=event.get('company') or {}
    name=str(company.get('name') or event.get('title') or '').replace(' ','').replace('＊','*').upper()
    return bool(re.match(r'^(?:S\*?ST|\*?ST)',name))

def unlock_ratio(event):
    value=event.get('unlock_ratio_float_before')
    if value is None: value=(event.get('details') or {}).get('占解禁前流通股')
    if value is None: return None
    try:
        if isinstance(value,str):
            value=value.strip().replace(',','')
            number=float(value[:-1])/100 if value.endswith('%') else float(value)
            return number if math.isfinite(number) else None
        number=float(value)
        return number if math.isfinite(number) else None
    except (ValueError,TypeError): return None

def symbol_key(market,ticker):
    ticker=str(ticker or '').upper().strip()
    if market=='港股': ticker=ticker.removesuffix('.HK').zfill(5)+'.HK'
    if market in ('中国','沪市','深市','北交所'): market='A股'
    return str(market)+':'+ticker

def apply_policy(events,watchlist=None,major_unlock_ratio=DEFAULT_UNLOCK_RATIO,logo_manifest=None):
    symbols=(watchlist or {}).get('symbols',[]) if isinstance(watchlist,dict) else (watchlist or [])
    held={symbol_key(s.get('market','A股'),s.get('ticker')):s for s in symbols}
    kept=[];pending=[];counts={'st_removed':0,'small_unlocks_removed':0,'unlock_ratio_missing':0,'non_a_share_removed':0,'duplicate_hk_counter_removed':0}
    hk_normal={(str(e.get('company',{}).get('ticker','')).replace('.HK','').zfill(5),e.get('date')):e for e in events if e.get('market')=='港股' and e.get('category')=='earnings'}
    for item in events:
        e=copy.deepcopy(item)
        if is_st(e): counts['st_removed']+=1;continue
        c=e.get('company') or {};ticker=str(c.get('ticker','')).replace('.HK','')
        if e.get('market')=='A股' and e.get('category')=='earnings' and re.fullmatch(r'(?:200|900)\d{3}',ticker):
            counts['non_a_share_removed']+=1;continue
        if e.get('market')=='港股' and e.get('category')=='earnings' and re.fullmatch(r'8\d{4}',ticker):
            primary=str(int(ticker)-80000).zfill(5)
            counterpart=hk_normal.get((primary,e.get('date')))
            name=str(c.get('name','')).removesuffix('-R').strip()
            if counterpart and name==str((counterpart.get('company') or {}).get('name','')).strip():
                counts['duplicate_hk_counter_removed']+=1;continue
        if e.get('category')=='unlock':
            ratio=unlock_ratio(e)
            if ratio is None or ratio<0:
                e['pending_reason']='缺少可核实的解禁前流通股比例，未进入重大解禁提醒'
                pending.append(e);counts['unlock_ratio_missing']+=1;continue
            if ratio<major_unlock_ratio:
                counts['small_unlocks_removed']+=1;continue
            e['major_unlock']=True;e['unlock_ratio_float_before']=ratio
            e.setdefault('details',{})['筛选标准']=f'计划解禁量 / 解禁前流通股 ≥ {major_unlock_ratio:.0%}；按用户2026-10-28要求过滤小比例解禁'
        company=e.get('company') or {}
        related=set(e.get('related_symbols') or [])
        if company.get('ticker'): related.add(symbol_key(e.get('market'),company['ticker']))
        matches=sorted(related.intersection(held))
        e['is_holding']=bool(matches)
        if matches:e['holding_symbols']=matches
        if company and logo_manifest:
            info=logo_manifest.get(symbol_key(e.get('market'),company.get('ticker')))
            if info:
                company['logo_url']=info['path'];company['logo_source_url']=info.get('source_url')
                e['company']=company
        kept.append(e)
    return {'events':kept,'pending':pending,'filtered':counts,'major_unlock_ratio':major_unlock_ratio}


def event_importance(event):
    if event.get('is_personal'):return {'importance':event.get('importance','normal'),'importance_label':'重要' if event.get('importance')=='high' else '', 'importance_reason':'本人标记的重要日程'}
    """Display importance only; never a price direction or duplicate meeting."""
    title=str(event.get('title') or '')
    if event.get('category')=='macro' and re.search(r'FOMC|非农|就业形势|CPI|PCE|GDP|采购经理|居民消费价格|工业生产者价格',title,re.I):
        return {'importance':'high','importance_label':'重磅','importance_reason':'主要政策或经济数据，可能影响跨市场定价'}
    if event.get('category')=='politics' and re.search(r'美国.*中期选举|中期选举.*美国',title):
        return {'importance':'high','importance_label':'重磅','importance_reason':'美国国会选举，关注政策路径与不确定性'}
    return {'importance':'normal'}


def evidence_quality(event):
    from urllib.parse import urlsplit
    import datetime as _dq_dt
    if event.get('is_personal'):return {'level':'personal','label':'个人日程','basis':'用户创建或从日历文件导入'}
    host=(urlsplit(str(event.get('source_url')or'')).hostname or'').lower()
    official=('federalreserve.gov','stats.gov.cn','bls.gov','bea.gov','pbc.gov.cn','hkex.com.hk','hkexnews.hk','sse.com.cn','szse.cn','bse.cn','hko.gov.hk','usa.gov','fec.gov','senate.gov','house.gov')
    primary=any(host==x or host.endswith('.'+x)for x in official)
    calculated=event.get('category')=='astronomy'or 'JPL'in str(event.get('source_name'))
    if calculated:level,label,basis='calculated','星历计算','计算得到的时间窗口，与原始星历来源分别列示'
    elif primary:level,label,basis='primary','官方日程','官方来源的日程安排；不单凭日程推断数据已经公布'
    elif event.get('event_type')=='earnings_call' and 'IR'in str(event.get('source_name')):level,label,basis='issuer','公司IR日程','公司投资者关系日程；不代表已取得财报公布值'
    else:level,label,basis='secondary','平台日程','第三方平台日历；预计时段和公司正式确认分开'
    warnings=[]
    if event.get('data_stale'):warnings.append('保留旧快照，当前刷新未成功')
    raw=event.get('source_checked_at')
    if raw:
        try:
            at=_dq_dt.datetime.fromisoformat(str(raw).replace('Z','+00:00'))
            if at.tzinfo and at>_dq_dt.datetime.now(_dq_dt.timezone.utc)+_dq_dt.timedelta(minutes=5):warnings.append('来源核实时间在未来，需复核')
        except(ValueError,TypeError):warnings.append('来源核实时间格式无法确认')
    return {'level':level,'label':label,'basis':basis,'warnings':warnings,'source_host':host}
