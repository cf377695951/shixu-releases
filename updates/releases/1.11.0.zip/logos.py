"""Local issuer marks, with compact build-time catalog assets.

The bundled catalog contains 48px PNGs. Runtime never requests issuer images
from an external service; only requested visible marks are base64-decoded, with
a bounded 256-entry cache. Provider provenance remains explicit in the registry.
"""
from __future__ import annotations
import base64
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import struct
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent
BRANDING=ROOT/'branding'
CATALOG_LIMIT=40_000_000
ASSET_LIMIT=30_000
VIRTUAL=re.compile(r'catalog-[0-9a-f]{24}\.png\Z')
CATALOG_FILES=('catalog-assets.json','catalog-extra-v15.json','catalog-extra-v18.json')
MANIFEST_FILES=('manifest.json','manifest-v15.json','manifest-v18.json')

def _stamp(path:Path)->int:
    try:return path.stat().st_mtime_ns
    except OSError:return 0

def _bundle_stamp(names:tuple[str,...])->tuple[int,...]:
    return tuple(_stamp(BRANDING/name) for name in names)

@lru_cache(maxsize=1)
def _catalog(stamp)->dict:
    del stamp
    result={}
    for filename in CATALOG_FILES:
        path=BRANDING/filename
        try:
            limit=CATALOG_LIMIT if filename=='catalog-assets.json' else 2_000_000
            if path.stat().st_size>limit:continue
            raw=json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict) or raw.get('schema')!=1:continue
            assets=raw.get('assets')
            if not isinstance(assets,dict) or len(assets)>25_000:continue
            for name,item in assets.items():
                if len(result)>=25_000:break
                if isinstance(name,str) and VIRTUAL.fullmatch(name):result.setdefault(name,item)
        except (OSError,ValueError,TypeError):continue
    return result

@lru_cache(maxsize=256)
def _decoded(name:str,stamp)->tuple[bytes,str,str]|None:
    if not VIRTUAL.fullmatch(name):return None
    item=_catalog(stamp).get(name)
    if not isinstance(item,dict) or item.get('mime')!='image/png':return None
    try:
        encoded=item['base64'];sha=item['sha256']
        if not isinstance(encoded,str) or len(encoded)>ASSET_LIMIT*2:return None
        if not re.fullmatch('[0-9a-f]{64}',sha):return None
        data=base64.b64decode(encoded,validate=True)
        if not data or len(data)>ASSET_LIMIT or len(data)!=item.get('size'):return None
        if data[:8]!=b'\x89PNG\r\n\x1a\n' or struct.unpack('>II',data[16:24])!=(48,48):return None
        if hashlib.sha256(data).hexdigest()!=sha or name!='catalog-'+sha[:24]+'.png':return None
        return data,'image/png',sha
    except (KeyError,ValueError,TypeError,struct.error):return None

def logo_asset(name:str)->tuple[bytes,str,str]|None:
    """Return only a known virtual local PNG, never an arbitrary path or URL."""
    if not isinstance(name,str) or not VIRTUAL.fullmatch(name):return None
    return _decoded(name,_bundle_stamp(CATALOG_FILES))

@lru_cache(maxsize=2)
def _registry(stamp)->dict:
    del stamp
    try:
        raw={}
        for filename in MANIFEST_FILES:
            path=BRANDING/filename
            try:
                limit=20_000_000 if filename=='manifest.json' else 1_000_000
                if path.stat().st_size>limit:continue
                part=json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(part,dict) or len(part)>30_000:continue
                for key,item in part.items():
                    if len(raw)>=30_000:break
                    raw.setdefault(key,item)
            except (OSError,ValueError,TypeError):continue
        result={};catalog=_catalog(_bundle_stamp(CATALOG_FILES))
        for key,item in raw.items():
            if not isinstance(item,dict):continue
            asset=item.get('path','')
            if not isinstance(asset,str) or not asset.startswith('/branding/'):continue
            name=asset.removeprefix('/branding/')
            if Path(name).name!=name or Path(name).suffix not in ('.svg','.ico','.png'):continue
            source_url=item.get('source_url','')
            if not isinstance(source_url,str):continue
            try:source=urlsplit(source_url)
            except ValueError:continue
            if source.scheme!='https' or not source.hostname or source.username or source.password:continue
            sha=item.get('sha256','')
            if not isinstance(sha,str) or not re.fullmatch('[0-9a-f]{64}',sha):continue
            if VIRTUAL.fullmatch(name):
                entry=catalog.get(name)
                if not isinstance(entry,dict) or entry.get('sha256')!=sha or entry.get('mime')!='image/png':continue
                # Decode/hash only requested visible images, not every company.
                if item.get('catalog_asset')!=name or name!='catalog-'+sha[:24]+'.png':continue
            else:
                path=BRANDING/name
                if not path.is_file() or path.stat().st_size>500_000:continue
                if hashlib.sha256(path.read_bytes()).hexdigest()!=sha:continue
            result[str(key)]=dict(item)
        return result
    except (OSError,ValueError,TypeError):return {}

def prewarm()->dict:
    """Read compact catalog metadata before requests; no network or bulk decode."""
    registry=_registry(_bundle_stamp(MANIFEST_FILES+CATALOG_FILES))
    return {'symbols':len(registry),'catalog_images':len(_catalog(_bundle_stamp(CATALOG_FILES))),'decoded_cache_limit':256}

def logo_for(market:str,ticker:str)->dict|None:
    item=_registry(_bundle_stamp(MANIFEST_FILES+CATALOG_FILES)).get(str(market)+':'+str(ticker).upper())
    return dict(item) if item else None

def apply_branding(events:list[dict])->list[dict]:
    registry=_registry(_bundle_stamp(MANIFEST_FILES+CATALOG_FILES))
    for event in events:
        company=event.get('company')
        if not isinstance(company,dict):continue
        mark=registry.get(str(event.get('market',''))+':'+str(company.get('ticker','')).upper())
        if mark:
            company.update(logo_url=mark['path'],logo_source_url=mark['source_url'],logo_kind=mark.get('kind'))
        else:
            for key in ('logo_url','logo_source_url','logo_kind'):company.pop(key,None)
    return events
