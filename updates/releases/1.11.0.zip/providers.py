"""Source-isolated public calendar adapters. Python 3.11+, standard library only.

No financial account connection, trading, notification or scheduler is present.
Calendar publication is evidence of a scheduled event, not of an economic outcome.
"""
from __future__ import annotations

import concurrent.futures
import copy
import datetime as dt
import hashlib
import html
import json
import math
import os
from pathlib import Path
import re
import threading
import time
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

UTC = dt.timezone.utc
BEIJING = dt.timezone(dt.timedelta(hours=8), "Asia/Shanghai")
HTTP_TIMEOUT = 15
MAX_BYTES = 8 * 1024 * 1024
CACHE_SECONDS = 15 * 60
ALLOWED_HOSTS = frozenset({
    "www.bls.gov", "www.bea.gov", "apps.bea.gov", "www.deribit.com",
    "api.nasdaq.com", "www.federalreserve.gov", "datacenter-web.eastmoney.com",
    "push2.eastmoney.com",
})
ROOT = Path(__file__).resolve().parent
URLS = {
    "bls": "https://www.bls.gov/schedule/news_release/bls.ics",
    "bea": "https://www.bea.gov/news/schedule/ics/online-calendar-subscription.ics",
    "fed": "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm",
    "east": "https://datacenter-web.eastmoney.com/api/data/v1/get",
}


def now_iso():
    return dt.datetime.now(UTC).isoformat(timespec="seconds")


def _date(value):
    return dt.date.fromisoformat(str(value)[:10])


def _in_range(event, start, end):
    return start <= event.get("date", "") <= end


def _validate_url(url):
    p = urllib.parse.urlsplit(url)
    if p.scheme != "https" or p.hostname not in ALLOWED_HOSTS or p.username or p.password or p.port not in (None, 443):
        raise ValueError("数据请求地址不在内置HTTPS来源名单")
    return url


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _fetch(url, timeout=HTTP_TIMEOUT):
    """No user-supplied URL, no cookies, no credentials, bounded response."""
    _validate_url(url)
    req = urllib.request.Request(url, headers={
        "User-Agent": "EventAtlas-Calendar/1.0 (personal read-only calendar)",
        "Accept": "application/json,text/calendar,text/html;q=0.8,*/*;q=0.1",
        "Accept-Encoding": "identity",
    })
    with urllib.request.build_opener(_SafeRedirect).open(req, timeout=timeout) as response:
        _validate_url(response.geturl())
        body = response.read(MAX_BYTES + 1)
        if len(body) > MAX_BYTES:
            raise ValueError("来源响应超过8MiB限制，未作为完整数据使用")
        encoding = response.headers.get_content_charset() or "utf-8"
        return body.decode(encoding, errors="strict").lstrip("\ufeff")


def _json(url):
    return json.loads(_fetch(url))


def _read_cache(path):
    try:
        if path.stat().st_size > 40 * 1024 * 1024:
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("events"), list):
            return None
        dt.datetime.fromisoformat(data["saved_at"])
        return data
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _write_cache(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def _cached_source(source_id, name, coverage, cache_dir, fetcher, ttl=CACHE_SECONDS):
    path = Path(cache_dir) / (source_id + ".json")
    old = _read_cache(path)
    timestamp = now_iso()
    if old:
        age = (dt.datetime.now(UTC) - dt.datetime.fromisoformat(old["saved_at"])).total_seconds()
        effective_ttl = min(ttl, 60) if old.get("source", {}).get("status") == "partial" else ttl
        if 0 <= age < effective_ttl:
            source = dict(old.get("source", {}), id=source_id, name=name,
                          status=old.get("source", {}).get("status", "ok"),
                          cache_used=True, last_success=old["saved_at"])
            return copy.deepcopy(old["events"]), source
    try:
        result = fetcher()
        timestamp = now_iso()
        events = result["events"]
        if not isinstance(events, list):
            raise ValueError("来源事件结构不是列表")
        for event in events:
            event.setdefault("source_checked_at", timestamp)
        warning = result.get("warning")
        source = {"id": source_id, "name": name,
                  "status": "partial" if warning else "ok", "last_success": timestamp,
                  "coverage": result.get("coverage", coverage), "error": warning,
                  "event_count": len(events), "cache_used": False, "intervals": result.get("intervals")}
        _write_cache(path, {"saved_at": timestamp, "events": events, "source": source})
        return events, source
    except Exception as exc:
        error = f"{type(exc).__name__}: {str(exc)[:240]}"
        if old:
            events = copy.deepcopy(old["events"])
            for event in events:
                event["data_stale"] = True
                event.setdefault("details", {})["刷新状态"] = "联网刷新失败，保留上次成功缓存；不可视为最新确认"
            return events, {"id": source_id, "name": name, "status": "cached",
                            "last_success": old["saved_at"], "coverage": old.get("source", {}).get("coverage", coverage),
                            "error": error, "event_count": len(events), "cache_used": True}
        return [], {"id": source_id, "name": name, "status": "error", "last_success": None,
                    "coverage": coverage, "error": error, "event_count": 0, "cache_used": False}


def _eastern_offset(local):
    """Fallback for Windows embedded Python without IANA tzdata, years>=2007.

    This is a conversion rule for a source's actual time, not a schedule model.
    Financial source times (08:30/10:00/14:00) avoid DST transition ambiguity.
    """
    if local.year < 2007:
        raise ValueError("无tzdata时仅支持2007年后的纽约夏令时规则")
    march = dt.date(local.year, 3, 1)
    second_sunday = 1 + (6 - march.weekday()) % 7 + 7
    november = dt.date(local.year, 11, 1)
    first_sunday = 1 + (6 - november.weekday()) % 7
    begin = dt.datetime(local.year, 3, second_sunday, 2)
    end = dt.datetime(local.year, 11, first_sunday, 2)
    return dt.timedelta(hours=-4 if begin <= local.replace(tzinfo=None) < end else -5)


def _aware(local, timezone):
    name = {"US-Eastern": "America/New_York", "US/Eastern": "America/New_York", "GMT": "UTC"}.get(timezone, timezone)
    if name in ("UTC", "Etc/UTC"):
        return local.replace(tzinfo=UTC)
    if name in ("Asia/Shanghai", "Asia/Hong_Kong"):
        return local.replace(tzinfo=BEIJING)
    try:
        return local.replace(tzinfo=ZoneInfo(name))
    except ZoneInfoNotFoundError:
        if name == "America/New_York":
            return local.replace(tzinfo=dt.timezone(_eastern_offset(local)))
        raise ValueError(f"来源时区无法识别: {timezone}")


def _ics_unescape(value):
    return re.sub(r"\\([nN,;\\])", lambda m: "\n" if m.group(1).lower() == "n" else m.group(1), value)


_TRANSLATIONS = {
    "Consumer Price Index": "美国CPI消费者价格指数",
    "Producer Price Index": "美国PPI生产者价格指数",
    "Employment Situation": "美国非农就业报告",
    "Job Openings and Labor Turnover Survey": "美国JOLTS职位空缺与劳动力流动",
    "Employment Cost Index": "美国就业成本指数",
    "U.S. Import and Export Price Indexes": "美国进出口价格指数",
    "Productivity and Costs": "美国生产率与成本",
    "Real Earnings": "美国实际收入",
}


def _macro_title(summary):
    if summary in _TRANSLATIONS:
        return _TRANSLATIONS[summary]
    if summary.startswith("Personal Income and Outlays"):
        return "美国个人收入与支出（含PCE） · " + summary.split(",", 1)[-1].strip()
    if "Gross Domestic Product" in summary or summary.startswith("GDP ("):
        return "美国GDP · " + summary
    return summary


def parse_ics(text, source_id, source_name, source_url):
    """Parse VEVENT DTSTART/UID/SEQUENCE/CANCELLED with RFC5545 unfolding.

    These publisher feeds contain non-recurring release records. A recurring
    VEVENT is rejected rather than silently showing only its first instance.
    """
    if "BEGIN:VCALENDAR" not in text or "END:VCALENDAR" not in text:
        raise ValueError("来源不是完整的iCalendar日历")
    lines = re.sub(r"\r?\n[ \t]", "", text.replace("\r\n", "\n")).split("\n")
    events = {}
    record = None
    default_timezone = "America/New_York"
    for line in lines:
        if line.startswith("X-WR-TIMEZONE:"):
            default_timezone = line.split(":", 1)[1].strip()
        if line == "BEGIN:VEVENT":
            record = {}
            continue
        if line == "END:VEVENT":
            if not record or "DTSTART" not in record or "SUMMARY" not in record:
                raise ValueError("iCalendar事件缺少必要日期或标题")
            if "RRULE" in record or "RDATE" in record:
                raise ValueError("来源出现重复规则，V1未展开，拒绝当作完整日历")
            params, raw = record["DTSTART"]
            all_day = "VALUE=DATE" in params and "DATE-TIME" not in params
            summary = _ics_unescape(record["SUMMARY"][1])
            uid = record.get("UID", ("", summary + raw))[1]
            sequence = int(record.get("SEQUENCE", ("", "0"))[1])
            stable_id = source_id + "-" + hashlib.sha256(uid.encode()).hexdigest()[:22]
            if all_day or re.fullmatch(r"\d{8}", raw):
                local = dt.datetime.strptime(raw[:8], "%Y%m%d")
                date, clock, stamp = local.date().isoformat(), "", None
                tz = default_timezone
            else:
                fmt = "%Y%m%dT%H%M%S" if len(raw.rstrip("Z")) == 15 else "%Y%m%dT%H%M"
                local = dt.datetime.strptime(raw.rstrip("Z"), fmt)
                tz_match = re.search(r"TZID=([^;]+)", params)
                tz = "UTC" if raw.endswith("Z") else (tz_match.group(1).strip('"') if tz_match else default_timezone)
                aware = _aware(local, tz)
                china = aware.astimezone(BEIJING)
                date, clock, stamp = china.date().isoformat(), china.strftime("%H:%M"), aware.astimezone(UTC).isoformat()
            cancelled = record.get("STATUS", ("", ""))[1].upper() == "CANCELLED"
            event = {"id": stable_id, "title": _macro_title(summary), "category": "macro", "market": "美国",
                     "date": date, "time": clock, "timezone": "Asia/Shanghai" if clock else tz,
                     "source_url": source_url, "source_name": source_name, "status": "confirmed",
                     "timestamp_utc": stamp, "details": {"原始名称": summary, "官方源日期时间": raw,
                     "官方源时区": tz, "发布内容": "统计发布日程；不包含预测值、前值或实际经济数据",
                     "日程口径": "官方目前列示，可能更新；以源页面最终变更为准"}}
            previous = events.get(stable_id)
            if previous is None or sequence >= previous[0]:
                events[stable_id] = (sequence, None if cancelled else event)
            record = None
            continue
        if record is not None and ":" in line:
            left, value = line.split(":", 1)
            key = left.split(";", 1)[0].upper()
            record[key] = (left, value)
    return [event for _, event in events.values() if event is not None]


def _ics_source(source_id):
    label = "美国劳工统计局 BLS" if source_id == "bls" else "美国经济分析局 BEA"
    events = parse_ics(_fetch(URLS[source_id]), source_id, label, URLS[source_id])
    dates = [e["date"] for e in events]
    if not dates:
        raise ValueError("官方ICS解析后没有事件，不将空日历视为完整覆盖")
    return {"events": events, "coverage": f"官方ICS当前列示的全部发布，{min(dates)}—{max(dates)}；后续未列示日期不是已确认无事件"}


def parse_deribit(payload, currency):
    if payload.get("error") or not isinstance(payload.get("result"), list):
        raise ValueError("Deribit接口错误或result结构变化")
    groups = {}
    for item in payload["result"]:
        if item.get("kind") != "option" or item.get("base_currency") != currency:
            continue
        timestamp = item.get("expiration_timestamp")
        if not isinstance(timestamp, (int, float)) or not math.isfinite(timestamp):
            raise ValueError("Deribit期权缺少可校验的到期时间戳")
        expires = dt.datetime.fromtimestamp(timestamp / 1000, UTC)
        key = expires.isoformat()
        groups.setdefault(key, []).append(item)
    out = []
    for timestamp, items in groups.items():
        expires = dt.datetime.fromisoformat(timestamp)
        china = expires.astimezone(BEIJING)
        periods = sorted({str(x.get("settlement_period", "未列示")) for x in items})
        out.append({"id": f"deribit-{currency}-{int(expires.timestamp())}",
                    "title": f"{currency}期权到期 · Deribit", "category": "options", "market": "币圈",
                    "date": china.date().isoformat(), "time": china.strftime("%H:%M"), "timezone": "Asia/Shanghai",
                    "timestamp_utc": timestamp, "source_url": "https://docs.deribit.com/api-reference/market-data/public-get_instruments",
                    "source_name": "Deribit公开合约接口", "status": "confirmed",
                    "details": {"到期时间UTC": expires.strftime("%Y-%m-%d %H:%M UTC"),
                    "本次列示合约数": len(items), "合约周期字段": "、".join(periods),
                    "覆盖口径": f"仅Deribit当前列示的{currency}结算、{currency}标的期权；不含全交易所及USDC结算期权",
                    "规模数据": "未采集未平仓量、名义金额或最大痛点；合约个数不是仓位规模",
                    "风险解释": "到期不意味着必然涨跌；确切合约状态以交易所为准"}})
    return out


def _deribit(currency):
    params = urllib.parse.urlencode({"currency": currency, "kind": "option", "expired": "false"})
    payload = _json("https://www.deribit.com/api/v2/public/get_instruments?" + params)
    events = parse_deribit(payload, currency)
    if not events:
        raise ValueError("Deribit返回零期权到期组，可能覆盖或结构异常")
    return {"events": events, "coverage": f"Deribit公开接口当前列示{currency}结算期权；不代表币圈全交易所，不包含已归档历史"}


_MONTHS = {month.lower(): i for i, month in enumerate(("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"), 1)}


def _strip_tags(value):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", value))).strip()


def parse_fed(text):
    """Read official meeting cells, not date-looking links or a fixed schedule."""
    headings = list(re.finditer(r"(\d{4})\s+FOMC Meetings", text))
    if not headings:
        raise ValueError("Fed会议标题结构已变化")
    output = []
    today_ny = dt.datetime.now(UTC).astimezone(dt.timezone(dt.timedelta(hours=-5))).date()
    for i, heading in enumerate(headings):
        year = int(heading.group(1))
        block = text[heading.end(): headings[i + 1].start() if i + 1 < len(headings) else len(text)]
        # Match individual month/date cells even when a shaded class is also present.
        rows = re.finditer(r'<div[^>]*class="[^"]*fomc-meeting__month[^\"]*"[^>]*>(.*?)</div>\s*<div[^>]*class="[^"]*fomc-meeting__date[^\"]*"[^>]*>(.*?)</div>', block, re.S | re.I)
        for row in rows:
            month_text, date_text = _strip_tags(row.group(1)), _strip_tags(row.group(2))
            # Historical unscheduled meetings often use a conference-call suffix.
            if "notation" in date_text.lower() or "unscheduled" in date_text.lower():
                continue
            months = re.findall(r"[A-Za-z]+", month_text)
            numbers = re.findall(r"\d{1,2}", date_text)
            if len(months) != 1 or months[0].lower() not in _MONTHS or not 1 <= len(numbers) <= 2:
                continue  # Cross-month historical special cases are outside V1's current feed.
            month = _MONTHS[months[0].lower()]
            begin, end = int(numbers[0]), int(numbers[-1])
            if end < begin or end - begin > 2:
                continue
            first, last = dt.date(year, month, begin), dt.date(year, month, end)
            tentative = first > today_ny
            for day in range(begin, end + 1):
                date = dt.date(year, month, day).isoformat()
                output.append({"id": "fed-fomc-" + date, "title": "FOMC会议（美东日程）" + (" · 末日" if day == end else " · 首日"),
                    "category": "macro", "market": "美国", "date": date, "time": "", "timezone": "America/New_York",
                    "source_url": URLS["fed"], "source_name": "美联储FOMC官方会议日历", "status": "estimated" if tentative else "confirmed",
                    "date_basis": "market_date", "details": {"会议开始（美东日期）": first.isoformat(), "会议结束（美东日期）": last.isoformat(),
                    "日期显示口径": "这里显示美东会议日期，不是北京时间的决议发布时点",
                    "官方日历说明": "所有未来会议日期在前一次会议确认前均为tentative；不把会议日期等同于决议时刻",
                    "经济预测": "带*，伴随经济预测" if "*" in date_text else "官方日历该场未标*"}})
    if not output:
        raise ValueError("Fed页面解析到零会议，不将GET成功当作日程刷新")
    return {"events": output, "coverage": f"Fed官方当前会议表；未来日期按官方tentative标预计，会议日期保留美东口径；{min(e['date'] for e in output)}—{max(e['date'] for e in output)}"}


def _fed():
    return parse_fed(_fetch(URLS["fed"]))


def _number(value):
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(value) else None
    if not value or str(value).strip() in ("--", "N/A", "-", "n/a"):
        return None
    text = re.sub(r"[$,\s]", "", str(value))
    try:
        n = float(text)
        return n if math.isfinite(n) else None
    except ValueError:
        return None


def parse_nasdaq(payload, source_date):
    status = payload.get("status", {})
    if status.get("rCode") not in (None, 200):
        raise ValueError("Nasdaq接口返回非200业务状态")
    data = payload.get("data")
    if not isinstance(data, dict) or data.get("rows") is None:
        raise ValueError("Nasdaq该日未提供可核验名单，不等同于零财报")
    if not isinstance(data["rows"], list):
        raise ValueError("Nasdaq rows结构已变化")
    events = []
    for company in data["rows"]:
        symbol, name = company.get("symbol"), company.get("name")
        if not symbol or not name:
            raise ValueError("Nasdaq名单出现缺少股票代码/名称的记录")
        timing = company.get("time", "")
        source_day = _date(source_date)
        if timing == "time-after-hours":
            show_day = source_day + dt.timedelta(days=1)
            date_basis = "beijing_day_from_after_hours"
            period = "美东盘后；北京时间次日，精确时刻待公司确认"
        elif timing == "time-pre-market":
            show_day = source_day
            date_basis = "market_date_no_exact_time"
            period = "美东盘前；未提供精确时刻，先按美东财报日期归档"
        else:
            show_day = source_day
            date_basis = "market_date_no_exact_time"
            period = "未提供时段；按美东财报日期归档，可能跨北京时间日期"
        events.append({"id": f"nasdaq-{symbol}-{source_date}", "title": f"{name} · 财报", "category": "earnings", "market": "美股",
            "date": show_day.isoformat(), "time": "", "timezone": "Asia/Shanghai" if timing == "time-after-hours" else "America/New_York",
            "date_basis": date_basis, "source_url": "https://www.nasdaq.com/market-activity/earnings?date=" + source_date,
            "source_name": "Nasdaq财报日历（平台预计）", "status": "estimated",
            "company": {"name": name, "ticker": symbol, "market_cap": _number(company.get("marketCap")), "currency": "USD", "cap_asof": None},
            "details": {"美东财报日期": source_date, "报告期": company.get("fiscalQuarterEnding") or "未提供",
            "发布时段": period, "日期确认状态": "日历平台预计；尚未逐家公司核对IR公告",
            "市值口径": "Nasdaq返回总市值用于同市场排序，接口未给市值事实时点，因此日期留空；非历史财报日市值",
            "EPS预测": company.get("epsForecast") or "未提供", "一致预期样本数": company.get("noOfEsts") or "未提供"}})
    return events


def _nasdaq(start, end, cache_dir):
    first, last = _date(start) - dt.timedelta(days=1), _date(end)
    if (last - first).days > 62:
        raise ValueError("V1财报联网窗口最多62天；请按月查看，未截断冒充完整数据")
    days = [(first + dt.timedelta(days=i)).isoformat() for i in range((last - first).days + 1)]
    failures, events, successes = [], [], []
    def fetch_day(date):
        return _cached_source("nasdaq-day-" + date, "Nasdaq单日日历", date, Path(cache_dir) / "days",
                              lambda: {"events": parse_nasdaq(_json("https://api.nasdaq.com/api/calendar/earnings?date=" + date), date)}, ttl=CACHE_SECONDS)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(fetch_day, days))
    for date, (items, source) in zip(days, results):
        events.extend(items)
        if source["status"] in ("error", "cached", "partial"):
            failures.append(date)
        else:
            successes.append(date)
    if not successes and not events:
        raise ValueError("全部日期财报名单不可用，不能宣称该月无财报")
    return {"events": events,
        "coverage": f"美股Nasdaq平台在美东{days[0]}—{days[-1]}返回的全部名单，成功{len(successes)}/{len(days)}日；未设市值门槛，非全球/全部交易所保证",
        "warning": ("以下美东日期未获得新鲜可核名单（空缺不等于无事件）：" + "、".join(failures)) if failures else None}


def _east_rows(report, date_field, start, end):
    max_pages = 60
    columns = {
        "RPT_PUBLIC_BS_APPOIN": "SECURITY_CODE,SECURITY_NAME_ABBR,REPORT_DATE,APPOINT_PUBLISH_DATE,ACTUAL_PUBLISH_DATE,REPORT_TYPE_NAME,FIRST_APPOINT_DATE,FIRST_CHANGE_DATE,SECOND_CHANGE_DATE,THIRD_CHANGE_DATE,EITIME",
        "RPT_LIFT_STAGE": "SECURITY_CODE,SECURITY_NAME_ABBR,FREE_DATE,CURRENT_FREE_SHARES,ABLE_FREE_SHARES,FREE_SHARES,NON_FREE_SHARES,FREE_RATIO,TOTAL_RATIO,LIFT_MARKET_CAP,FREE_SHARES_TYPE,BATCH_HOLDER_NUM,EUTIME",
    }.get(report, "ALL")
    def fetch_page(page):
        params = {"reportName": report, "columns": columns, "pageSize": "500", "pageNumber": str(page),
                  "sortColumns": date_field + ",SECURITY_CODE", "sortTypes": "1,1",
                  "filter": f"({date_field}>='{start}')({date_field}<='{end}')", "source": "WEB", "client": "WEB"}
        payload = _json(URLS["east"] + "?" + urllib.parse.urlencode(params))
        result = payload.get("result")
        if payload.get("success") is not True or not isinstance(result, dict) or not isinstance(result.get("data"), list):
            # Choice returns result=null for some no-record date ranges. Do not guess that means zero.
            raise ValueError(f"东方财富{report}未返回可校验名单：{payload.get('message', '结构变化')}")
        return result
    first = fetch_page(1)
    pages = int(first.get("pages", 1))
    total = int(first.get("count", len(first["data"])))
    if pages > max_pages:
        raise ValueError("来源超过30000条分页上限，未将截断名单作为全量")
    results = list(first["data"])
    if pages > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            rest = list(pool.map(fetch_page, range(2, pages + 1)))
        for result in rest:
            if int(result.get("count", total)) != total:
                raise ValueError("分页过程中来源总数发生变化，本轮不能证明全量")
            results.extend(result["data"])
    if len(results) != total:
        raise ValueError(f"分页记录数不一致：收到{len(results)}，来源count={total}；不按全量使用")
    return results


def parse_east_earnings(rows):
    output = []
    for row in rows:
        ticker, name = row.get("SECURITY_CODE"), row.get("SECURITY_NAME_ABBR")
        raw = row.get("ACTUAL_PUBLISH_DATE") or row.get("APPOINT_PUBLISH_DATE")
        if not ticker or not name or not raw:
            raise ValueError("A股预约披露出现缺失代码/日期记录")
        date = _date(raw).isoformat()
        report_date = str(row.get("REPORT_DATE") or "")[:10]
        output.append({"id": f"east-earnings-{ticker}-{report_date}", "title": name + " · " + str(row.get("REPORT_TYPE_NAME") or "财报"),
            "category": "earnings", "market": "A股", "date": date, "time": "", "timezone": "Asia/Shanghai",
            "source_url": f"https://data.eastmoney.com/bbsj/{ticker}.html", "source_name": "东方财富Choice预约披露日历", "status": "estimated",
            "company": {"name": name, "ticker": ticker, "market_cap": None, "currency": "CNY", "cap_asof": None},
            "details": {"报告期": report_date, "首次预约日期": str(row.get("FIRST_APPOINT_DATE") or "未提供")[:10],
                "最新预约日期": str(row.get("APPOINT_PUBLISH_DATE") or "未提供")[:10],
                "平台实际披露日期": str(row.get("ACTUAL_PUBLISH_DATE") or "尚未披露")[:10],
                "一次变更": str(row.get("FIRST_CHANGE_DATE") or "无")[:10],
                "二次变更": str(row.get("SECOND_CHANGE_DATE") or "无")[:10],
                "三次变更": str(row.get("THIRD_CHANGE_DATE") or "无")[:10],
                "来源更新时间": row.get("EITIME") or "未提供",
                "核验状态": "平台汇总，未逐条核交易所公告；正式执行前需核原文。市值缺失不猜测，排在有市值公司之后。"}})
    return output


def _east_earnings(start, end, cache_dir=None):
    """Fetch independent seven-day slices, preserving successful intervals.

    At most two slices and four pages per slice run concurrently. Each slice
    is attempted once per call, with its own successful cache. A failed week
    cannot erase another week, and cached-only weeks remain explicitly stale.
    """
    if cache_dir is None:
        with tempfile.TemporaryDirectory(prefix="event-atlas-earnings-") as transient:
            return _east_earnings(start, end, transient)
    first, last = _date(start), _date(end)
    intervals = []
    current = first
    while current <= last:
        until = min(current + dt.timedelta(days=6), last)
        intervals.append((current.isoformat(), until.isoformat()))
        current = until + dt.timedelta(days=1)
    def fetch_interval(interval):
        lo, hi = interval
        def loader():
            rows = _east_rows("RPT_PUBLIC_BS_APPOIN", "APPOINT_PUBLISH_DATE", lo, hi)
            return {"events": parse_east_earnings(rows),
                    "coverage": f"最新预约日期{lo}—{hi}全部分页{len(rows)}条；平台汇总、未逐条核公告"}
        return _cached_source(f"east-earnings-week-{lo}-{hi}", "A股预约披露周区间", f"{lo}—{hi}",
                              Path(cache_dir) / "earnings-weeks", loader)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(fetch_interval, intervals))
    unique, interval_statuses, gaps = {}, [], []
    successful_intervals = 0
    for (lo, hi), (events, source) in zip(intervals, results):
        if source["status"] == "ok":
            successful_intervals += 1
        else:
            label = "上次缓存" if source["status"] == "cached" else "未取到完整名单"
            gaps.append(f"{lo}—{hi}（{label}）")
        interval_statuses.append({"start": lo, "end": hi, "status": source["status"], "records": len(events),
                                  "last_success": source.get("last_success"), "error": source.get("error")})
        for event in events:
            old = unique.get(event["id"])
            if old is None or str(event.get("source_checked_at", "")) >= str(old.get("source_checked_at", "")):
                unique[event["id"]] = event
    if not unique and not successful_intervals:
        raise ValueError("全部A股财报区间不可用，不能宣称该月无财报：" + "；".join(gaps))
    return {"events": sorted(unique.values(), key=lambda e: (e["date"], e["id"])),
            "coverage": f"A股最新预约日期{start}—{end}，已取到完整分页的区间{successful_intervals}/{len(intervals)}，保留{len(unique)}条；每个7日区间独立缓存，不含港股/未预约记录，未逐条核IR或交易所公告；缺市值公司保留",
            "warning": "以下区间本轮未取到新鲜完整名单，空缺不等于无财报：" + "；".join(gaps) if gaps else None,
            "intervals": interval_statuses}


def parse_east_unlock(rows):
    output = []
    for row in rows:
        ticker, name, raw = row.get("SECURITY_CODE"), row.get("SECURITY_NAME_ABBR"), row.get("FREE_DATE")
        if not ticker or not name or not raw:
            raise ValueError("A股解禁出现缺少代码/日期记录")
        date = _date(raw).isoformat()
        # Choice's source raw quantities are 万股/万元; ratio fields are fractions.
        # Preserve both raw and explicit units rather than displaying an unlabelled number.
        scheduled = _number(row.get("CURRENT_FREE_SHARES"))
        actual = _number(row.get("ABLE_FREE_SHARES"))
        float_before = _number(row.get("FREE_SHARES"))
        market_cap = _number(row.get("LIFT_MARKET_CAP"))
        float_ratio = _number(row.get("FREE_RATIO"))
        total_ratio = _number(row.get("TOTAL_RATIO"))
        if scheduled is None or scheduled < 0:
            raise ValueError("解禁数量缺失或异常")
        # FREE_SHARES can be a pre- OR post-unlock float, depending on the
        # source snapshot and event. Never relabel it as a known pre-event float.
        # A ratio identity can be checked against either known interpretation;
        # the displayed denominator, if available, is explicitly a derivation.
        if float_ratio is not None and float_before:
            candidates = [scheduled / float_before]
            if float_before > scheduled:
                candidates.append(scheduled / (float_before - scheduled))
            if not any(abs(value - float_ratio) <= max(1e-6, abs(float_ratio) * 0.02) for value in candidates):
                raise ValueError("解禁股数与来源流通比例无法按已知口径交叉核对，暂不展示该记录")
        free_derived = scheduled * 10000 / float_ratio if float_ratio and float_ratio > 0 else None
        # Do not infer total shares from A-share float + non-float: dual-listed
        # companies can also have H shares, producing a different denominator.
        if total_ratio is not None and not 0 <= total_ratio <= 1:
            raise ValueError("来源占总股本小数比例越界，暂不展示该记录")
        share_type = str(row.get("FREE_SHARES_TYPE") or "未提供")
        stable = hashlib.sha256((ticker + date + share_type).encode()).hexdigest()[:20]
        pct = lambda v: f"{v * 100:.4f}%" if v is not None else "未提供"
        output.append({"id": "east-unlock-" + stable, "title": name + " · 限售股解禁", "category": "unlock", "market": "A股",
            "date": date, "time": "", "timezone": "Asia/Shanghai", "source_url": f"https://data.eastmoney.com/dxf/q/{ticker}.html",
            "source_name": "东方财富Choice解禁日历", "status": "estimated",
            "company": {"name": name, "ticker": ticker, "market_cap": None, "currency": "CNY", "cap_asof": None},
            "details": {"计划解禁数量（股）": round(scheduled * 10000, 4),
                "平台实际可流通数量（股）": round(actual * 10000, 4) if actual is not None else "未提供",
                "解禁前流通股分母（按源比例反推，股）": round(free_derived, 2) if free_derived is not None else "未提供",
                "平台FREE_SHARES（股，时点未注明）": round(float_before * 10000, 4) if float_before is not None else "未提供",
                "占解禁前流通股": pct(float_ratio), "占总股本": pct(total_ratio),
                "参考解禁市值（元）": round(market_cap * 10000, 2) if market_cap is not None else "未提供",
                "限售股份类型": share_type, "本批股东数": row.get("BATCH_HOLDER_NUM") or "未提供",
                "来源更新时间": row.get("EUTIME") or "未提供",
                "单位口径": "来源股数字段为万股、市值为万元、比例为小数；已转换为股/元/百分比。FREE_RATIO源页面定义为占解禁前流通股；按计划股数/源比例反推的分母为计算值，并非原公告确认股数。FREE_SHARES未直接冒称解禁前股数",
                "核验状态": "平台汇总，未逐条核交易所公告；解禁不等于实际减持，未来数量/日期可能变更",
                "成交量对照": "未接入20日平均成交量，留空不计算"}})
    return output


def _east_unlock(start, end):
    rows = _east_rows("RPT_LIFT_STAGE", "FREE_DATE", start, end)
    events, rejected = [], []
    for row in rows:
        try:
            events.extend(parse_east_unlock([row]))
        except ValueError as exc:
            rejected.append(f"{row.get('SECURITY_CODE', '?')}/{str(row.get('FREE_DATE',''))[:10]}：{exc}")
    if rows and not events:
        raise ValueError("解禁全部记录未通过单位/比例核验：" + "；".join(rejected[:3]))
    return {"events": events, "coverage": f"A股平台解禁日期{start}—{end}全部分页{len(rows)}条，展示{len(events)}条；含单位及分母说明，不含币圈解锁或全量交易所公告核验",
            "warning": "部分记录未通过口径核验，未展示：" + "；".join(rejected) if rejected else None}


def _a_market_caps():
    """One paginated all-A quote snapshot; no per-company request fan-out.

    Only ordering metadata is used, not prices or account information. A failed
    snapshot leaves every company in the earnings list with unknown cap.
    """
    def page(number):
        params = {"pn": str(number), "pz": "100", "po": "1", "np": "1", "fltt": "2", "invt": "2", "fid": "f20",
                  "fs": "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23,m:0+t:81+s:2048", "fields": "f12,f13,f14,f20,f124"}
        payload = _json("https://push2.eastmoney.com/api/qt/clist/get?" + urllib.parse.urlencode(params))
        data = payload.get("data")
        if not isinstance(data, dict) or not isinstance(data.get("diff"), (list, dict)):
            raise ValueError("A股总市值接口未返回可核对的diff列表")
        rows = list(data["diff"].values()) if isinstance(data["diff"], dict) else data["diff"]
        return int(data.get("total", 0)), rows
    total, rows = page(1)
    if total <= 0 or not rows:
        raise ValueError("A股总市值返回空快照，不当作全市场")
    page_size = len(rows)
    pages = math.ceil(total / page_size)
    if pages > 100:
        raise ValueError("A股总市值分页超出100页上限，未作为全市场排序使用")
    if pages > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            rest = list(pool.map(page, range(2, pages + 1)))
        for returned_total, records in rest:
            if returned_total != total:
                raise ValueError("A股总市值翻页期间总数变化，本轮无法证明完整")
            rows.extend(records)
    codes = [str(row.get("f12", "")) for row in rows]
    if len(rows) != total or len(set(codes)) != total or not all(codes):
        raise ValueError("A股总市值全市场分页缺失或重复，暂不用于排序")
    records = []
    for row in rows:
        market_cap = _number(row.get("f20"))
        source_ts = _number(row.get("f124"))
        cap_asof = None
        if source_ts is not None and 946684800 <= source_ts <= dt.datetime.now(UTC).timestamp() + 86400:
            cap_asof = dt.datetime.fromtimestamp(source_ts, UTC).isoformat()
        records.append({"id": "a-cap-" + str(row["f12"]), "ticker": str(row["f12"]),
                        "market_cap": market_cap if market_cap and market_cap > 0 else None,
                        "currency": "CNY", "cap_asof": cap_asof,
                        "cap_source_url": "https://quote.eastmoney.com/center/gridlist.html#hs_a_board"})
    return {"events": records, "coverage": f"东方财富A股行情总市值快照，完整分页{len(records)}/{total}；f20为元，源时间字段缺失时市值日期留空。仅用于同市场排序，不是财报日历史市值"}


def _join_caps(events, caps):
    for event in events:
        company = event.get("company")
        if event.get("market") != "A股" or not company:
            continue
        quote = caps.get(str(company.get("ticker", "")))
        if not quote or not quote.get("market_cap"):
            continue
        company.update({k: quote.get(k) for k in ("market_cap", "currency", "cap_asof", "cap_source_url")})
        company["cap_stale"] = bool(quote.get("data_stale"))
        company["cap_source_checked_at"] = quote.get("source_checked_at")
        event.setdefault("details", {})["市值口径"] = "A股全市场行情总市值快照（元）用于同市场排序；有源行情时间戳则显示，缺失不拿本次抓取时间冒充；不是财报日历史市值"
        if company["cap_stale"]:
            event["details"]["市值缓存状态"] = "行情刷新失败，排序使用上次成功缓存；不代表当前总市值"


def _load_seed(start, end):
    try:
        content = json.loads((ROOT / "seed_verified.json").read_text(encoding="utf-8"))
        events = [copy.deepcopy(e) for e in content.get("events", []) if _in_range(e, start, end)]
        checked = content.get("checked_at")
        for event in events:
            event.setdefault("source_checked_at", checked)
            event.setdefault("time", "")
            event.setdefault("details", {})["基线说明"] = "随V1发布的人工核验快照；此条未表示已在本次联网刷新重新核实"
        coverage = content.get("coverage", "人工核实日程基线；不代表实时全市场覆盖")
        return events, {"id": "verified-baseline", "name": "官方日程人工核验基线", "status": "baseline", "last_success": checked,
                        "coverage": json.dumps(coverage, ensure_ascii=False) if not isinstance(coverage, str) else coverage,
                        "error": None, "event_count": len(events)}
    except (OSError, ValueError, TypeError) as exc:
        return [], {"id": "verified-baseline", "name": "官方日程人工核验基线", "status": "error", "last_success": None,
                    "coverage": "基线文件缺失或损坏", "error": str(exc), "event_count": 0}


def refresh_data(start_date, end_date, cache_dir, progress=None):
    """Return observed schedules + per-source health. Never executes external code.

    Inputs are inclusive Beijing display dates; all-day source-market dates are
    explicitly labelled in date_basis/timezone. Typical month refresh: 10–60s,
    cold US earnings may take ~90s; UI should run this in a background thread.
    """
    start, end = _date(start_date).isoformat(), _date(end_date).isoformat()
    if start > end or (_date(end) - _date(start)).days > 62:
        raise ValueError("联网窗口须为递增日期且不超过62天；按月查看可保留全部名单")
    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    events, baseline = _load_seed(start, end)
    sources = [baseline]
    caps = {}
    tasks = [
        ("bls", "BLS官方统计发布", "BLS官方ICS发布日程", lambda: _ics_source("bls"), CACHE_SECONDS),
        ("bea", "BEA官方统计发布", "BEA官方ICS发布日程", lambda: _ics_source("bea"), CACHE_SECONDS),
        ("fed", "Fed官方会议日历", "FOMC官方会议表；未来日程可能调整", _fed, CACHE_SECONDS),
        ("deribit-BTC", "BTC期权到期", "Deribit当前列示合约", lambda: _deribit("BTC"), 300),
        ("deribit-ETH", "ETH期权到期", "Deribit当前列示合约", lambda: _deribit("ETH"), 300),
        (f"nasdaq-{start}-{end}", "美股财报 · Nasdaq", f"美东{start}—{end}日历平台名单", lambda: _nasdaq(start, end, cache_dir), CACHE_SECONDS),
        (f"east-earnings-{start}-{end}", "A股财报 · 预约披露", "东方财富Choice日期范围分周全部分页；未逐条核公告", lambda: _east_earnings(start, end, cache_dir), CACHE_SECONDS),
        (f"east-unlock-{start}-{end}", "A股限售股解禁", "东方财富Choice日期范围全部分页；未逐条核公告", lambda: _east_unlock(start, end), CACHE_SECONDS),
        ("a-marketcap", "A股全市场总市值排序", "东方财富A股总市值完整分页，失败时保留未知市值公司", _a_market_caps, CACHE_SECONDS),
    ]
    tasks=[t for t in tasks if t[0] not in ("fed","a-marketcap")]
    def run(task):
        sid, name, coverage, loader, ttl = task
        return _cached_source(sid, name, coverage, cache_dir, loader, ttl)
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        futures = {pool.submit(run, task): task[0] for task in tasks}
        for future in concurrent.futures.as_completed(futures):
            result_events, source = future.result()
            if source["id"] == "a-marketcap":
                caps = {q["ticker"]: q for q in result_events}
                source["record_count"] = len(caps)
                source["event_count"] = 0
                result_events = []
                _join_caps(events, caps)
            else:
                _join_caps(result_events, caps)
            # Live Fed replaces its manually captured baseline only after actual parsing.
            if source["id"] == "fed" and source["status"] in ("ok", "partial"):
                live_dates = {e["date"] for e in result_events}
                events = [e for e in events if not ("fomccalendars.htm" in e.get("source_url", "") and e.get("date") in live_dates)]
            events.extend(e for e in result_events if _in_range(e, start, end))
            sources.append(source)
            if progress:
                try:
                    progress(dict(source, events=result_events))
                except Exception:
                    pass
    sources.extend([
        {"id": "token-unlocks", "name": "代币解锁与ZEC供给节点", "status": "not_configured", "last_success": None,
         "coverage": "尚未接入官方项目公告与链上区块源；ZEC减半与代币解锁是不同机制，未推算/编造日期", "error": None},
    ])
    unique = {}
    _join_caps(events, caps)
    for event in events:
        if _in_range(event, start, end):
            unique[event["id"]] = event
    return {"version": "1.0.0", "events": sorted(unique.values(), key=lambda e: (e["date"], e.get("time", ""), e["id"])),
            "sources": sorted(sources, key=lambda s: s["id"]), "fetched_at": now_iso(),
            "requested_start": start, "requested_end": end, "timezone": "Asia/Shanghai",
            "coverage_note": "这是各来源已列示日程的汇总，未保证全市场无遗漏；来源失败/未接入或未来未列示均不等于无事件。"}
