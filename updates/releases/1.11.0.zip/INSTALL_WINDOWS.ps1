﻿# Requires Windows PowerShell 5.1 or PowerShell 7. No administrator access.
[CmdletBinding()]
param([switch]$Uninstall, [switch]$Launch)
$ErrorActionPreference = 'Stop'
$appFolder = Join-Path $env:LOCALAPPDATA 'Willance\EventCalendarV1'

$pythonExe = $null
$bundledPython = Join-Path $PSScriptRoot 'runtime\python.exe'
if (Test-Path -LiteralPath $bundledPython) { $pythonExe = $bundledPython }
foreach ($commandName in @('py', 'python', 'python3')) {
    if ($pythonExe) { break }
    $candidate = Get-Command $commandName -ErrorAction SilentlyContinue
    if (-not $candidate) { continue }
    try {
        $checkCode = 'import json,sys; print(json.dumps({"executable":sys.executable,"valid":sys.version_info >= (3,11)}))'
        if ($commandName -eq 'py') { $infoText = & $candidate.Source -3 -c $checkCode 2>$null }
        else { $infoText = & $candidate.Source -c $checkCode 2>$null }
        if ($LASTEXITCODE -eq 0) {
            $info = $infoText | ConvertFrom-Json
            if ($info.valid -and (Test-Path -LiteralPath $info.executable)) { $pythonExe = $info.executable; break }
        }
    } catch { continue }
}
if (-not $pythonExe) {
    throw 'Python 3.11+ is required. Install from https://www.python.org/downloads/windows/ and rerun. Nothing is downloaded automatically.'
}
# All entry points use the same identity-checked shortcut/install policy.
# This script never independently recreates legacy launch or exit shortcuts.
$sourceLauncher = Join-Path $PSScriptRoot 'desktop\launcher.py'
$mode = '--install'
if ($Uninstall) { $mode = '--uninstall' }
& $pythonExe $sourceLauncher $mode
if ($LASTEXITCODE -ne 0) { throw '时序安装操作未完成；已有入口已保留。' }
if ($Uninstall) {
    Write-Host '时序已卸载。'
} else {
    Write-Host ('已安装：' + $appFolder)
    Write-Host '桌面入口：时序'
    if ($Launch) {
        $installedPython = Join-Path $appFolder 'runtime\pythonw.exe'
        if (-not (Test-Path -LiteralPath $installedPython)) {
            $installedPython = Join-Path (Split-Path -Parent $pythonExe) 'pythonw.exe'
            if (-not (Test-Path -LiteralPath $installedPython)) { $installedPython = $pythonExe }
        }
        Start-Process -FilePath $installedPython -ArgumentList ('"' + (Join-Path $appFolder 'desktop\launcher.py') + '"') -WorkingDirectory $appFolder
    }
}
