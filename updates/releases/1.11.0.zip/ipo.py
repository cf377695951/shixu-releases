"""A-share IPO calendar, including BSE. Public schedules only; no subscriptions/orders.

The issuer date comes from the data platform and remains estimated until an
issuer announcement is checked. Session windows are exchange rules, not invented
company-specific publication timestamps. No cash or securities account is read.
"""
from __future__ import annotations
import concurrent.futures
import copy
import datetime as dt
import json
import math
import os
from pathlib import Path
import re
import threading
import urllib.parse
import urllib.request

UTC = dt.timezone.utc
BEIJING = dt.timezone(dt.timedelta(hours=8))
API = 'https://datacenter-web.eastmoney.com/api/data/v1/get'
SOURCE_MAIN = 'https://data.eastmoney.com/xg/xg/default.html'
SOURCE_BSE = 'https://data.eastmoney.com/xg/xg/default.html?mkt=bjs'
RULES = {
    '沪市': 'https://one.sse.com.cn/onething/gptz/',
    '科创板': 'https://one.sse.com.cn/onething/gptz/',
    '深市': 'https://investor.szse.cn/institute/rules/t20230608_601043.html',
    '创业板': 'https://investor.szse.cn/index/update/t20190327_565779.html',
    '北交所': 'https://www.bse.cn/fxrz_list/200015211.html',
}
BSE_TRADING_RULE = 'https://www.bse.cn/jygl_list/200028217.html'
MAIN_COLUMNS = ','.join(('SECURITY_CODE','SECURITY_NAME','SECURITY_NAME_ABBR','APPLY_CODE','APPLY_DATE','LISTING_DATE','SELECT_LISTING_DATE','TRADE_MARKET','MARKET_TYPE_NEW','MARKET','IS_BEIJING','ISSUE_PRICE','ONLINE_APPLY_UPPER','BALLOT_PAY_DATE','BALLOT_NUM_DATE','ONLINE_PAY_DATE','ONLINE_REFUND_DATE','INFO_CODE'))
BSE_COLUMNS = ','.join(('SECURITY_CODE','SECURITY_NAME_ABBR','APPLY_CODE','APPLY_DATE','SELECT_LISTING_DATE','ISSUE_PRICE','APPLY_NUM_UPPER','APPLY_AMT_UPPER','ONLINE_PAY_DATE','ONLINE_REFUND_DATE','RESULT_NOTICE_DATE','INFO_CODE'))
MAX_BYTES = 5 * 1024 * 1024
CACHE_SECONDS = 15 * 60


def _now():
    return dt.datetime.now(UTC).isoformat(timespec='seconds')


def _day(value):
    if value in (None, '', '-', '--'):
        return None
    return dt.date.fromisoformat(str(value)[:10]).isoformat()


def _validate_url(url):
    p = urllib.parse.urlsplit(url)
    if p.scheme != 'https' or p.hostname != 'datacenter-web.eastmoney.com' or p.username or p.password or p.port not in (None,443):
        raise ValueError('IPO数据请求只允许内置HTTPS数据源')
    return url


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _fetch_json(url):
    _validate_url(url)
    req = urllib.request.Request(url,headers={'User-Agent':'EventAtlas-Calendar/1.1 (personal read-only calendar)','Accept':'application/json','Accept-Encoding':'identity'})
    with urllib.request.build_opener(_SafeRedirect).open(req, timeout=15) as response:
        _validate_url(response.geturl())
        raw = response.read(MAX_BYTES+1)
        if len(raw)>MAX_BYTES:
            raise ValueError('IPO响应过大，不能当作完整名单')
        return json.loads(raw.decode('utf-8-sig'))


def _fetch_rows(report, field, start, end):
    columns = BSE_COLUMNS if report=='RPT_NEEQ_ISSUEINFO_LIST' else MAIN_COLUMNS
    def page(number):
        params={'reportName':report,'columns':columns,'pageSize':'500','pageNumber':str(number),'sortColumns':field+',SECURITY_CODE','sortTypes':'1,1','filter':f"({field}>='{start}')({field}<='{end}')",'source':'WEB','client':'WEB'}
        payload=_fetch_json(API+'?'+urllib.parse.urlencode(params))
        result=payload.get('result')
        if payload.get('success') is not True or not isinstance(result,dict) or not isinstance(result.get('data'),list):
            raise ValueError('IPO来源未返回可核名单：'+str(payload.get('message','结构变化'))[:100])
        return result
    first=page(1)
    total=int(first.get('count',len(first['data'])))
    pages=int(first.get('pages',1))
    if total<0 or pages<0 or pages>10 or total>5000:
        raise ValueError('IPO分页范围超限，未将截断记录当作全量')
    rows=list(first['data'])
    if pages>1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            for result in pool.map(page,range(2,pages+1)):
                if int(result.get('count',total))!=total:
                    raise ValueError('IPO翻页期间总数变化')
                rows.extend(result['data'])
    if len(rows)!=total:
        raise ValueError('IPO分页条数与来源总数不一致')
    keys=[(str(r.get('SECURITY_CODE','')),str(r.get(field,''))) for r in rows]
    if len(keys)!=len(set(keys)):
        raise ValueError('IPO分页含重复记录，不能称完整名单')
    return rows


def _board(row, bse=False):
    market=' '.join(str(row.get(k) or '') for k in ('TRADE_MARKET','MARKET_TYPE_NEW','MARKET','SECUCODE'))
    if bse or row.get('IS_BEIJING') in (1,'1') or '北京' in market or '北交' in market or '.BJ' in market:
        return '北交所'
    if '科创' in market or str(row.get('SECURITY_CODE','')).startswith(('688','689')):
        return '科创板'
    if '创业' in market or str(row.get('SECURITY_CODE','')).startswith(('300','301')):
        return '创业板'
    if '上海' in market or '上交' in market or str(row.get('SECURITY_CODE','')).startswith(('600','601','603','605')):
        return '沪市'
    if '深圳' in market or '深交' in market or str(row.get('SECURITY_CODE','')).startswith(('000','001','002','003')):
        return '深市'
    raise ValueError('不能确定新股交易所；不推断申购时间')


def _number(value):
    if value is None or value in ('','-','--'): return None
    try:
        num=float(value)
    except (TypeError,ValueError): return None
    return num if math.isfinite(num) else None


def _windows(date, board, kind):
    if kind=='subscription':
        times=[('09:30' if board in ('沪市','科创板') else '09:15','11:30'),('13:00','15:00')]
    else:
        times=[('09:15','09:25'),('09:30','11:30'),('13:00','15:00')]
    return [{'start':f'{date}T{a}:00+08:00','end':f'{date}T{b}:00+08:00','label':a+'–'+b} for a,b in times]


def parse_rows(rows, kind, *, bse=False, checked_at=None):
    if kind not in ('subscription','listing'): raise ValueError('未知IPO事件种类')
    checked_at=checked_at or _now()
    events=[]
    for row in rows:
        ticker=str(row.get('SECURITY_CODE') or '')
        name=row.get('SECURITY_NAME_ABBR') or row.get('SECURITY_NAME')
        if not re.fullmatch(r'\d{6}',ticker) or not name:
            raise ValueError('IPO记录缺少合法证券代码或名称')
        board=_board(row,bse=bse)
        # The all-market source also includes BSE; its distinct source is used below.
        if not bse and board=='北交所': continue
        raw_date=row.get('APPLY_DATE') if kind=='subscription' else row.get('SELECT_LISTING_DATE') or row.get('LISTING_DATE')
        day=_day(raw_date)
        if not day: raise ValueError('IPO记录未提供该事件的日期')
        sessions=_windows(day,board,kind)
        price=_number(row.get('ISSUE_PRICE'))
        upper=_number(row.get('APPLY_NUM_UPPER') if bse else row.get('ONLINE_APPLY_UPPER'))
        info=str(row.get('INFO_CODE') or '')
        details={'证券代码':ticker,'申购代码':str(row.get('APPLY_CODE') or ticker),'所属市场':board,
                 '事件类型':'网上申购' if kind=='subscription' else '新股上市交易日',
                 '日期核验状态':'平台日历汇总，未逐只核发行/上市公告；日期可能调整',
                 '时段口径':'交易所网上申购申报时段；非券商提前接单时间' if kind=='subscription' else '交易所普通股票竞价时段，含集合竞价；不是上市仪式举行时间。临时停牌等以交易所公告为准。',
                 '时间规则来源':RULES[board] if kind=='subscription' else BSE_TRADING_RULE if board=='北交所' else 'https://www.sse.com.cn/lawandrules/sselawsrules2025/trade/universal/c/c_20260424_10816492.shtml' if board in ('沪市','科创板') else 'https://docs.static.szse.cn/www/lawrules/rule/trade/current/W020260424690713155663.pdf',
                 '参与方式':'北交所现金申购：申购前应足额存入申购资金；权限及发行公告另核' if board=='北交所' else '沪深网上市值申购：须符合市场市值及相应板块权限；中签后按公告缴款，申购时无需预缴认购款'}
        if kind=='listing': details['原申购方式（仅申购日适用）']=details.pop('参与方式')
        if price is not None: details['发行价（元/股）']=price
        if upper is not None: details['网上申购数量上限（股）']=int(upper) if upper.is_integer() else upper
        for key,label in [('APPLY_DATE','申购日'),('LISTING_DATE','上市日'),('SELECT_LISTING_DATE','北交所上市日'),('BALLOT_PAY_DATE','中签缴款日'),('BALLOT_NUM_DATE','中签/配售结果日'),('RESULT_NOTICE_DATE','发行结果公告日'),('ONLINE_PAY_DATE','网上申购资金缴付日'),('ONLINE_REFUND_DATE','网上申购资金退款日')]:
            value=_day(row.get(key))
            if value: details[label]=value
        amt=_number(row.get('APPLY_AMT_UPPER'))
        if bse and amt is not None: details['顶格申购金额（元）']=amt
        if info and re.fullmatch(r'AN\d+',info):
            details['平台公告入口']=f'https://data.eastmoney.com/notices/detail/{ticker}/{info}.html'
        title=f'{name} · {board}{"新股申购" if kind=="subscription" else "新股上市"}'
        events.append({'id':f'ipo-{kind}-{ticker}-{day}','title':title,'category':'ipo','market':'A股','ipo_market':board,'ipo_kind':kind,
                       'date':day,'time':' / '.join(s['label'] for s in sessions),'display_time':' / '.join(s['label'] for s in sessions)+' 北京时间',
                       'timezone':'Asia/Shanghai','time_precision':'window','time_start':sessions[0]['start'][11:16],'time_end':sessions[-1]['end'][11:16],
                       'start_at':sessions[0]['start'],'end_at':sessions[-1]['end'],'session_windows':sessions,
                       'source_url':SOURCE_BSE if bse else SOURCE_MAIN,'source_name':'东方财富北交所发行日历' if bse else '东方财富沪深新股日历',
                       'source_checked_at':checked_at,'status':'estimated','company':{'name':name,'ticker':ticker,'market_cap':None,'currency':'CNY','cap_asof':None},'details':details})
    return events


def _cache_read(path):
    try:
        if path.stat().st_size>15*1024*1024:return None
        value=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(value.get('events'),list) or not isinstance(value.get('source'),dict): return None
        stamp=dt.datetime.fromisoformat(value['saved_at'])
        if stamp.tzinfo is None: return None
        return value
    except (OSError,ValueError,KeyError,TypeError):return None


def _cached_query(source_id,name,start,end,cache_dir,loader):
    path=Path(cache_dir)/(source_id+'_'+start+'_'+end+'.json')
    old=_cache_read(path)
    if old and 0<=(dt.datetime.now(UTC)-dt.datetime.fromisoformat(old['saved_at'])).total_seconds()<CACHE_SECONDS:
        source=copy.deepcopy(old['source']);source['cache_used']=True
        return copy.deepcopy(old['events']),source
    try:
        events=loader()
        stamp=_now()
        for event in events:event['source_checked_at']=stamp
        source={'id':source_id,'name':name,'status':'ok','last_success':stamp,'source_url':SOURCE_BSE if 'bse' in source_id else SOURCE_MAIN,
                'event_count':len(events),'coverage':f'{start}至{end}，平台当前返回的完整分页；申购和上市分开抓取。北交所使用独立发行表，不代表所有尚未公告的IPO。','error':None,'cache_used':False}
        payload={'saved_at':stamp,'events':events,'source':source}
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_name(path.name+f'.{os.getpid()}.{threading.get_ident()}.tmp')
        temporary.write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False),encoding='utf-8');os.replace(temporary,path)
        return events,source
    except Exception as exc:
        error=type(exc).__name__+': '+str(exc)[:240]
        if old:
            events=copy.deepcopy(old['events'])
            for event in events:
                event['data_stale']=True;event.setdefault('details',{})['刷新状态']='该来源本轮失败，保留原核实时间；不可视作最新申购安排'
            source=dict(old['source'],status='cached',error=error,cache_used=True)
            return events,source
        return [],{'id':source_id,'name':name,'status':'error','last_success':None,'event_count':0,'coverage':f'{start}至{end}来源未取到可核名单，不等于期间没有申购/上市','error':error}


def refresh_ipo(start_date,end_date,cache_dir):
    start,end=_day(start_date),_day(end_date)
    if not start or not end or start>end or (dt.date.fromisoformat(end)-dt.date.fromisoformat(start)).days>366:
        raise ValueError('IPO日历日期范围无效或超过366天')
    tasks=[
        ('ipo-main-subscription','沪深新股网上申购','RPTA_APP_IPOAPPLY','APPLY_DATE','subscription',False),
        ('ipo-main-listing','沪深新股上市','RPTA_APP_IPOAPPLY','LISTING_DATE','listing',False),
        ('ipo-bse-subscription','北交所新股网上申购','RPT_NEEQ_ISSUEINFO_LIST','APPLY_DATE','subscription',True),
        ('ipo-bse-listing','北交所新股上市','RPT_NEEQ_ISSUEINFO_LIST','SELECT_LISTING_DATE','listing',True),
    ]
    def one(task):
        sid,name,report,field,kind,bse=task
        return _cached_query(sid,name,start,end,cache_dir,lambda:parse_rows(_fetch_rows(report,field,start,end),kind,bse=bse))
    events={};sources=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for items,source in pool.map(one,tasks):
            for event in items:
                if start<=event['date']<=end: events[event['id']]=event
            sources.append(source)
    return {'events':sorted(events.values(),key=lambda e:(e['date'],e['ipo_kind']!='subscription',e['ipo_market'],e['id'])),'sources':sources,'fetched_at':_now()}
