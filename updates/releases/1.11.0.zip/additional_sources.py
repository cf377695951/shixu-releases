"""Official NBS release calendar. stdlib only; never extrapolate unpublished dates.

Future records from the annual table remain estimated: the NBS calls the
published dates a preliminary plan. Only a validated parse advances last_success.
"""
from __future__ import annotations

import datetime as dt
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import urllib.parse
import urllib.request

INDEX_URL = 'https://www.stats.gov.cn/xxgk/sjfb/fbrcb/'
KNOWN_URLS = {2026: 'https://www.stats.gov.cn/xw/tjxw/tzgg/202512/t20251224_1962137.html'}
_WEEKDAYS = '一二三四五六日'
_MAX_BYTES = 4 * 1024 * 1024


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')


def _fetch(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != 'https' or parsed.hostname not in ('www.stats.gov.cn', 'stats.gov.cn'):
        raise ValueError('NBS source URL is not an allowed official HTTPS origin')
    req = urllib.request.Request(url, headers={'User-Agent': 'EventAtlas/1.0 (personal economic calendar)', 'Accept': 'text/html'})
    with urllib.request.urlopen(req, timeout=10) as response:
        # Redirects must stay on the official origin as well.
        final = urllib.parse.urlparse(response.geturl())
        if final.scheme != 'https' or final.hostname not in ('www.stats.gov.cn', 'stats.gov.cn'):
            raise ValueError('Unexpected NBS redirect origin')
        body = response.read(_MAX_BYTES + 1)
        if len(body) > _MAX_BYTES:
            raise ValueError('NBS calendar response is too large')
        return body.decode('utf-8-sig')


class _Tables(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.table, self.row, self.cell = [], None, None, None
        self.depth = 0

    def handle_starttag(self, tag, attrs):
        if tag == 'table':
            self.depth += 1
            if self.depth == 1:
                self.table = []
        if self.depth != 1:
            return
        if tag == 'tr':
            self.row = []
        elif tag in ('td', 'th') and self.row is not None:
            attrs = dict(attrs)
            self.cell = {'text': '', 'rowspan': int(attrs.get('rowspan', '1')), 'colspan': int(attrs.get('colspan', '1'))}
            if not 1 <= self.cell['rowspan'] <= 100 or not 1 <= self.cell['colspan'] <= 100:
                raise ValueError('Unreasonable calendar table span')
        elif tag in ('br', 'p') and self.cell is not None:
            self.cell['text'] += ' '

    def handle_endtag(self, tag):
        if self.depth == 1:
            if tag in ('td', 'th') and self.cell is not None:
                self.cell['text'] = re.sub(r'\s+', ' ', self.cell['text']).strip()
                self.row.append(self.cell)
                self.cell = None
            elif tag == 'tr' and self.row is not None:
                self.table.append(self.row)
                self.row = None
            elif tag == 'table':
                self.tables.append(self.table)
                self.table = None
        if tag == 'table':
            self.depth -= 1

    def handle_data(self, text):
        if self.depth == 1 and self.cell is not None:
            self.cell['text'] += text


def _expand(rows):
    """Expand both rowspan and colspan, preserving exact month column positions."""
    occupied, grid = {}, []
    for rn, row in enumerate(rows):
        col = 0
        for cell in row:
            while (rn, col) in occupied:
                col += 1
            for dr in range(cell['rowspan']):
                for dc in range(cell['colspan']):
                    if (rn + dr, col + dc) in occupied:
                        raise ValueError('Overlapping NBS table cells')
                    occupied[rn + dr, col + dc] = cell['text']
            col += cell['colspan']
        width = max((c for r, c in occupied if r == rn), default=-1) + 1
        grid.append([occupied.get((rn, c), '') for c in range(width)])
    return grid


def parse_nbs_calendar(html, year, source_url=None, checked_at=None):
    """Return validated official *planned* releases, without inventing values.

    The March 2026 PMI cell contains both March 4 and March 31; the day/time
    rows also contain empty rowspan cells. These are deliberately not flattened.
    """
    year = int(year)
    source_url = source_url or KNOWN_URLS.get(year)
    checked_at = checked_at or _now()
    if not source_url:
        raise ValueError('No official URL for requested NBS year')
    if not re.search(rf'{year}\s*年[^<]{{0,100}}(?:国家统计局|统计信息)', html):
        raise ValueError('NBS page year/title does not match requested calendar')
    parser = _Tables()
    parser.feed(html)
    candidates = []
    for table in parser.tables:
        grid = _expand(table)
        for rn, row in enumerate(grid):
            normalized = [re.sub(r'\s+', '', x) for x in row]
            if '1月' in normalized and '12月' in normalized and '内容' in normalized:
                month_cols = {m: normalized.index(f'{m}月') for m in range(1, 13)}
                if len(set(month_cols.values())) != 12:
                    raise ValueError('NBS calendar month columns are ambiguous')
                candidates.append((grid, rn, month_cols))
                break
    if not candidates:
        raise ValueError('No valid 12-month NBS calendar table found')
    # The official page repeats identical desktop/mobile tables. Parse each and
    # insist they agree instead of accidentally double-counting the releases.
    parsed_tables = []
    for grid, header_row, month_cols in candidates:
        parsed = {}
        found_metrics = set()
        for rn in range(header_row + 1, len(grid)):
            row = grid[rn]
            if len(row) < 2 or not row[0].strip().isdigit():
                continue
            metric_no, label = int(row[0].strip()), row[1].strip()
            if not 1 <= metric_no <= 40 or not label:
                continue
            if len(row) <= max(month_cols.values()):
                raise ValueError('NBS calendar data row lost a month column')
            date_cells = {m: re.findall(r'(?<!\d)([0-3]?\d)\s*/\s*([一二三四五六日天])', row[col]) for m, col in month_cols.items()}
            if not any(date_cells.values()):
                continue  # This is the companion time row, not another event.
            found_metrics.add(metric_no)
            time_row = grid[rn + 1] if rn + 1 < len(grid) else []
            for month, dates in date_cells.items():
                col = month_cols[month]
                if not dates:
                    continue
                times = re.findall(r'(?<!\d)([0-2]?\d)\s*[:：]\s*([0-5]\d)(?!\d)', time_row[col] if col < len(time_row) else '')
                if len(times) != 1:
                    raise ValueError(f'NBS metric {metric_no}, month {month} has ambiguous/missing release time')
                hour, minute = map(int, times[0])
                if hour > 23:
                    raise ValueError('Invalid NBS release time')
                for day, weekday in dates:
                    date = dt.date(year, month, int(day))
                    if _WEEKDAYS[date.weekday()] != weekday.replace('天', '日'):
                        raise ValueError(f'NBS date/weekday disagreement at {date}')
                    key = f'nbs-{year}-{metric_no:02d}-{month:02d}-{int(day):02d}'
                    title = f'中国 · {label}'
                    details = {'计划性质': '官方年度初步发布计划，届时可能调整', '统计口径': '除PMI外一般发布上月、上季、上年或累计数据；不在日历中猜测实际值或预期值', '原始项目': label, '日程年份': year, '官方表格序号': metric_no}
                    if metric_no == 4 and year == 2026 and month == 3 and int(day) == 4:
                        details['特殊安排'] = '官方注5：因春节假期，2月份采购经理指数于3月4日发布'
                    if metric_no == 1:
                        details['发布类别'] = '年度/季度经济运行（含GDP相关发布）' if month in (1, 4, 7, 10) else '月度国民经济运行'
                    parsed[key] = {'id': key, 'title': title, 'category': 'macro', 'market': '中国', 'date': date.isoformat(), 'time': f'{hour:02d}:{minute:02d}', 'timezone': 'Asia/Shanghai', 'source_url': source_url, 'source_name': '国家统计局', 'status': 'estimated', 'source_checked_at': checked_at, 'details': details}
        # Guard against parsing a header shell, anti-bot page, or truncated table.
        if not {1, 4, 5, 6}.issubset(found_metrics) or len(parsed) < 40:
            raise ValueError('NBS calendar failed minimum metric/count validation')
        parsed_tables.append(parsed)
    first = parsed_tables[0]
    signature = lambda values: {(v['id'], v['title'], v['date'], v['time']) for v in values.values()}
    if any(signature(first) != signature(x) for x in parsed_tables[1:]):
        raise ValueError('Desktop and mobile NBS schedule tables disagree')
    return sorted(first.values(), key=lambda e: (e['date'], e['time'], e['id']))


class _ScheduleLinks(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links, self.href, self.text = {}, None, ''

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.href = dict(attrs).get('href')
            self.text = ''

    def handle_data(self, text):
        if self.href is not None:
            self.text += text

    def handle_endtag(self, tag):
        if tag == 'a' and self.href is not None:
            match = re.search(r'(20\d{2})年国家统计局主要统计信息发布日程表', re.sub(r'\s+', '', self.text))
            if match:
                url = urllib.parse.urljoin(INDEX_URL, self.href)
                p = urllib.parse.urlparse(url)
                if p.hostname in ('www.stats.gov.cn', 'stats.gov.cn'):
                    # The published index may use an HTTP href on the same host.
                    self.links[int(match[1])] = urllib.parse.urlunparse(p._replace(scheme='https'))
            self.href = None


def _cache_read(path):
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('schema') != 1 or not isinstance(data.get('years'), dict):
            return {'schema': 1, 'years': {}}
        return data
    except (OSError, ValueError, TypeError):
        return {'schema': 1, 'years': {}}


def _cache_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, path)


def refresh_additional(start_date, end_date, cache_dir):
    """Refresh NBS official schedules, keeping last valid cache on failure.

    Returns {events, sources, fetched_at}; no other program schedules are changed.
    Index discovery is used for future years; it is never constructed by guessing
    a year into an old URL. A successful HTTP download alone is not a success.
    """
    start, end = dt.date.fromisoformat(str(start_date)), dt.date.fromisoformat(str(end_date))
    if end < start:
        raise ValueError('end_date precedes start_date')
    now = _now()
    cache_path = Path(cache_dir) / 'nbs-calendar.json'
    cache = _cache_read(cache_path)
    urls = dict(KNOWN_URLS)
    errors = []
    try:
        links = _ScheduleLinks()
        links.feed(_fetch(INDEX_URL))
        urls.update(links.links)
        if not links.links:
            errors.append('官方日程索引未识别到年度表链接；仅尝试已核实2026地址')
    except Exception as exc:
        errors.append(f'官方年度索引读取失败：{type(exc).__name__}: {str(exc)[:180]}')
    out, fresh_years, cached_years, missing_years = [], [], [], []
    for year in range(start.year, end.year + 1):
        if year not in urls:
            missing_years.append(year)
            errors.append(f'{year}年官方年度日程未发现；未推算日期')
            # No old-year dates can substitute for a different year.
            continue
        try:
            html = _fetch(urls[year])
            parsed = parse_nbs_calendar(html, year, urls[year], now)
            cache['years'][str(year)] = {'events': parsed, 'last_success': now, 'url': urls[year], 'html_sha256': hashlib.sha256(html.encode()).hexdigest()}
            out.extend(parsed)
            fresh_years.append(year)
        except Exception as exc:
            errors.append(f'{year}年日程获取或解析失败：{type(exc).__name__}: {str(exc)[:200]}')
            old = cache['years'].get(str(year), {})
            if old.get('events') and old.get('last_success'):
                out.extend(old['events'])
                cached_years.append(year)
            else:
                missing_years.append(year)
    if fresh_years:
        try:
            _cache_write(cache_path, cache)
        except OSError as exc:
            errors.append(f'日程已解析，但本地缓存保存失败：{type(exc).__name__}')
    successes = [cache['years'].get(str(y), {}).get('last_success') for y in fresh_years + cached_years]
    last_success = max((x for x in successes if x), default=None)
    if fresh_years and not missing_years and not cached_years:
        status = 'ok' if not errors else 'partial'
    elif fresh_years:
        status = 'partial'
    elif cached_years:
        status = 'cached'
    else:
        status = 'error'
    events = [e for e in out if start.isoformat() <= e['date'] <= end.isoformat()]
    coverage = f'国家统计局官方年度表；新解析年份：{fresh_years or "无"}；缓存年份：{cached_years or "无"}；缺失年份：{missing_years or "无"}。覆盖CPI/PPI/PMI、经济运行、工业、投资、消费等，均为官方初步计划。'
    source = {'id': 'nbs-calendar', 'name': '国家统计局发布日程', 'status': status, 'last_success': last_success, 'coverage': coverage, 'error': '；'.join(errors) or None, 'url': INDEX_URL, 'fetched_at': now, 'count': len(events)}
    return {'events': events, 'sources': [source], 'fetched_at': now}
