(function () {
  'use strict';
  const CATS = {personal:'个人日程',ipo:'A股打新 · 含北交所',season:'节气与节日',astronomy:'星象与天文',crypto:'币圈资料',options:'币圈数据 · 期权',macro:'重要经济数据',earnings:'公司财报',holiday:'市场休市',politics:'政治与选举',unlock:'重大解禁'};
  const MKT_ORDER = ['美股','A股','港股'];
  const $=id=>document.getElementById(id);
  const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pad=n=>String(n).padStart(2,'0');
  // Reuse formatters: creating Intl objects for every company row blocks Edge.
  const dayFormatter=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'});
  const stampFormatter=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',dateStyle:'medium',timeStyle:'short',hour12:false});
  const capFormatter=new Intl.NumberFormat('zh-CN',{maximumFractionDigits:2});
  const stampCache=new Map();
  const today=()=>{const parts=dayFormatter.formatToParts(new Date());const pick=t=>parts.find(p=>p.type===t).value;return `${pick('year')}-${pick('month')}-${pick('day')}`;};
  const dateObj=value=>new Date(value+'T12:00:00Z');
  const dateKey=d=>`${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}`;
  const longDate=value=>{const d=dateObj(value);return `${d.getUTCMonth()+1}月${d.getUTCDate()}日 · ${['周日','周一','周二','周三','周四','周五','周六'][d.getUTCDay()]}`;};
  const safeUrl=value=>{try{const u=new URL(String(value));return u.protocol==='https:'?u.href:null;}catch{return null;}};
  const stamp=value=>{if(!value)return '尚未成功获取';if(/^\d{4}-\d{2}-\d{2}$/.test(String(value)))return String(value)+'（来源仅日期）';if(stampCache.has(value))return stampCache.get(value);const d=new Date(value),label=Number.isNaN(d.getTime())?'来源未给出有效时间':stampFormatter.format(d)+' 北京时间';if(stampCache.size>4096)stampCache.clear();stampCache.set(value,label);return label;};
  const statusLabel=value=>({confirmed:'已确认',estimated:'预计 / 待核',unverified:'待核实',success:'更新成功',ok:'更新成功',cached:'使用缓存',stale:'缓存已过期',error:'更新失败',failed:'更新失败',unavailable:'暂不可用',not_configured:'未接入',unsupported:'未接入',partial:'部分覆盖',seed:'官方核验快照',baseline:'官方核验快照',refreshing:'正在更新',pending:'待核实'}[value]||value||'待核实');
  const initial=today();
  // Only overview rows and the currently requested page live in the renderer.
  // Complete source records, search, sorting and filtering remain in the server.
  const PAGE_SIZE=20;
  const state={
    year:+initial.slice(0,4),month:+initial.slice(5,7),date:initial,
    days:new Map(),day:null,mainCount:0,totalCount:0,pendingCount:0,
    pendingData:null,sources:[],coverage:null,fetched:null,revision:null,
    datasetRevision:null,holdingsByDay:{},selected:null,detailData:null,
    detailLoading:false,detailError:'',detailPage:0,dayPage:0,
    categories:new Set(Object.keys(CATS)),query:'',market:'all',view:'month',
    token:null,loading:true,refreshing:false,error:'',closed:false,poll:null,
    timers:[],holdingOnly:false,watchlist:[],watchlistFactDate:null,
    watchlistNote:'',quotes:{},updates:{status:'checking'},focus:'all',
    monthRequest:0,dayRequest:0,detailRequest:0,pendingRequest:0,
    statusChecking:false,quotesChecking:false,updatesChecking:false,dataRefreshing:false,desktopData:null,desktopBusy:false,desktopTimer:null,desktopDeadline:0,
    earningsData:null,earningsEvent:null,earningsLoading:false,earningsError:'',
    earningsRequest:0,earningsTimer:null,earningsDeadline:0,
    optionsData:null,optionsEvent:null,optionsLoading:false,optionsError:'',optionsRequest:0,optionsTimer:null,optionsDeadline:0,
    almanac:null,almanacDate:null,searchData:null,searchPage:0,searchRequest:0,searchLoading:false,updateNotified:null,macroData:null,macroEvent:null,macroLoading:false,macroError:'',macroRequest:0,macroTimer:null,macroDeadline:0,
    personalEditing:null,personalBusy:false,personalStatus:{},personalStatusTimer:null,personalStatusDeadline:0,removedPage:0,importText:'',importPreview:null,importBusy:false,exportEvent:null,favorites:[],favoriteCapabilities:{},favoritesLoading:false,favoritesError:'',favoritesPage:0,favoritesRequest:0,favoriteBusy:false,reminderEditing:null
  };
  const caches={day:new Map(),detail:new Map(),pending:new Map()};
  const flights=new Map();
  let monthPromise=null,monthUrl=null,lastLoaded=0;
  const perf=()=>window.CalendarPerformance;
  const measure=(label,fn)=>perf()&&perf().measure?perf().measure(label,fn):fn();
  const phase=label=>{if(perf()&&perf().phase)perf().phase(label);};
  function cacheSet(map,key,value,limit=16){map.delete(key);map.set(key,value);while(map.size>limit)map.delete(map.keys().next().value);}
  function clearCaches(){Object.values(caches).forEach(map=>map.clear());}
  function invalidateContentRequests(){
    state.dayRequest++;state.detailRequest++;state.pendingRequest++;
    ['day','detail','pending'].forEach(abortChannel);
    state.day=null;state.pendingData=null;clearCaches();
  }

  function range(){const d=new Date(Date.UTC(state.year,state.month-1,1,12));d.setUTCDate(d.getUTCDate()-((d.getUTCDay()+6)%7));return {start:dateKey(d),end:dateKey(new Date(Date.UTC(state.year,state.month,7,12)))};}
  function params(extra={}){return new URLSearchParams({...range(),market:state.market,categories:[...state.categories].join(','),q:state.query,holding:state.holdingOnly?'1':'0',...extra}).toString();}
  function filterKey(){return [state.year,state.month,state.market,state.holdingOnly,state.query,[...state.categories].join(',')].join('|');}
  function abortChannel(name){const old=flights.get(name);if(old)old.controller.abort();}
  async function getJson(url,options={}){
    const response=await fetch(url,{credentials:'same-origin',cache:'no-store',...options});
    const text=await response.text();
    if(!response.ok){let reason='';try{reason=String(JSON.parse(text).error||'').slice(0,220);}catch{}throw new Error(reason||'服务返回 '+response.status);}
    const started=performance.now();
    const result=JSON.parse(text);
    if(perf()){
      if(perf().mark)perf().mark('JSON '+url.split('?')[0],performance.now()-started);
      if(perf().payload)perf().payload(url.split('?')[0],new TextEncoder().encode(text).length,Array.isArray(result.items)?result.items.length:Array.isArray(result.days)?result.days.length:0);
    }
    return result;
  }
  function requestChannel(name,url){
    const old=flights.get(name);
    if(old&&old.url===url&&!old.controller.signal.aborted)return old.promise;
    if(old)old.controller.abort();
    const controller=new AbortController(),flight={url,controller,promise:null};
    flight.promise=getJson(url,{signal:controller.signal}).finally(()=>{if(flights.get(name)===flight)flights.delete(name);});
    flights.set(name,flight);return flight.promise;
  }
  const post=(url,payload)=>getJson(url,{method:'POST',headers:{'Content-Type':'application/json','X-Calendar-Token':state.token},body:JSON.stringify(payload||{})});
  const daySummary=date=>state.days.get(date)||{date,count:0,holding_count:0,entry_count:0,entries:[]};
  const entries=date=>state.day&&state.day.date===date?state.day.entries||[]:daySummary(date).entries||[];
  const groupTotal=g=>Number(g.total===undefined?g.count:g.total)||0;
  const groupLogos=g=>g.logos||g.items||[];
  const loadingMarkup=label=>'<div class="empty-state" role="status"><strong>'+esc(label||'正在读取')+'</strong><p>日历可继续操作。</p></div>';
  function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,6000);}

  const important=e=>e&&(e.importance==='high'||e.event&&e.event.importance==='high');
  const importanceBadge=e=>important(e)?'<span class="important-badge" title="'+esc(e.importance_reason||'主要政策或经济事件')+'">'+(e.is_personal?'重要':'重磅')+'</span>':'';
  const category=e=>Object.hasOwn(CATS,e.category)?e.category:'macro';
  const isHolding=e=>e.is_holding===true;
  const timePrecision=e=>({date_range:'date_only',broad_window:'window',range:'window'}[e.time_precision]||e.time_precision);
  const cap=e=>{const n=e.company&&e.company.market_cap;return n!==null&&n!==undefined&&n!==''&&Number.isFinite(Number(n))&&Number(n)>0?Number(n):null;};
  const currency=e=>String(e.company&&e.company.currency||'币种未确认');
  function capText(e){const n=cap(e);if(n===null)return '市值源暂不可用';const div=n>=1e12?1e12:n>=1e8?1e8:n>=1e4?1e4:1;return `${capFormatter.format(n/div)}${div===1e12?'万亿':div===1e8?'亿':div===1e4?'万':''} ${currency(e)}`;}
  function timeLabel(e){if(e.time_display)return String(e.time_display).replace(/\s*北京时间[（(]UTC\+8[）)]/g,'');if(timePrecision(e)==='date_only')return '00:00–24:00 · 日期级';if(e.time)return String(e.time);return '尚未核实发布时段';}
  const dateBasis=e=>timePrecision(e)==='date_only'?'北京时间 UTC+8 · 日期级安排，时刻未公开':'北京时间 UTC+8';
  const holdingBadge=e=>isHolding(e)?'<span class="holding-badge">持仓相关</span>':'';
  const badge=e=>`<span class="status-badge ${e.status==='confirmed'?'confirmed':'estimated'}">${e.data_stale?'缓存 · ':''}${esc(statusLabel(e.status))}</span>`;
  function row(e){return `<button type="button" class="day-event-row category-${category(e)} ${important(e)?'important-event':''} ${isHolding(e)?'holding-event':''}" data-event="${esc(e.id)}"><span class="event-time">${esc(timeLabel(e))}<small>北京时间</small></span><span class="event-copy"><span class="event-title"><span class="dot" data-cat="${category(e)}"></span>${esc(e.title)}${importanceBadge(e)}${holdingBadge(e)}</span><span class="event-meta">${esc(e.market||'')} · ${esc(e.source_name||'')}${timePrecision(e)==='date_only'?' · 日期级安排，非精确发布时间':''}</span></span>${badge(e)}</button>`;}
  function logoPath(c){const value=c&&c.logo_url;if(typeof value!=='string')return null;if(/^\/(?:branding|logo)\/[A-Za-z0-9_./-]+$/.test(value)&&!value.includes('..'))return value;return safeUrl(value);}
  function logoMarkup(e,mini=false){const c=e.company||{},path=logoPath(c),ticker=String(c.ticker||'代码未知'),name=String(c.name||e.title||''),chinese=(name.match(/[\u3400-\u9fff]/g)||[]).slice(0,2).join(''),fallback=chinese||(name.match(/[A-Za-z]/g)||[]).slice(0,4).join('').toUpperCase()||'公司';return '<span class="logo-box '+(mini?'mini-logo ':'')+(isHolding(e)?'logo-holding':'')+'" title="'+esc(name)+' · '+esc(ticker)+(path?'':' · 来源未提供图标')+'">'+(path?'<img class="company-logo" src="'+esc(path)+'" alt="'+esc(name)+'标识" decoding="async" width="36" height="36">':'')+'<span class="logo-fallback" '+(path?'hidden':'')+'>'+esc(fallback)+'</span></span>';}
  function uniqueCompanyLogos(items,limit){const seen=new Set(),result=[];for(const e of items){const c=e.company||{},key=String(c.name||c.ticker||e.id).trim().toUpperCase();if(seen.has(key))continue;seen.add(key);result.push(e);if(result.length>=limit)break;}return result;}
  function cellEntry(e,date){const logos=e.category==='earnings'?`<span class="mini-logos">${uniqueCompanyLogos(e.group.items,3).map(c=>logoMarkup(c,true)).join('')}</span>`:'';return `<button type="button" class="day-event category-${e.category} ${e.category==='earnings'?'cell-earnings':''} ${e.is_holding?'holding-event':''} ${important(e.event)?'important-event':''}" data-entry="${esc(e.id)}" data-entry-date="${date}" title="${esc(e.title)}${e.event?' · '+esc(timeLabel(e.event))+' 北京时间':''}"><span class="cell-entry-heading"><span class="event-dot"></span><span>${e.is_holding?'● ':''}${esc(e.title)}${importanceBadge(e.event)}</span>${e.event&&timePrecision(e.event)==='exact'?`<time>${esc(e.event.time||String(e.event.start_at||'').slice(11,16))}</time>`:''}</span>${logos}</button>`;}
  function companyRow(e){const c=e.company||{},capAt=c.cap_asof?stamp(c.cap_asof):c.cap_source_checked_at?'来源未给市值事实时点；获取于 '+stamp(c.cap_source_checked_at):'自动联网获取，不需手动补';return `<button type="button" class="company-row ${isHolding(e)?'holding-event':''}" data-event="${esc(e.id)}">${logoMarkup(e)}<span class="company-copy"><span class="company-name">${esc(c.name||e.title)} ${e.event_type==='earnings_call'?'<small>业绩电话会</small>':''} ${holdingBadge(e)}</span><span class="company-ticker">${esc(c.ticker||'证券代码未确认')} · ${esc(timeLabel(e))} 北京时间 · ${e.data_stale?'缓存 · ':''}${esc(statusLabel(e.status))}</span></span><span class="company-cap ${cap(e)===null?'cap-unavailable':''}">${esc(capText(e))}<small>${cap(e)!==null?esc((c.cap_stale?'缓存 · ':'')+capAt):'自动重试 · 无需你补'}</small></span></button>`;}
  const labels={quantity:'数量',amount:'规模',shares:'解禁股数',total_shares:'总股本',total_ratio:'占总股本',float_ratio:'占解禁前流通股',unlock_ratio:'解禁比例',market_value:'解禁参考市值',volume_multiple:'成交量倍数',shareholders:'解禁对象',type:'类型',note:'说明',notes:'说明',description:'说明',exchange:'交易所',currency:'币种',underlying:'标的',settlement:'交割说明',expiry:'到期时间',expiry_utc:'原始到期时间 UTC',instrument_count:'合约数量',period:'数据期间',actual:'公布值',forecast:'预期值',previous:'前值',verified_at:'核实时间',last_updated:'更新时点',holiday_type:'休市类型',original_date:'原文日期',original_time:'原文时刻',original_timezone:'原文时区',date_basis:'时间口径',scope:'适用范围',confirmation_note:'确认说明',meeting_start:'原文内部会期开始',meeting_end:'原文内部会期结束',official_tentative:'官方暂定安排'};
  function detailText(value,depth=0){if(value===null||value===undefined||value==='')return '来源未提供';if(depth>4)return '长内容请查看原始来源';if(Array.isArray(value))return value.slice(0,30).map(v=>detailText(v,depth+1)).join('；')+(value.length>30?'；更多内容请查看原始来源':'');if(typeof value==='object')return Object.entries(value).slice(0,40).map(([k,v])=>(labels[k]||k)+'：'+detailText(v,depth+1)).join('；');const text=String(value);return text.length>4000?text.slice(0,4000)+'…（完整内容见原始来源）':text;}
  const mobileDetails=()=>Boolean(window.matchMedia&&window.matchMedia('(max-width:1099px)').matches);
  function prettyCoverage(v){if(typeof v==='string'&&v.trim().startsWith('[')){try{return prettyCoverage(JSON.parse(v));}catch{return v;}}if(Array.isArray(v))return v.map(x=>x&&x.name?`${x.name}：${x.from||''}—${x.through||''}。${x.note||''}`:detailText(x)).join('；');return detailText(v);}
  function renderSources(){if(state.closed)return;const bad=state.sources.filter(s=>s.error||['error','failed','unavailable','not_configured','unsupported','stale','partial','cached'].includes(s.status));$('connectionDot').className='connection-dot '+(state.error?'failed':state.refreshing?'pending':bad.length?'partial':state.fetched?'ok':'pending');$('connectionTitle').textContent=state.loading?'正在读取日历':state.error?'当前连接异常，保留已获取记录':state.refreshing?'正在联网刷新':bad.length?'部分来源覆盖有限，请留意核实状态':'已读取有来源的日程';$('connectionText').textContent=state.error||`数据集更新 ${stamp(state.fetched)} · 主日历 ${state.mainCount} 条 · 待核实 ${state.pendingCount} 条`;$('refreshButton').disabled=state.refreshing||!state.token;$('refreshButton').textContent=state.refreshing?'↻ 更新中…':'↻ 联网刷新';$('coverageSummary').textContent=(state.coverage?prettyCoverage(state.coverage):'未收录不等于没有事件；每源覆盖与错误分别列示。')+' 运行期间自动联网：日历每15分钟检查，近期宏观公布值后台核对；以各来源实际成功时间为准。';if($('sourcesDialog').open)$('sourceList').innerHTML=state.sources.map(s=>{const link=safeUrl(s.source_url||s.url);return `<section class="source-card"><div class="source-card-head"><strong>${esc(s.name||s.id||'来源')}</strong><span class="status-badge">${esc(statusLabel(s.status))}</span></div><p>${esc(prettyCoverage(s.coverage||'覆盖未提供'))}</p><small>上次成功：${esc(stamp(s.last_success||s.source_checked_at||s.checked_at))}</small>${s.error?`<p class="source-error">${esc(s.error)}</p>`:''}${link?`<a class="source-link" href="${esc(link)}" target="_blank" rel="noopener noreferrer">原始来源 ↗</a>`:''}</section>`;}).join('')||'<p>尚未获取来源状态。</p>';renderQuotes();}
  const UPDATE_LABELS={checking:'正在检查更新',current:'当前已是最新版',available:'发现新版本，准备后台下载',downloading:'正在后台下载更新',ready:'更新已校验，退出日历后下次打开生效',offline:'暂时无法连接更新源，当前日历照常使用',unconfigured:'更新源尚未配置',unavailable:'更新源暂不可用',error:'更新未完成，当前版本继续使用'};
  function renderUpdates(){const u=state.updates||{},label=UPDATE_LABELS[u.status]||'尚未检查更新';$('updateStatus').textContent=(u.current_version?'V'+u.current_version+' · ':'')+label+(u.latest_version&&u.latest_version!==u.current_version?' · V'+u.latest_version:'');$('updateStatus').title=u.error||u.message||(u.checked_at?'检查于 '+stamp(u.checked_at):'');$('updateButton').disabled=['checking','downloading'].includes(u.status)||!state.token;$('updateButton').textContent=u.status==='ready'?'更新已就绪':'检查更新';const found=Boolean(u.latest_version&&u.latest_version!==u.current_version&&['available','downloading','ready'].includes(u.status));$('updateBadge').hidden=!found;$('updateBadge').textContent=found?(u.status==='ready'?'● 新版本已就绪':'● 发现新版本')+' '+u.latest_version:'';$('updateArea').classList.toggle('has-update',found);if(found&&state.updateNotified!==u.latest_version){state.updateNotified=u.latest_version;toast('发现时序 '+u.latest_version+'：'+(u.status==='ready'?'更新已就绪，退出并重开即可生效。':'正在后台准备更新，左下角可查看进度。'));}}
  async function checkUpdates(manual=false){if(state.closed)return;try{if(manual){state.updates={...state.updates,status:'checking'};renderUpdates();}state.updates=manual?await post('/api/updates/check'):await getJson('/api/updates/status');renderUpdates();if(manual&&state.updates.status==='ready')toast('更新包已校验；退出本日历后，下次打开自动应用。');}catch(e){state.updates={...state.updates,status:'offline',error:'更新检查失败：'+e.message};renderUpdates();}}
  function quoteRefreshNote(q){
    const source=q.source&&typeof q.source==='object'?q.source:q;
    const failed=Number(source.failed_count)||Object.keys(source.errors||{}).length;
    const invalid=Array.isArray(source.invalid)?source.invalid.length:Number(source.unsupported_count)||0;
    const raw=String(q.error||q.last_error||source.error||'');
    const legacy=raw.match(/(\d+)个行情未刷新[、，, ]+(\d+)个代码未支持/);
    const missing=Number(source.missing_count)||0,stale=Number(source.stale_count)||0;
    const count=failed||(legacy?Number(legacy[1]):0)||missing||stale;
    const unsupported=invalid||(legacy?Number(legacy[2]):0);
    const parts=[];
    if(count)parts.push('本轮'+count+'家公司数据暂未更新，继续显示上次数据并自动重试。');
    if(unsupported)parts.push(unsupported+'家公司的代码暂无法由当前数据源识别，程序会继续核对。');
    if(parts.length)return parts.join(' ');
    if(legacy)return '';
    if(raw&&/尚无有效总市值/.test(raw)){const n=raw.match(/(\d+)/);return (n?n[1]+'家':'部分')+'公司暂未取得市值数据，程序会自动重试。';}
    if(raw)return '部分公司数据暂未更新，继续显示上次数据并自动重试。';
    return '';
  }
  function renderQuotes(){
    const q=state.quotes||{},busy=Boolean(q.refreshing||state.dataRefreshing),at=q.last_success||q.fetched_at;
    $('quotesSummary').textContent='数据更新时间：'+stamp(at)+' · 公司市值'+(q.refreshing?'正在更新':'在交易期间每30分钟自动更新');
    $('quotesRefresh').disabled=busy||state.refreshing||!state.token;
    $('quotesRefresh').textContent=busy||state.refreshing?'↻ 数据更新中…':'↻ 刷新数据';
    $('quotesError').textContent=quoteRefreshNote(q);
    $('quotesError').hidden=!$('quotesError').textContent;
  }
  function renderDesktop(){
    const d=state.desktopData||{},busy=state.desktopBusy||['running','repairing','pending','checking'].includes(d.state),supported=d.supported===true;
    $('installDirectory').value=d.install_dir||'尚未读取到安装位置';
    $('desktopError').textContent=d.error?String(d.error).slice(0,700):'';
    $('desktopError').hidden=!d.error;
    $('desktopStatus').textContent=state.desktopBusy?'正在检查本机桌面入口…':d.message||(!supported?'此预览环境不提供Windows桌面操作。':d.error?'桌面入口尚未修复：'+String(d.error).slice(0,180):busy?'正在修复桌面入口，请稍候。':['ready','ok','success','repaired'].includes(d.state)?'桌面入口已就绪。使用“时序”即可打开本安装。':'可以打开安装文件夹，或修复这份安装的桌面图标。');
    $('repairDesktop').disabled=!supported||busy||!state.token;
    $('openInstallFolder').disabled=!supported||!d.install_dir||!state.token;
  }
  async function checkDesktop(){
    if(state.closed||state.desktopBusy)return;state.desktopBusy=true;renderDesktop();
    try{state.desktopData=await getJson('/api/desktop/status');}
    catch(error){state.desktopData={...(state.desktopData||{}),error:'暂时无法读取桌面状态',message:'暂时无法读取桌面状态，请稍后再展开。'};}
    finally{state.desktopBusy=false;renderDesktop();}
    clearTimeout(state.desktopTimer);state.desktopTimer=null;
    if($('desktopTools').open&&Date.now()<state.desktopDeadline&&['running','repairing','pending','checking'].includes((state.desktopData||{}).state))state.desktopTimer=setTimeout(checkDesktop,1500);
  }
  async function repairDesktop(){
    if(state.closed||state.desktopBusy||!state.token||!state.desktopData||!state.desktopData.supported)return;
    state.desktopBusy=true;renderDesktop();
    try{const data=await post('/api/desktop/repair');state.desktopData=data.desktop||data;state.desktopDeadline=Date.now()+60000;toast('已请求修复本安装的桌面入口，日历可继续使用。');}
    catch(error){state.desktopData={...state.desktopData,error:error.message,message:'桌面入口修复未完成：'+String(error.message).slice(0,180)};}
    finally{state.desktopBusy=false;renderDesktop();}
    clearTimeout(state.desktopTimer);state.desktopTimer=setTimeout(checkDesktop,1200);
  }
  async function openInstallFolder(){
    if(state.closed||!state.token||!state.desktopData||!state.desktopData.supported)return;
    try{await post('/api/desktop/open-folder');toast('已请求打开当前安装文件夹。');}catch(error){toast('文件夹暂时无法打开：'+String(error.message).slice(0,160));}
  }
  async function refreshData(){
    if(state.closed||state.dataRefreshing||!state.token)return;
    state.dataRefreshing=true;renderQuotes();
    try{
      const calendarAlreadyUpdating=state.refreshing;
      const results=await Promise.allSettled([refresh(false),post('/api/quotes/refresh')]);
      const calendarRequested=calendarAlreadyUpdating||results[0].status==='fulfilled'&&Boolean(results[0].value);
      if(results[1].status==='fulfilled')await checkQuotes();
      else{state.quotes={...state.quotes,error:'公司数据暂未更新，程序会自动重试。'};}
      toast(calendarRequested?(results[1].status==='rejected'?'日程刷新已请求；公司数据暂未更新，将自动重试。':'已请求刷新日程与公司数据，日历可继续使用。'):(results[1].status==='fulfilled'?'已请求更新公司数据；日程暂未更新，请稍后重试。':'本次数据刷新未完成，继续显示上次数据，请稍后重试。'));
    }finally{state.dataRefreshing=false;renderQuotes();}
  }
  function openWatchlist(){$('watchlistInput').value=state.watchlist.map(x=>typeof x==='string'?x:[x.market,x.ticker,x.name||''].join(',')).join('\n');$('watchlistFactDate').value=state.watchlistFactDate||today();$('watchlistError').textContent='';$('watchlistDialog').showModal();}
  function parseWatchlist(text){const rows=[];for(const line of text.split(/\r?\n/)){if(!line.trim())continue;const parts=line.split(/[,，\t]+/).map(x=>x.trim());if(parts.length<2||!['A股','美股','港股'].includes(parts[0])||!parts[1]||parts[1].length>24)throw new Error('每行填写“市场,证券代码,名称”，市场为 A股、美股或港股。');rows.push({market:parts[0],ticker:parts[1],name:parts[2]||''});}if(rows.length>100)throw new Error('本机持仓列表最多100个证券代码。');return rows;}
  function watchlistPayload(text,date){
    const symbols=parseWatchlist(text),parsed=new Date(date+'T12:00:00Z');
    if(!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(date)||Number.isNaN(parsed.getTime())||parsed.toISOString().slice(0,10)!==date)throw new Error('请填写有效的持仓资料提供日期。');
    return {symbols,fact_date:date};
  }
  function applyBootstrap(c){state.token=c.token||null;if(perf()&&perf().setSession)perf().setSession(state.token);if(c.version)state.updates.current_version=c.version;state.watchlist=Array.isArray(c.watchlist)?c.watchlist:c.watchlist&&c.watchlist.symbols||c.symbols||[];state.watchlistFactDate=c.watchlist_fact_date||c.watchlist&&c.watchlist.fact_date||c.fact_date||null;state.watchlistNote=c.watchlist&&c.watchlist.note||'';}
  const isEarnings=e=>Boolean(e&&e.category==='earnings'&&e.company);
  function metricUnit(value){const text=String(value||'').trim();return /^(USD|US\$|美元|美金|\$)$/i.test(text)?'USD':/^(CNY|RMB|人民币|元)$/i.test(text)?'CNY':/^(HKD|港元|港币)$/i.test(text)?'HKD':text;}
  function metricKind(m){const text=String(m.key||m.label||'').toLowerCase(),label=String(m.label||'').toLowerCase();if(/adj.?eps|调整后.*每股|调整后eps/.test(text+' '+label))return 'adj_eps';return /^(eps|eps预期|每股收益|每股盈利)$/.test(text)?'eps':text;}
  const metricIdentity=m=>[metricKind(m),conciseMetricBasis(m.basis),metricUnit(m.unit)].join('|');
  function earningsMetrics(data){
    const rows=new Map();
    for(const [kind,list] of [['expected',data.expectations],['actual',data.actuals]]){
      for(const m of (Array.isArray(list)?list:[]).slice(0,8)){
        if(!m||typeof m!=='object')continue;
        const key=metricIdentity(m),kindName=metricKind(m),row=rows.get(key)||{label:kindName==='eps'?'EPS':kindName==='adj_eps'?'调整后EPS':m.label||m.key||'指标',basis:m.basis||'',unit:metricUnit(m.unit)};
        row[kind]=m;rows.set(key,row);
      }
    }
    return [...rows.values()].slice(0,10);
  }
  function metricFigure(m){
    if(!m||m.value===null||m.value===undefined||m.value==='')return '<span class="earnings-value missing">尚未获取</span>';
    const value=String(m.value).slice(0,100)+(m.unit?' '+String(m.unit).slice(0,30):'');
    return '<span class="earnings-value">'+esc(value)+'</span>';
  }
  function conciseMetricBasis(value){
    const text=String(value||'');
    if(!text||/未|待核|未知|不明|unknown|unspecified/i.test(text))return '口径待核';
    if(/non[ -]?gaap|\badj\b|adjusted|调整后|非\s*GAAP/i.test(text))return '非GAAP';
    if(/\bGAAP\b/i.test(text))return 'GAAP';
    if(/\bIFRS\b/i.test(text))return 'IFRS';
    return '口径待核';
  }
  function earningsLiveMarkup(e,data){
    data=data||{};
    const rows=earningsMetrics(data),busy=state.earningsLoading||data.status==='refreshing'&&!state.earningsError&&Date.now()<state.earningsDeadline;
    const points=(Array.isArray(data.focus_points)&&data.focus_points.length?data.focus_points:['营收、每股收益与市场预期的差异','核心业务增长、利润率与现金流','下一季度指引及资本开支']).slice(0,3);
    const articles=(Array.isArray(data.articles)?data.articles:[]).slice(0,5);
    const offline=data.status==='offline',error=offline?'':state.earningsError||data.error;
    const metricNotes=[['expectations','市场预期'],['actuals','实际公布']].flatMap(([key,kind])=>(Array.isArray(data[key])?data[key]:[]).slice(0,8).filter(m=>m&&typeof m==='object').map(m=>({...m,note_kind:kind}))).slice(0,16);
    return '<div class="earnings-section-head"><h3>预期与实际</h3><span class="earnings-stage '+(data.released?'is-released':'')+'">'+(data.released?'快讯已报 · 待公司公告核验':busy?'正在联网核实':'按需核实')+'</span></div>'+
      '<div class="earnings-comparison"><div class="earnings-comparison-head"><span>核心指标</span><span>市场预期</span><span>实际公布</span></div>'+(rows.length?rows.map(r=>'<div class="earnings-comparison-row"><span class="earnings-metric-name">'+esc(r.label)+'<small>'+esc(conciseMetricBasis(r.basis))+'</small></span><span>'+metricFigure(r.expected)+'</span><span>'+metricFigure(r.actual)+'</span></div>').join(''):'<div class="earnings-unavailable">'+(busy?'正在查找这家公司本期财报的预期和披露。':'尚未取得可匹配本期、同口径的数字。')+'<small>未取得的指标留空；下方可查看已找到的来源。</small></div>')+'</div>'+
      (metricNotes.length?'<details class="earnings-metric-notes"><summary>指标口径与时点</summary>'+metricNotes.map(m=>{const link=safeUrl(m.source_url);return '<p><strong>'+esc(m.note_kind)+' · '+esc(m.label||m.key||'指标')+'</strong><br>'+esc(m.basis||'口径待核')+'<br>'+esc(stamp(m.asof))+(link?'<br><a href="'+esc(link)+'" target="_blank" rel="noopener noreferrer">指标来源 ↗</a>':'')+'</p>';}).join('')+'</details>':'')+
      '<section class="earnings-focus"><div class="earnings-section-head"><h3>'+(points.length===3?'重点看这三项':'重点关注')+'</h3><small>研究关注点</small></div><ol>'+points.map(p=>'<li>'+esc(String(p).slice(0,240))+'</li>').join('')+'</ol></section>'+
      '<section class="earnings-news"><div class="earnings-section-head"><h3>财报快讯与原文</h3><small>方程式新闻</small></div>'+(articles.length?articles.map(a=>{const url=safeUrl(a.url),source=safeUrl(a.source_url);return '<article class="earnings-article">'+(url?'<a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+esc(String(a.title||'查看快讯').slice(0,240))+' ↗</a>':'<strong>'+esc(String(a.title||'快讯').slice(0,240))+'</strong>')+'<small>新闻快讯 · '+esc(a.source_name||'方程式新闻')+' · '+esc(stamp(a.published_at))+'</small>'+(source?'<a class="earnings-original" href="'+esc(source)+'" target="_blank" rel="noopener noreferrer">原始来源 ↗</a>':'')+'</article>';}).join(''):'<p class="earnings-empty-news">'+(busy?'正在检索相关快讯…':'尚未找到与该公司、本期披露匹配的快讯。')+'</p>')+'</section>'+
      '<div class="earnings-live-foot"><span role="status">'+esc(offline?'缓存展示 · 当前预览未联网':busy?'联网获取中，日历可继续操作':error?(data.last_success_at?'刷新失败，保留上次结果':'本次获取未完成'):data.checked_at?'核实于 '+stamp(data.checked_at):'打开时自动查询；仅更新当前公司')+'</span><button class="button earnings-refresh" type="button" data-refresh-earnings '+(busy?'disabled':'')+'>'+(busy?'获取中…':'刷新本公司')+'</button></div>'+
      (error?'<p class="earnings-fetch-note">'+esc(String(error).slice(0,200))+'</p>':'')+
      '<p class="earnings-provenance">'+esc(data.provenance_note||'快讯属于新闻来源；财报期、指标口径和实际数字须以公司公告核验。')+'</p>';
  }
  function earningsEvidenceMarkup(e,data){
    const c=e.company||{},fields=Object.entries(e.details||{}),link=safeUrl(e.source_url);
    const facts=[['安排来源',e.source_name||'来源未提供'],['安排状态',statusLabel(e.status)],['来源核实',stamp(e.source_checked_at||e.verified_at)],['参考总市值',capText(e)],['市值事实时点',c.cap_asof?stamp(c.cap_asof):'来源未给出'],...fields.map(([k,v])=>[labels[k]||k,detailText(v)])];
    return '<details class="earnings-evidence"><summary>来源与核实信息 <span>展开</span></summary><div>'+(link?'<a class="source-link" href="'+esc(link)+'" target="_blank" rel="noopener noreferrer">'+esc(e.source_name||'日程来源')+' ↗</a>':'')+'<dl class="detail-fields">'+facts.map(([k,v])=>'<div class="field-row"><dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl>'+((data&&data.expectations||[]).concat(data&&data.actuals||[]).filter(m=>m&&m.asof).map(m=>'<p class="earnings-provenance">'+esc(m.label||m.key||'指标')+' · '+esc(m.basis||'口径未标明')+' · '+esc(stamp(m.asof))+'</p>').join(''))+'</div></details>';
  }
  function earningsDetailMarkup(e){
    const c=e.company||{},data=state.earningsEvent===e.id?state.earningsData:null,schedule=data&&data.schedule||{},exact=timePrecision(e)==='exact',label=schedule.label||timeLabel(e);
    return '<div class="detail-eyebrow category-earnings">公司财报 '+holdingBadge(e)+' '+badge(e)+'</div><div class="earnings-issuer">'+logoMarkup(e)+'<div><h2 class="detail-title">'+esc(c.name||e.title)+'</h2><p>'+esc(c.ticker||'')+'<span data-earnings-period>'+(data&&data.report_period?' · '+esc(data.report_period):'')+'</span></p></div></div>'+
      '<div class="earnings-when"><span>北京时间 · UTC+8</span><strong>'+esc(e.date)+'<br>'+esc(label)+'</strong><small>'+esc(schedule.status==='confirmed'?'已核实安排':exact?'精确时刻以公司最新公告为准':timePrecision(e)==='date_only'?'仅确认日期，具体时刻未公开':'发布时段；公司未确认精确时刻')+'</small></div>'+
      '<div class="earnings-live" data-earnings-live="'+esc(e.id)+'">'+earningsLiveMarkup(e,data)+'</div>'+earningsEvidenceMarkup(e,data);
  }
  const isOptions=e=>Boolean(e&&e.category==='options');
  const knownNumber=value=>(typeof value==='number'||typeof value==='string'&&value.trim()!=='')&&Number.isFinite(Number(value));
  function optionFigure(value,unit=''){return knownNumber(value)?capFormatter.format(Number(value))+(unit?' '+esc(unit):''):'尚未取得';}
  function optionNotional(value){if(!knownNumber(value))return '尚未取得';const n=Number(value),div=n>=1e8?1e8:n>=1e4?1e4:1,unit=div===1e8?'亿美元':div===1e4?'万美元':'美元';return capFormatter.format(n/div)+unit;}
  function optionsLiveMarkup(e,data){
    data=data||{};
    const busy=state.optionsLoading||data.status==='refreshing'&&!state.optionsError&&Date.now()<state.optionsDeadline;
    const error=state.optionsError||data.error,offline=data.status==='offline';
    const values=[['最大痛点',optionFigure(data.max_pain,data.max_pain_currency||'USD'),'该到期日持仓计算'],['到期名义规模',optionNotional(data.notional_usd),'按标的指数价折算'],['未平仓量 OI',optionFigure(data.total_oi,data.oi_unit||data.asset||''),'只计算本次到期合约'],['Put / Call',optionFigure(data.put_call_ratio),'未平仓量比值']];
    return '<div class="options-headline"><span class="earnings-stage">'+esc(data.venue||'Deribit')+' · '+(busy?'正在核实':offline?'缓存展示':data.status==='partial'?'部分覆盖':'持仓快照')+'</span><small>'+esc(data.asof?'数据时点 '+stamp(data.asof):'尚无有效持仓快照')+'</small></div><div class="options-metrics">'+values.map(([label,value,note])=>'<div class="option-metric"><span>'+label+'</span><strong class="'+(value==='尚未取得'?'missing':'')+'">'+value+'</strong><small>'+note+'</small></div>').join('')+'</div><div class="options-oi-row"><span>Call <strong>'+optionFigure(data.call_oi,data.oi_unit||'')+'</strong></span><span>Put <strong>'+optionFigure(data.put_oi,data.oi_unit||'')+'</strong></span></div>'+
      '<p class="option-scope">'+esc(data.coverage||'仅Deribit本次到期、指定结算币种的期权；不是全市场规模。')+'</p>'+(!knownNumber(data.max_pain)?'<p class="earnings-fetch-note">'+(busy?'正在读取本次到期持仓，完成后填入。':'最大痛点尚无可核实数据，不以合约个数代替仓位规模。')+'</p>':'')+
      '<div class="earnings-live-foot"><span role="status">'+esc(offline?'缓存展示 · 当前未联网':busy?'后台读取中，日历可继续操作':error?(data.last_success_at?'刷新失败，保留原快照':'本次读取未完成'):data.checked_at?'核实于 '+stamp(data.checked_at):'点开后按需联网')+'</span><button type="button" class="button earnings-refresh" data-refresh-options '+(busy?'disabled':'')+'>'+(busy?'读取中…':'刷新持仓数据')+'</button></div>'+(!offline&&error?'<p class="earnings-fetch-note">'+esc(String(error).slice(0,220))+'</p>':'')+
      '<details class="earnings-evidence"><summary>计算方法与来源 <span>展开</span></summary><p class="earnings-provenance">'+esc(data.methodology||'最大痛点为持仓静态计算指标，不是价格预测；缺少完整持仓时不输出。')+'</p>'+(data.notional_basis?'<p class="earnings-provenance">'+esc(data.notional_basis)+'</p>':'')+(data.index_price!==null&&data.index_price!==undefined?'<p class="earnings-provenance">标的指数价：'+optionFigure(data.index_price,'USD')+'</p>':'')+(Array.isArray(data.source_urls)?data.source_urls:[]).map(u=>{const link=safeUrl(typeof u==='string'?u:u.url);return link?'<p><a class="source-link" href="'+esc(link)+'" target="_blank" rel="noopener noreferrer">Deribit数据来源 ↗</a></p>':'';}).join('')+'</details>';
  }
  function optionsDetailMarkup(e){const data=state.optionsEvent===e.id?state.optionsData:null;return '<div class="detail-eyebrow category-options">期权到期 '+badge(e)+(e.expiry_tier==='monthly'||e.expiry_tier==='quarterly'?'<span class="expiry-tier">'+esc(e.expiry_label||(e.expiry_tier==='quarterly'?'季度到期':'月度到期'))+'</span>':'')+'</div><h2 class="detail-title">'+esc(e.title)+'</h2><div class="earnings-when"><span>到期时间 · 北京时间 UTC+8</span><strong>'+esc(e.date)+' '+esc(timeLabel(e))+'</strong></div><div data-options-live="'+esc(e.id)+'">'+optionsLiveMarkup(e,data)+'</div>'+evidenceMarkup(e);}
  function isEconomic(e){return Boolean(e&&e.category==='macro'&&!/FOMC|美联储/i.test(e.title||'')&&(/中国.*(?:居民消费价格|工业生产者|采购经理|规模以上工业生产|工业增加值|国民经济运行|社会消费|工业经济效益|固定资产投资)/.test(e.title||'')||/美国.*(?:CPI|非农|PCE|GDP)/i.test(e.title||'')));}
  function isMacro(e){
    if(isEconomic(e))return true;
    if(!e||e.category!=='macro'||!/FOMC|联邦公开市场委员会/i.test(String(e.title||''))||!/决议|利率决定|rate decision|新闻发布会|记者会|press conference|纪要|minutes/i.test(String(e.title||''))||!['exact','minute','second'].includes(timePrecision(e)))return false;
    const raw=String(e.start_at||''),instant=Date.parse(raw);
    return Boolean(/(?:Z|[+-]\d\d:\d\d)$/.test(raw)&&Number.isFinite(instant)&&new Date(instant+8*3600000).toISOString().slice(0,10)===e.date);
  }
  function macroValue(value,unit,missing='尚未取得'){if(value===null||value===undefined||value==='')return '<span class="earnings-value missing">'+esc(missing)+'</span>';const text=String(value).slice(0,100),suffix=unit&&!(String(unit)==='%'&&text.includes('%'))?String(unit).slice(0,25):'';return '<span class="earnings-value">'+esc(text)+(suffix?' <small>'+esc(suffix)+'</small>':'')+'</span>';}
  function macroLiveMarkup(e,data){
    if(isEconomic(e))return economicMarkup(e,data);
    data=data||{};
    const busy=state.macroLoading||data.status==='refreshing'&&!state.macroError&&Date.now()<state.macroDeadline;
    const offline=data.status==='offline',error=offline?'':state.macroError||data.error;
    const metrics=(Array.isArray(data.metrics)?data.metrics:[]).filter(x=>x&&typeof x==='object').slice(0,6),articles=(Array.isArray(data.articles)?data.articles:[]).filter(x=>x&&typeof x==='object').slice(0,6);
    const stance=data.stance&&typeof data.stance==='object'?data.stance:{},availableSignals=(Array.isArray(stance.evidence)?stance.evidence:[]).filter(x=>typeof x==='string'&&x.trim()||x&&typeof x==='object'&&x.text).slice(0,6),signals=[];
    // Include both directions when the summary says mixed, instead of showing
    // three similar quotations and hiding the reason for the disagreement.
    for(const direction of ['偏鹰线索','缓和线索','分歧线索']){const signal=availableSignals.find(x=>x&&x.signal===direction);if(signal&&!signals.includes(signal))signals.push(signal);}
    for(const signal of availableSignals){if(signals.length>=3)break;if(!signals.includes(signal))signals.push(signal);}
    const stanceLabel=signals.length?String(stance.label||'待判断'):'待判断',stanceClass=({'偏鹰信号':'hawkish','偏鸽信号':'dovish','偏鸽 / 缓和信号':'dovish','信号分歧':'mixed'})[stanceLabel]||'unknown';
    const previews=(Array.isArray(data.preview)?data.preview:[]).filter(x=>x&&typeof x==='object'&&x.text).slice(0,2);
    const impacts=(Array.isArray(data.impact_scenarios)?data.impact_scenarios:[]).filter(x=>x&&typeof x==='object').slice(0,3);
    const points=(Array.isArray(data.focus_points)?data.focus_points:[]).slice(0,3);
    const official=(Array.isArray(data.official_sources)?data.official_sources:[]).filter(x=>typeof x==='string'||x&&typeof x==='object').slice(0,5);
    const verification=(offline?'缓存资料 · ':'')+(metrics.some(m=>m.verification==='官方已核验')?'含官方核验数据':metrics.some(m=>m.actual!==null&&m.actual!==undefined&&m.actual!=='')?'快讯已报 · 待官方核验':busy?'正在联网查询':'按本次会议核实');
    return '<div class="earnings-section-head"><h3>预期与结果</h3><span class="earnings-stage">'+esc(verification)+'</span></div>'+
      (previews.length?'<section class="macro-preview"><strong>会前观点</strong>'+previews.map(v=>{const url=safeUrl(v.source_url);return '<p>'+esc(String(v.text).slice(0,350))+'</p><small>'+esc(v.source_name||'来源前瞻')+' · '+esc(stamp(v.asof))+(url?' <a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">原文 ↗</a>':'')+'</small>';}).join('')+'<small class="macro-preview-basis">来源前瞻观点，不等于市场一致预期或利率概率。</small></section>':'')+
      '<div class="earnings-comparison macro-comparison"><div class="earnings-comparison-head"><span>关注指标</span><span>会议前预期</span><span>实际公布</span></div>'+(metrics.length?metrics.map(m=>'<div class="earnings-comparison-row"><span class="earnings-metric-name">'+esc(m.label||m.key||'指标')+(m.previous!==null&&m.previous!==undefined&&m.previous!==''?'<small>前值 '+esc(m.previous)+(m.unit?' '+esc(m.unit):'')+'</small>':'')+'</span><span>'+macroValue(m.expected,m.unit,'未取得可靠预期')+'</span><span>'+macroValue(m.actual,m.unit)+'</span></div>').join(''):'<div class="earnings-unavailable">'+(busy?'正在核对这次会议的预期与公布结果。':'尚未取得与本次会议匹配的指标。')+'<small>缺少可靠来源的数字不填入；下方可查看原文。</small></div>')+'</div>'+
      '<section class="macro-stance '+stanceClass+'"><div class="earnings-section-head"><h3>政策信号</h3><strong class="stance-label">'+esc(stanceLabel)+'</strong></div>'+(signals.length?signals.map(v=>{const text=typeof v==='string'?v:v.text,url=safeUrl(typeof v==='object'&&v.url);return '<p class="macro-signal">'+esc(String(text||'').slice(0,420))+(url?' <a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">原文 ↗</a>':'')+(typeof v==='object'&&v.asof?'<small>'+esc(v.source_name||'原文信号')+' · '+esc(stamp(v.asof))+'</small>':'')+'</p>';}).join(''):'<p class="macro-signal">尚无足够的同场会议文本信号，不凭加息或降息单独判断鹰鸽。</p>')+'<small>'+esc(stance.basis||'依据会议文本提取信号；不等同于相对市场预期的鹰鸽评价。')+'</small></section>'+
      (points.length?'<section class="earnings-focus"><div class="earnings-section-head"><h3>重点关注</h3></div><ol>'+points.map(v=>'<li>'+esc(String(v).slice(0,250))+'</li>').join('')+'</ol></section>':'')+
      (impacts.length?'<section class="macro-impacts"><div class="earnings-section-head"><h3>可能影响哪些资产</h3><small>条件情景 · 研究模板</small></div>'+impacts.map(v=>'<article><strong>'+esc(String(v.condition||'观察条件').slice(0,160))+'</strong>'+(v.assets?'<span>'+esc(Array.isArray(v.assets)?v.assets.join(' · '):v.assets)+'</span>':'')+'<p>'+esc(String(v.text||'').slice(0,420))+'</p></article>').join('')+'<small>这是条件分析，不代表已发生的行情，也不保证涨跌。</small></section>':'')+
      '<section class="earnings-news"><div class="earnings-section-head"><h3>会议快讯与原文</h3><small>按本次会议匹配</small></div>'+(articles.length?articles.map(a=>{const url=safeUrl(a.url),source=safeUrl(a.source_url),kind=({decision:'利率决议',press:'发布会',minutes:'会议纪要',preview:'会前预期'})[a.kind]||'相关快讯';return '<article class="earnings-article">'+(url?'<a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+esc(String(a.title||'查看原文').slice(0,260))+' ↗</a>':'<strong>'+esc(String(a.title||'会议快讯').slice(0,260))+'</strong>')+'<small>'+esc(kind)+' · '+esc(a.source_name||'方程式新闻')+' · '+esc(stamp(a.published_at))+'</small>'+(source&&source!==url?'<a class="earnings-original" href="'+esc(source)+'" target="_blank" rel="noopener noreferrer">原始来源 ↗</a>':'')+'</article>';}).join(''):'<p class="earnings-empty-news">'+(busy?'正在查询本次会议的快讯…':'尚未找到可匹配本次会议的快讯。')+'</p>')+'</section>'+
      '<div class="earnings-live-foot"><span role="status">'+esc(offline?'缓存展示 · 当前预览未联网':busy?'正在后台获取，日历可继续操作':error?(data.last_success_at?'本次更新未完成，保留上次资料':'本次查询未完成'):data.checked_at?'查询于 '+stamp(data.checked_at):'点开时查询；仅更新当前会议')+'</span><button type="button" class="button earnings-refresh" data-refresh-macro '+(busy?'disabled':'')+'>'+(busy?'获取中…':'更新本次会议')+'</button></div>'+(!offline&&error?'<p class="earnings-fetch-note">'+esc(String(error).slice(0,220))+'</p>':'')+
      '<details class="earnings-evidence macro-evidence"><summary>指标来源与核验 <span>展开</span></summary>'+metrics.map(m=>{const url=safeUrl(m.source_url),expected=safeUrl(m.expected_source_url);return '<p><strong>'+esc(m.label||m.key||'指标')+'</strong><br>'+esc(m.verification||'来源未提供')+' · '+esc(m.source_name||'来源未提供')+'<br>'+esc(stamp(m.asof))+(url?'<br><a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">公布结果来源 ↗</a>':'')+(expected?'<br><a href="'+esc(expected)+'" target="_blank" rel="noopener noreferrer">会议前预期来源 ↗</a> · '+esc(m.expected_source_name||'')+' · '+esc(stamp(m.expected_asof)):'')+'</p>';}).join('')+official.map(v=>{const url=safeUrl(typeof v==='string'?v:v.url||v.source_url);return url?'<p><a href="'+esc(url)+'" target="_blank" rel="noopener noreferrer">'+esc(typeof v==='object'&&(v.name||v.title)||'官方来源')+' ↗</a></p>':'';}).join('')+'</details>';
  }
  function macroDetailMarkup(e){
    const data=state.macroEvent===e.id?state.macroData:null;
    return '<div class="detail-eyebrow category-macro">重要经济数据 '+holdingBadge(e)+' '+badge(e)+'</div><h2 class="detail-title">'+esc(e.title)+'</h2><div class="earnings-when"><span>北京时间 · UTC+8</span><strong>'+esc(e.date)+' '+esc(timeLabel(e))+'</strong></div><div data-macro-live="'+esc(e.id)+'">'+macroLiveMarkup(e,data)+'</div>'+evidenceMarkup(e);
  }
  function cancelMacro(clear=false){clearTimeout(state.macroTimer);state.macroTimer=null;state.macroRequest++;abortChannel('macro');state.macroLoading=false;if(clear){state.macroData=null;state.macroEvent=null;state.macroError='';state.macroDeadline=0;}}
  function macroVisible(e){return Boolean(isMacro(e)&&!state.closed&&!document.hidden&&state.selected===e.id&&state.detailData&&state.detailData.event&&state.detailData.event.id===e.id);}
  function renderMacro(e){if(!macroVisible(e))return;const parent=mobileDetails()?$('dialogContent'):$('detailContent'),region=parent.querySelector('[data-macro-live]');if(region&&region.getAttribute('data-macro-live')===e.id)region.innerHTML=macroLiveMarkup(e,state.macroData);}
  function scheduleMacro(e,delay){clearTimeout(state.macroTimer);state.macroTimer=null;if(!macroVisible(e))return;state.macroTimer=setTimeout(()=>{state.macroTimer=null;if(!macroVisible(e))return;if(delay>=60000)state.macroDeadline=Date.now()+30000;loadMacro(e);},delay);}
  async function loadMacro(e,refresh=false){
    if(!macroVisible(e))return;
    const selected=state.selected,date=state.date,context=filterKey()+'|'+state.revision,request=++state.macroRequest;
    clearTimeout(state.macroTimer);state.macroTimer=null;state.macroEvent=e.id;state.macroLoading=true;state.macroError='';renderMacro(e);
    let timedOut=false;const timeout=setTimeout(()=>{if(request===state.macroRequest){timedOut=true;abortChannel('macro');}},12000);
    const current=()=>request===state.macroRequest&&selected===state.selected&&date===state.date&&context===filterKey()+'|'+state.revision&&macroVisible(e);
    try{const data=await requestChannel('macro','/api/macro?'+params({id:e.id,...(refresh?{refresh:'1'}:{})}));if(!current())return;state.macroData=data;state.macroLoading=false;if(data.status==='refreshing'&&Date.now()>=state.macroDeadline){state.macroData={...data,status:'partial'};state.macroError='本次会议查询较慢，稍后自动再核实。';}renderMacro(e);scheduleMacro(e,data.status==='refreshing'&&Date.now()<state.macroDeadline?1500:60000);return data;}
    catch(error){if(!current()||error.name==='AbortError'&&!timedOut)return;state.macroLoading=false;state.macroError=timedOut?'本次查询超时，保留已有会议资料。':'本次查询未完成，保留已有会议资料。';renderMacro(e);scheduleMacro(e,60000);}finally{clearTimeout(timeout);}
  }
  function startMacro(e,refresh=false){if(!isMacro(e))return;cancelMacro(state.macroEvent!==e.id);state.macroEvent=e.id;state.macroDeadline=Date.now()+30000;return loadMacro(e,refresh);}
  function handleMacroVisibility(){if(document.hidden)cancelMacro();else if(state.detailData&&isMacro(state.detailData.event)&&state.selected===state.detailData.event.id)startMacro(state.detailData.event);}
  function keyFields(e){
    const fields=Object.entries(e.details||{}),patterns={ipo:e.ipo_kind==='listing'?/发行价|上市日期|上市日|板块|发行市盈率/:/发行价|申购代码|申购.*上限|网上.*上限|顶格.*金额|参与方式|缴款|缴付|退款|资金.*解冻/,unlock:/计划解禁|解禁股数|占.*流通|解禁.*市值|股份类型|股东|解禁对象/,macro:/^(公布值|实际|actual|预期值|forecast|前值|previous)$/,holiday:/受影响|适用市场|休市类型|提前收市|交易时段/,politics:/当地日期|投票日期|地区|选区|结果|计票/,crypto:/升级|区块|减半|减产|解锁|供应|流通|规模|数量|比例|机制|状态|生效|快照/};
    const pattern=patterns[e.category];return (pattern?fields.filter(([k])=>pattern.test(k)):[]).filter(([,v])=>v!==null&&v!==undefined&&v!==''&&!/^(来源未提供|未提供|待补|未知)$/.test(String(v))).slice(0,5);
  }
  function evidenceMarkup(e){const link=safeUrl(e.source_url),fields=Object.entries(e.details||{});return '<details class="earnings-evidence"><summary>来源与口径 <span>展开</span></summary>'+(link?'<a class="source-link" href="'+esc(link)+'" target="_blank" rel="noopener noreferrer">'+esc(e.source_name||'原始来源')+' ↗</a>':'')+'<p class="earnings-provenance">来源核实：'+esc(stamp(e.source_checked_at||e.verified_at))+'</p><dl class="detail-fields">'+fields.map(([k,v])=>'<div class="field-row"><dt>'+esc(labels[k]||k)+'</dt><dd>'+esc(detailText(v))+'</dd></div>').join('')+'</dl></details>';}
  function eventDetailMarkup(e){
    let html;
    if(isEarnings(e))html=earningsDetailMarkup(e);
    else if(isOptions(e))html=optionsDetailMarkup(e);
    else if(isMacro(e))html=macroDetailMarkup(e);
    else if(e.is_personal)html=personalDetailMarkup(e);
    else if(e.category==='season'||e.category==='astronomy')html=culturalDetailMarkup(e);
    else{
      const fields=keyFields(e),note=e.category==='macro'&&!fields.length?'当前仅接入官方日程，指标数值尚未接入。':e.category==='politics'?'投票与计票依各地区安排，结果以官方公布为准。':e.category==='unlock'?'计划解禁不等于实际减持。':'';
      html='<div class="detail-eyebrow category-'+category(e)+'">'+CATS[category(e)]+' '+holdingBadge(e)+' '+badge(e)+'</div>'+(e.company?'<div class="event-issuer-mark">'+logoMarkup(e)+'</div>':'')+'<h2 class="detail-title">'+esc(e.title)+'</h2><div class="earnings-when"><span>北京时间 · UTC+8</span><strong>'+esc(e.date)+' '+esc(timeLabel(e))+'</strong></div>'+(fields.length?'<section class="detail-section key-details"><h3>关键资料</h3><dl class="detail-fields">'+fields.map(([k,v])=>'<div class="field-row"><dt>'+esc(labels[k]||k)+'</dt><dd>'+esc(detailText(v))+'</dd></div>').join('')+'</dl></section>':'')+(note?'<p class="detail-summary">'+note+'</p>':'')+evidenceMarkup(e);
    }
    return '<div class="favorite-control" data-favorite-control="'+esc(e.id)+'">'+favoriteButtonMarkup(e)+'</div>'+eventActionsMarkup(e)+qualityMarkup(e)+html;
  }

  function renderFilters(){
    const html=Object.entries(CATS).map(([key,name])=>'<label class="filter-option"><input type="checkbox" data-category="'+key+'" '+(state.categories.has(key)?'checked':'')+'><span class="dot" data-cat="'+key+'"></span><span>'+name+'</span></label>').join('');
    $('categoryFilters').innerHTML=html;$('mobileCategoryFilters').innerHTML=html;$('holdingOnly').checked=state.holdingOnly;
  }
  function renderNavigation(){
    $('monthLabel').textContent=state.year+' 年 '+state.month+' 月';
    $('personalHomeButton').classList.toggle('active',state.focus==='personal');const searching=Boolean(state.query.trim());$('monthView').hidden=state.view!=='month'||searching;$('agendaView').hidden=state.view!=='agenda'||searching;$('almanacStrip').hidden=searching;$('searchResults').hidden=!searching;$('dayListPanel').hidden=searching||state.view==='agenda';$('favoritesView').hidden=state.focus!=='favorites';document.querySelectorAll('.calendar-area').forEach(el=>el.hidden=state.focus==='favorites');$('favoritesButton').classList.toggle('active',state.focus==='favorites');
    document.querySelectorAll('[data-view]').forEach(el=>{const on=el.dataset.view===state.view&&state.focus!=='ipo';el.classList.toggle('active',on);el.setAttribute('aria-pressed',String(on));});
    $('ipoHomeButton').classList.toggle('active',state.focus==='ipo');$('allEventsButton').classList.toggle('active',state.focus==='all'&&state.view==='month');
    $('pendingButton').textContent='待核实 '+state.pendingCount;
    const r=range();document.querySelectorAll('a[href^="/calendar.ics"]').forEach(a=>a.href='/calendar.ics?start='+r.start+'&end='+r.end);
  }
  function highlightSearch(value){const text=String(value||''),q=state.query.trim(),at=text.toLocaleLowerCase().indexOf(q.toLocaleLowerCase());return at<0||!q?esc(text):esc(text.slice(0,at))+'<mark>'+esc(text.slice(at,at+q.length))+'</mark>'+esc(text.slice(at+q.length));}
  function renderSearch(){
    if(!state.query.trim())return;
    const d=state.searchData||{},items=d.items||[],groups=new Map();
    items.forEach(e=>{if(!groups.has(e.date))groups.set(e.date,[]);groups.get(e.date).push(e);});
    $('searchContent').innerHTML='<div class="search-result-heading"><div><small>搜索当前日期窗口 · 不区分大小写</small><h2>“'+esc(state.query.trim())+'” <span>'+(state.searchLoading?'正在查找…':(d.total||0)+' 条结果')+'</span></h2></div><button class="button" type="button" data-clear-search>返回月历 ×</button></div>'+(state.searchLoading&&!items.length?loadingMarkup('正在查找匹配事件'):[...groups].map(([date,events])=>'<section class="search-date-group"><header><strong>'+esc(longDate(date))+'</strong><small>'+esc(date)+' · 北京时间</small></header><div>'+events.map(e=>'<button type="button" class="search-result-row '+(important(e)?'important-event':'')+'" data-event="'+esc(e.id)+'" data-event-date="'+date+'"><span class="search-asset '+category(e)+'">'+(e.company?logoMarkup(e):e.category==='options'?'◷':'◈')+'</span><span><strong>'+highlightSearch(e.title)+importanceBadge(e)+holdingBadge(e)+'</strong><small>'+esc(e.market||'')+' · '+esc(CATS[category(e)]||'事项')+' · '+esc(e.source_name||'')+'</small></span><time>'+esc(timeLabel(e))+'<small>北京时间</small></time><span aria-hidden="true">↗</span></button>').join('')+'</div></section>').join('')||'<div class="empty-state">当前日期窗口没有匹配结果，可切换月份或清除筛选。</div>')+pagination(d,'search');
  }
  async function loadSearch(page=0){
    if(!state.query.trim()||state.closed)return;
    const request=++state.searchRequest,context=filterKey()+'|'+state.revision;state.searchLoading=true;renderSearch();
    try{const data=await requestChannel('search','/api/search?'+params({page,limit:PAGE_SIZE}));if(request!==state.searchRequest||context!==filterKey()+'|'+state.revision||state.closed)return;state.searchData=data;state.searchPage=data.page||0;state.searchLoading=false;renderSearch();}
    catch(error){if(error.name!=='AbortError'&&request===state.searchRequest){state.searchLoading=false;renderSearch();toast('搜索暂未完成，保留已有结果，请稍后重试。');}}
  }

  function monthPreview(items){return items.slice(0,items.some(important)?6:4);}
  function renderMonth(){return measure('month DOM',()=>{
    const first=new Date(Date.UTC(state.year,state.month-1,1,12)),offset=(first.getUTCDay()+6)%7,last=new Date(Date.UTC(state.year,state.month,0)).getUTCDate(),count=Math.ceil((offset+last)/7)*7,todayKey=today();
    const html=[];
    for(let i=0;i<count;i++){
      const d=new Date(Date.UTC(state.year,state.month-1,i-offset+1,12)),key=dateKey(d),summary=daySummary(key),items=summary.entries||[],held=summary.holding_count||0,kinds=[...new Set(items.map(e=>e.category))],extra=Math.max(0,(summary.entry_count||items.length)-monthPreview(items).length);
      html.push('<div class="day-cell '+(d.getUTCMonth()!==state.month-1?'outside ':'')+(key===state.date?'selected ':'')+(key===todayKey?'today ':'')+(held?'has-holdings ':'')+(summary.important_count?'has-important':'')+'" data-day="'+key+'"><button type="button" class="day-head" data-date="'+key+'" aria-pressed="'+(key===state.date)+'" aria-label="'+esc(longDate(key))+'，'+summary.count+'条事件，'+held+'条持仓相关"><span class="day-number">'+d.getUTCDate()+'</span>'+(summary.important_count?'<span class="day-important-count">重磅 '+summary.important_count+'</span>':held?'<span class="day-holding-count">持仓 '+held+'</span>':'<span class="day-lunar">'+(d.getUTCDay()%6===0?'周末':'')+'</span>')+'</button><div class="cell-events">'+monthPreview(items).map(e=>cellEntry(e,key)).join('')+(extra?'<button class="day-more" type="button" data-date="'+key+'">＋'+extra+'项，查看全部</button>':'')+'</div><div class="mobile-dots" aria-hidden="true">'+kinds.map(k=>'<span class="dot" data-cat="'+k+'"></span>').join('')+'</div></div>');
    }
    $('monthGrid').innerHTML=html.join('');
  });}
  function renderAgenda(){return measure('agenda DOM',()=>{
    const prefix=state.year+'-'+pad(state.month)+'-';
    $('agendaView').innerHTML=[...state.days.values()].filter(d=>d.date.startsWith(prefix)&&d.count).map(d=>'<section class="agenda-row"><button type="button" class="agenda-date" data-date="'+d.date+'">'+esc(longDate(d.date))+'<small>北京时间</small></button><div>'+(d.entries||[]).map(e=>e.event?row(e.event):'<button class="day-event-row category-'+e.category+'" type="button" data-entry="'+esc(e.id)+'" data-entry-date="'+d.date+'"><span class="event-copy"><span class="event-title">'+esc(e.title)+(e.is_holding?'<span class="holding-badge">持仓相关</span>':'')+'</span><span class="event-meta">查看完整名单与北京时间段 ↗</span></span></button>').join('')+((d.entry_count||0)>(d.entries||[]).length?'<button class="button" type="button" data-date="'+d.date+'">查看当天全部事项 ↗</button>':'')+'</div></section>').join('')||'<div class="empty-state">当前筛选下暂无已落实安排。</div>';
  });}
  function earningsMarkup(entry){
    const g=entry.group||{},items=g.items||[],count=groupTotal(g);
    return '<section class="earnings-group"><div class="earnings-heading"><strong><span class="dot" data-cat="earnings"></span> '+esc(g.market)+'财报 · '+count+'条 '+(entry.is_holding?'<span class="holding-badge">含持仓</span>':'')+'</strong><small>'+(g.mixed?'分币种按市值排序':'总市值降序')+' · 同类持仓优先 · 自动更新</small></div>'+items.slice(0,5).map(companyRow).join('')+'<button type="button" class="button show-more" data-entry="'+esc(entry.id)+'" data-entry-date="'+state.date+'">查看'+(count>5?'全部 ':'')+count+'条（每页20条）</button></section>';
  }
  function pagination(data,kind){
    const total=Number(data.total===undefined?data.count:data.total)||0,pages=Math.max(1,Number(data.pages)||1),page=Number(data.page)||0,limit=Number(data.limit)||PAGE_SIZE,start=total?page*limit+1:0,end=Math.min((page+1)*limit,total);
    if(pages<=1)return '';
    return '<div class="pagination" role="navigation" aria-label="名单分页"><button class="button" type="button" data-page-kind="'+kind+'" data-page-index="'+(page-1)+'" '+(page===0?'disabled':'')+'>上一页</button><span>第 '+(page+1)+' / '+pages+' 页 · '+start+'–'+end+' / '+total+' 条</span><button class="button" type="button" data-page-kind="'+kind+'" data-page-index="'+(page+1)+'" '+(page>=pages-1?'disabled':'')+'>下一页</button></div>';
  }
  function renderDay(){return measure('day DOM',()=>{
    const data=state.day&&state.day.date===state.date?state.day:null,summary=data||daySummary(state.date);
    $('selectedDayLabel').textContent=longDate(state.date)+' · 北京时间';
    $('daySummary').textContent=summary.count+'条已落实时间/时段的记录 · '+(summary.holding_count||0)+'条持仓相关';
    if(!data){$('dayList').innerHTML=loadingMarkup('正在读取当天事项');return;}
    $('dayList').innerHTML=(data.entries||[]).slice(0,PAGE_SIZE).map(e=>e.category==='earnings'&&e.group?earningsMarkup(e):e.group?'<button type="button" class="day-event-row category-'+e.category+'" data-entry="'+esc(e.id)+'" data-entry-date="'+state.date+'"><span class="event-copy">'+esc(e.title)+'</span></button>':row(e.event)).join('')+pagination({...data,total:data.entry_count},'day')||'<div class="empty-state"><strong>当前筛选下没有已落实时段的事件</strong><p>待核记录可在“待核实”中查看。</p></div>';
  });}
  function renderWatchBanner(){
    const held=Number(state.holdingsByDay[state.date]===undefined?daySummary(state.date).holding_count:state.holdingsByDay[state.date])||0;
    $('holdingsTitle').textContent=held?longDate(state.date)+'有 '+held+' 条与你持仓相关的事件':longDate(state.date)+'暂无已收录的持仓事件';
    $('holdingsBanner').classList.toggle('has-events',held>0);
    $('holdingsSubtitle').textContent='按证券代码关联 · '+(state.watchlistFactDate||'未标注日期')+'提供的持仓快照 · '+state.watchlist.length+'个证券 · 可在本机管理';
    $('holdingsOnlyButton').textContent=state.holdingOnly?'显示全部事件':'只看持仓相关';
    $('watchlistMeta').textContent=state.watchlist.length+' 个证券代码 · 资料提供日 '+(state.watchlistFactDate||'未标注');
  }
  function render(){
    renderNavigation();if(state.query.trim())renderSearch();else if(state.view==='month')renderMonth();else renderAgenda();
    renderDay();renderWatchBanner();
  }
  function showDayPopover(date,anchor){
    const pop=$('dayPopover'),list=entries(date),summary=state.day&&state.day.date===date?state.day:daySummary(date);
    $('popoverDay').textContent=longDate(date)+' · 北京时间';
    $('popoverList').innerHTML=list.map(e=>e.category==='earnings'&&e.group?'<section class="popover-group"><button class="popover-title" type="button" data-entry="'+esc(e.id)+'" data-entry-date="'+date+'"><span class="dot" data-cat="earnings"></span>'+esc(e.title)+(e.is_holding?'<span class="holding-badge">含持仓</span>':'')+'</button><small>持仓优先，其余按已知总市值降序</small><div class="popover-logos">'+uniqueCompanyLogos(groupLogos(e.group),5).map(c=>'<button type="button" class="popover-company" data-event="'+esc(c.id)+'">'+logoMarkup(c,true)+'<span>'+esc(c.company&&c.company.ticker||'')+'</span></button>').join('')+'</div><button type="button" class="popover-more" data-entry="'+esc(e.id)+'" data-entry-date="'+date+'">查看完整名单 ↗</button></section>':'<button type="button" class="popover-event '+(e.is_holding?'holding-event':'')+'" data-entry="'+esc(e.id)+'" data-entry-date="'+date+'"><span class="dot" data-cat="'+e.category+'"></span><span><strong>'+esc(e.title)+'</strong><small>'+(e.event?esc(timeLabel(e.event))+' 北京时间':'查看完整名单')+'</small></span></button>').join('')+((summary.entry_count||0)>list.length?'<button type="button" class="popover-more" data-open-day>查看当天全部事项 ↓</button>':'')||'<p class="popover-empty">当前筛选下无已核实事件。</p>';
    pop.dataset.date=date;pop.hidden=false;
    const element=document.querySelector('[data-day="'+date+'"]')||anchor;
    if(!element)return;
    const rect=element.getBoundingClientRect(),width=Math.min(340,window.innerWidth-24);
    pop.style.width=width+'px';pop.style.left=Math.max(12,Math.min(rect.left,window.innerWidth-width-12))+'px';pop.style.top=Math.max(12,Math.min(rect.top,window.innerHeight-pop.offsetHeight-12))+'px';
  }
  function closeDayPopover(){$('dayPopover').hidden=true;}
  function groupDetailMarkup(data){
    const kind=state.selected&&state.selected.startsWith('unlockgroup:')?'unlock':'earnings';
    return '<div class="detail-eyebrow category-'+kind+'">'+(kind==='earnings'?'公司财报 · 已剔除 ST':'仅重大解禁')+'</div><h2 class="detail-title">'+esc(data.market)+(kind==='earnings'?'财报 ':'重大解禁 ')+(data.total||data.count||0)+'条</h2><p class="detail-summary">'+esc(longDate(state.date))+' · 北京时间<br>同类持仓优先，随后按已知总市值降序；市值由程序自动更新。</p>'+'<div class="event-manage-actions"><button class="button remove-event-button" data-remove-group="'+kind+'" data-group-market="'+esc(data.market)+'">删除当天这一组</button></div>'+(data.items||[]).slice(0,PAGE_SIZE).map(kind==='earnings'?companyRow:row).join('')+pagination(data,'detail');
  }
  function detailMarkup(){
    if(!state.selected)return '';
    if(state.detailLoading&&!state.detailData)return loadingMarkup('正在读取详情');
    if(state.detailError&&!state.detailData)return '<div class="detail-empty">'+esc(state.detailError)+'<button class="button" type="button" data-retry-detail>重试</button></div>';
    if(!state.detailData)return loadingMarkup('正在读取详情');
    return state.detailData.event?eventDetailMarkup(state.detailData.event):groupDetailMarkup(state.detailData);
  }
  function renderDetail(){return measure('detail DOM',()=>{
    const mobile=mobileDetails(),html=detailMarkup(),visible=Boolean(state.selected);
    if(mobile){$('detailContent').innerHTML='';$('dialogContent').innerHTML=html;}
    else{$('dialogContent').innerHTML='';$('detailContent').innerHTML=html;}
    $('detailPanel').hidden=!visible||mobile;$('detailPanel').setAttribute('aria-hidden',String(!visible||mobile));
  });}
  function cancelOptions(clear=false){clearTimeout(state.optionsTimer);state.optionsTimer=null;state.optionsRequest++;abortChannel('options');state.optionsLoading=false;if(clear){state.optionsData=null;state.optionsEvent=null;state.optionsError='';state.optionsDeadline=0;}}
  function optionsVisible(e){return Boolean(isOptions(e)&&!state.closed&&!document.hidden&&state.selected===e.id&&state.detailData&&state.detailData.event&&state.detailData.event.id===e.id);}
  function renderOptions(e){if(!optionsVisible(e))return;const parent=mobileDetails()?$('dialogContent'):$('detailContent'),region=parent.querySelector('[data-options-live]');if(region&&region.getAttribute('data-options-live')===e.id)region.innerHTML=optionsLiveMarkup(e,state.optionsData);}
  function scheduleOptions(e,delay){clearTimeout(state.optionsTimer);state.optionsTimer=null;if(!optionsVisible(e))return;state.optionsTimer=setTimeout(()=>{state.optionsTimer=null;if(!optionsVisible(e))return;if(delay>=60000)state.optionsDeadline=Date.now()+30000;loadOptions(e);},delay);}
  async function loadOptions(e,refresh=false){
    if(!optionsVisible(e))return;
    const selected=state.selected,date=state.date,context=filterKey()+'|'+state.revision,request=++state.optionsRequest;
    clearTimeout(state.optionsTimer);state.optionsTimer=null;state.optionsEvent=e.id;state.optionsLoading=true;state.optionsError='';renderOptions(e);
    let timedOut=false;const timeout=setTimeout(()=>{if(request===state.optionsRequest){timedOut=true;abortChannel('options');}},12000);
    const current=()=>request===state.optionsRequest&&selected===state.selected&&date===state.date&&context===filterKey()+'|'+state.revision&&optionsVisible(e);
    try{const data=await requestChannel('options','/api/options?'+params({id:e.id,...(refresh?{refresh:'1'}:{})}));if(!current())return;state.optionsData=data;state.optionsLoading=false;if(data.status==='refreshing'&&Date.now()>=state.optionsDeadline){state.optionsData={...data,status:'partial'};state.optionsError='本次持仓读取耗时较长，稍后自动再核实。';}renderOptions(e);scheduleOptions(e,data.status==='refreshing'&&Date.now()<state.optionsDeadline?1500:60000);return data;}
    catch(error){if(!current()||error.name==='AbortError'&&!timedOut)return;state.optionsLoading=false;state.optionsError=timedOut?'读取超时，保留已有持仓快照。':'读取未完成，保留已有持仓快照。';renderOptions(e);scheduleOptions(e,60000);}finally{clearTimeout(timeout);}
  }
  function startOptions(e,refresh=false){if(!isOptions(e))return;cancelOptions(state.optionsEvent!==e.id);state.optionsEvent=e.id;state.optionsDeadline=Date.now()+30000;return loadOptions(e,refresh);}
  function handleOptionsVisibility(){if(document.hidden)cancelOptions();else if(state.detailData&&isOptions(state.detailData.event)&&state.selected===state.detailData.event.id)startOptions(state.detailData.event);}
  function favoriteFor(e){return state.favorites.find(item=>item.event&&item.event.id===e.id);}
  function favoriteButtonMarkup(e){const favorite=favoriteFor(e);return '<button type="button" class="button favorite-toggle '+(favorite?'is-favorite':'')+'" aria-pressed="'+Boolean(favorite)+'" data-toggle-favorite="'+esc(e.id)+'" '+(state.favoriteBusy?'disabled':'')+'><span aria-hidden="true">'+(favorite?'★':'☆')+'</span> '+(favorite?'已收藏':'收藏此事件')+'</button>'+(favorite&&!e.is_personal?'<button type="button" class="favorite-remind-link" data-remind-favorite="'+esc(favorite.id)+'">设置提醒 ↗</button>':'');}
  function renderFavoriteControl(){const e=state.detailData&&state.detailData.event;if(!e)return;const parent=mobileDetails()?$('dialogContent'):$('detailContent'),region=parent.querySelector('[data-favorite-control]');if(region&&region.getAttribute('data-favorite-control')===e.id)region.innerHTML=favoriteButtonMarkup(e);}
  function applyFavorites(payload){if(payload&&Array.isArray(payload.items)){state.favorites=payload.items.slice(0,1000);state.favoriteCapabilities=payload.capabilities||{};state.favoriteScheduler=payload.scheduler||{};state.favoriteNextDue=payload.next_due||null;}renderFavoriteControl();renderFavorites();}
  const REMINDER_LABELS={scheduled:'已安排提醒',delivering:'正在提醒',fired:'已提醒',dismissed:'已确认',cancelled:'已取消',missed:'已错过',failed:'提醒未启用'};
  function favoriteStatus(item){const r=item.reminder;if(!r)return '未设置提醒';const cap=state.favoriteCapabilities||{},scheduler=state.favoriteScheduler||{},ready=cap.supported!==false&&cap.scheduler_available!==false&&scheduler.status==='ready';let label=REMINDER_LABELS[r.status]||'待核实';if(r.status==='scheduled'&&!ready)label=cap.supported===false?'提醒时间已保存 · 系统提醒未启用':scheduler.status==='error'?'提醒时间已保存 · 系统任务未就绪':'提醒时间已保存 · 系统提醒待核实';return label+(r.at?' · '+stamp(r.at):'');}
  function renderFavorites(){
    $('favoriteCount').textContent=String(state.favorites.length);
    const items=[...state.favorites].sort((a,b)=>String(a.reminder&&a.reminder.status==='scheduled'&&a.reminder.at||a.event&&a.event.date||'9999').localeCompare(String(b.reminder&&b.reminder.status==='scheduled'&&b.reminder.at||b.event&&b.event.date||'9999'))),pages=Math.max(1,Math.ceil(items.length/PAGE_SIZE));state.favoritesPage=Math.min(state.favoritesPage,pages-1);
    const visible=items.slice(state.favoritesPage*PAGE_SIZE,(state.favoritesPage+1)*PAGE_SIZE),cap=state.favoriteCapabilities||{},scheduler=state.favoriteScheduler||{};
    $('favoritesSummary').textContent=state.favoritesLoading?'正在读取本机收藏':state.favoritesError||('已收藏 '+items.length+' 项'+(state.favoriteNextDue?' · 下次提醒 '+stamp(typeof state.favoriteNextDue==='string'?state.favoriteNextDue:state.favoriteNextDue.at):''));
    $('favoritesCapability').textContent=cap.supported===false?'当前环境不支持Windows闹钟；收藏和提醒时间仍保存在本机。':scheduler.status==='error'?'Windows提醒任务未启用：'+String(scheduler.last_error||cap.error||'请检查本机设置'):cap.note||'提醒使用北京时间。电脑须开机并登录；关机或睡眠期间不能保证准时响铃。';
    $('favoritesList').innerHTML=visible.map(item=>{const e=item.event||{},r=item.reminder,held=e.date===today(),source=safeUrl(e.source_url);return '<article class="favorite-card '+(held?'is-today':'')+'"><div class="favorite-card-main">'+(e.company?logoMarkup(e):'<span class="favorite-category" aria-hidden="true">'+esc(({options:'₿',macro:'◉',season:'◌',ipo:'✦'})[e.category]||'☆')+'</span>')+'<div><span class="favorite-card-kind">'+esc(CATS[e.category]||'收藏事件')+(held?' · 今天':'')+'</span><button class="favorite-title" type="button" data-open-favorite="'+esc(item.id)+'">'+esc(e.title||'收藏事件')+'</button><p>'+esc(e.date||'日期待核')+' · '+esc(timeLabel(e))+' 北京时间</p></div></div><div class="favorite-reminder-state '+(r&&r.status==='failed'?'failed':'')+'">'+esc(favoriteStatus(item))+'</div>'+(r&&r.last_error?'<p class="favorite-error">'+esc(r.last_error)+'</p>':'')+'<div class="favorite-actions"><button type="button" class="button" data-remind-favorite="'+esc(item.id)+'">'+(r&&r.status==='scheduled'?'修改提醒':'设置提醒')+'</button>'+(r&&['scheduled','failed','missed'].includes(r.status)?'<button type="button" class="text-button" data-cancel-reminder="'+esc(item.id)+'">取消提醒</button>':'')+(r&&['fired','delivering'].includes(r.status)?'<button type="button" class="text-button" data-dismiss-reminder="'+esc(item.id)+'">确认收到</button>':'')+'<button type="button" class="text-button" data-remove-favorite="'+esc(item.id)+'">取消收藏</button>'+(source?'<a href="'+esc(source)+'" target="_blank" rel="noopener noreferrer">来源 ↗</a>':'')+'</div></article>';}).join('')+(items.length>PAGE_SIZE?'<div class="pagination"><button class="button" type="button" data-favorites-page="'+(state.favoritesPage-1)+'" '+(state.favoritesPage===0?'disabled':'')+'>上一页</button><span>'+(state.favoritesPage+1)+' / '+pages+'</span><button class="button" type="button" data-favorites-page="'+(state.favoritesPage+1)+'" '+(state.favoritesPage===pages-1?'disabled':'')+'>下一页</button></div>':'')||'<div class="favorites-empty"><span>☆</span><h3>把重要的时间留在这里</h3><p>点开任意事件，点击“收藏此事件”，再设一个北京时间提醒。</p></div>';
  }
  async function loadFavorites(){const request=++state.favoritesRequest;state.favoritesLoading=true;state.favoritesError='';renderFavorites();try{const payload=await requestChannel('favorites','/api/favorites');if(request!==state.favoritesRequest||state.closed)return;state.favoritesLoading=false;applyFavorites(payload);return payload;}catch(error){if(request!==state.favoritesRequest||error.name==='AbortError')return;state.favoritesLoading=false;state.favoritesError='本机收藏暂时读取失败，原收藏未清除。';renderFavorites();}}
  async function favoriteAction(payload){if(state.favoriteBusy)return;state.favoritesRequest++;abortChannel('favorites');state.favoritesLoading=false;state.favoriteBusy=true;renderFavoriteControl();try{const result=await post('/api/favorites',payload);if(result.favorites)applyFavorites(result.favorites);else if(Array.isArray(result.items))applyFavorites(result);else await loadFavorites();return result;}finally{state.favoriteBusy=false;renderFavoriteControl();}}
  async function toggleFavorite(e){if(!e)return;const item=favoriteFor(e);try{await favoriteAction(item?{action:'remove',id:item.id}:{action:'save',event_id:e.id,start:range().start,end:range().end});toast(item?'已取消收藏及其提醒。':'已收藏，可设置北京时间提醒。');}catch(error){toast('收藏未保存：'+error.message);}}
  function openFavorites(){closeDayPopover();closeDetails();state.focus='favorites';renderNavigation();renderFavorites();return loadFavorites();}
  function openFavorite(id){const item=state.favorites.find(x=>x.id===id);if(!item||!item.event)return;closeDetails();const e=item.event;if(/^\d{4}-\d{2}-\d{2}$/.test(e.date||'')){state.date=e.date;state.year=+e.date.slice(0,4);state.month=+e.date.slice(5,7);}state.selected=e.id;state.detailData={event:e};state.detailLoading=false;renderDetail();if(mobileDetails()&&!$('detailDialog').open)$('detailDialog').showModal();if(isEarnings(e))startEarnings(e);if(isOptions(e))startOptions(e);if(isMacro(e))startMacro(e);}
  function reminderDefault(){return {date:dateKey(new Date(dateObj(today()).getTime()+86400000)),time:'09:00'};}
  function reminderPayload(id,date,time,channels){const canonical=new Date(date+'T12:00:00Z'),at=date+'T'+time+':00+08:00',parsed=new Date(at);if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(canonical.getTime())||canonical.toISOString().slice(0,10)!==date||!/^\d{2}:\d{2}$/.test(time)||Number.isNaN(parsed.getTime()))throw new Error('请选择有效的北京时间日期和时刻。');if(parsed.getTime()<=Date.now())throw new Error('提醒时间须晚于现在。');if(!channels.length)throw new Error('至少选择弹窗或响铃一种方式。');return {action:'remind',id,at,channels};}
  function openReminder(id){const item=state.favorites.find(x=>x.id===id);if(!item)return;state.reminderEditing=id;const d=reminderDefault(),r=item.reminder||{};if(r.at&&new Date(r.at).getTime()>Date.now()){d.date=String(r.at).slice(0,10);d.time=String(r.at).slice(11,16);}$('reminderTitle').textContent=(item.event||{}).title||'收藏事件';$('reminderDate').value=d.date;$('reminderTime').value=d.time;$('reminderPopup').checked=!r.channels||r.channels.includes('popup');$('reminderSound').checked=!r.channels||r.channels.includes('sound');$('reminderError').textContent='';$('reminderCapability').textContent=state.favoriteCapabilities.supported===false?'当前预览环境不支持系统响铃；Windows端保存后会检查系统提醒任务。':'提醒保存于本机；关闭日历窗口后由Windows任务继续检查，电脑须开机并登录。';$('reminderDialog').showModal();}
  async function saveReminder(){const id=state.reminderEditing;if(!id)return;try{const channels=[];if($('reminderPopup').checked)channels.push('popup');if($('reminderSound').checked)channels.push('sound');const payload=reminderPayload(id,$('reminderDate').value,$('reminderTime').value,channels);$('saveReminder').disabled=true;await favoriteAction(payload);$('reminderDialog').close();const saved=state.favorites.find(x=>x.id===id),r=saved&&saved.reminder;toast(r&&r.status==='failed'?'提醒时间已保存，系统闹钟尚未启用；请查看错误。':'提醒时间已保存，请留意本机任务状态。');}catch(error){$('reminderError').textContent=error.message;}finally{$('saveReminder').disabled=false;}}

  function cancelEarnings(clear=false){
    clearTimeout(state.earningsTimer);state.earningsTimer=null;state.earningsRequest++;abortChannel('earnings');state.earningsLoading=false;
    if(clear){state.earningsData=null;state.earningsEvent=null;state.earningsError='';state.earningsDeadline=0;}
  }
  function earningsVisible(e){return Boolean(isEarnings(e)&&!state.closed&&!document.hidden&&state.selected===e.id&&state.detailData&&state.detailData.event&&state.detailData.event.id===e.id);}
  function renderEarnings(e){
    if(!earningsVisible(e))return;
    const parent=mobileDetails()?$('dialogContent'):$('detailContent'),region=parent.querySelector('[data-earnings-live]'),period=parent.querySelector('[data-earnings-period]');
    if(region&&region.getAttribute('data-earnings-live')===e.id)region.innerHTML=earningsLiveMarkup(e,state.earningsData);
    if(period)period.textContent=state.earningsData&&state.earningsData.report_period?' · '+state.earningsData.report_period:'';
  }
  function scheduleEarnings(e,delay){
    clearTimeout(state.earningsTimer);state.earningsTimer=null;
    if(!earningsVisible(e))return;
    state.earningsTimer=setTimeout(()=>{
      state.earningsTimer=null;
      if(!earningsVisible(e))return;
      if(delay>=60000)state.earningsDeadline=Date.now()+20000;
      loadEarnings(e,false);
    },delay);
  }
  async function loadEarnings(e,refresh=false){
    if(!earningsVisible(e))return;
    const selected=state.selected,date=state.date,context=filterKey()+'|'+state.revision,request=++state.earningsRequest;
    clearTimeout(state.earningsTimer);state.earningsTimer=null;state.earningsEvent=e.id;state.earningsLoading=true;state.earningsError='';renderEarnings(e);
    let timedOut=false;
    const timeout=setTimeout(()=>{if(request===state.earningsRequest){timedOut=true;abortChannel('earnings');}},12000);
    const current=()=>request===state.earningsRequest&&selected===state.selected&&date===state.date&&context===filterKey()+'|'+state.revision&&earningsVisible(e);
    try{
      const data=await requestChannel('earnings','/api/earnings?'+params({id:e.id,...(refresh?{refresh:'1'}:{})}));
      if(!current())return;
      state.earningsData=data;state.earningsLoading=false;
      if(data.status==='refreshing'&&Date.now()>=state.earningsDeadline){state.earningsData={...data,status:'partial'};state.earningsError='读取耗时较长，保留当前资料，稍后自动再核实。';}
      renderEarnings(e);scheduleEarnings(e,data.status==='refreshing'&&Date.now()<state.earningsDeadline?1500:60000);
      return data;
    }catch(error){
      if(!current()||error.name==='AbortError'&&!timedOut)return;
      state.earningsLoading=false;state.earningsError=timedOut?'本次读取超时，保留上次资料，稍后自动再核实。':'本次联网获取失败，保留上次资料。';renderEarnings(e);scheduleEarnings(e,60000);
    }finally{clearTimeout(timeout);}
  }
  function startEarnings(e,refresh=false){
    if(!isEarnings(e))return;
    cancelEarnings(state.earningsEvent!==e.id);state.earningsEvent=e.id;state.earningsDeadline=Date.now()+20000;
    return loadEarnings(e,refresh);
  }
  function handleEarningsVisibility(){
    if(document.hidden)cancelEarnings();
    else if(state.detailData&&isEarnings(state.detailData.event)&&state.selected===state.detailData.event.id)startEarnings(state.detailData.event);
  }
  function closeDetails(){
    cancelEarnings(true);cancelOptions(true);cancelMacro(true);
    state.selected=null;state.detailRequest++;abortChannel('detail');state.detailData=null;state.detailError='';state.detailLoading=false;
    if($('detailDialog').open)$('detailDialog').close();renderDetail();
  }
  async function loadDay(page=0){
    const date=state.date,context=filterKey()+'|'+state.revision,key=[context,date,page].join('|'),request=++state.dayRequest;
    state.dayPage=page;
    const cached=caches.day.get(key);
    if(cached){state.day=cached;renderDay();renderWatchBanner();return cached;}
    try{
      const data=await requestChannel('day','/api/day?'+params({date,page,limit:PAGE_SIZE}));
      if(request!==state.dayRequest||date!==state.date||context!==filterKey()+'|'+state.revision||state.closed)return;
      cacheSet(caches.day,key,data);state.day=data;renderDay();renderWatchBanner();
      if(!$('dayPopover').hidden&&$('dayPopover').dataset.date===date)showDayPopover(date);
      return data;
    }catch(error){if(error.name!=='AbortError'&&request===state.dayRequest&&context===filterKey()+'|'+state.revision){$('dayList').innerHTML='<div class="empty-state">当天事项读取失败，已保留月历。<button class="button" data-retry-day type="button">重试</button></div>';}}
  }
  async function loadDetail(page=0){
    if(!state.selected)return;
    const selected=state.selected,date=state.date,context=filterKey()+'|'+state.revision,request=++state.detailRequest;
    state.detailPage=page;state.detailLoading=true;state.detailError='';
    const group=selected.startsWith('group:')||selected.startsWith('unlockgroup:'),kind=selected.startsWith('unlockgroup:')?'unlock':'earnings',market=selected.slice(selected.indexOf(':')+1);
    const key=[state.revision,filterKey(),date,selected,page].join('|'),cached=caches.detail.get(key);
    if(cached){state.detailData=cached;state.detailLoading=false;renderDetail();if(isEarnings(cached.event))startEarnings(cached.event);if(isOptions(cached.event))startOptions(cached.event);if(isMacro(cached.event))startMacro(cached.event);return cached;}
    if(!state.detailData)renderDetail();
    try{
      const url=group?'/api/group?'+params({date,kind,group_market:market,page,limit:PAGE_SIZE}):'/api/event?'+params({id:selected});
      const data=await requestChannel('detail',url);
      if(request!==state.detailRequest||selected!==state.selected||date!==state.date||context!==filterKey()+'|'+state.revision||state.closed)return;
      cacheSet(caches.detail,key,data);state.detailData=data;state.detailLoading=false;renderDetail();
      const panel=mobileDetails()?$('dialogContent'):$('detailPanel');if(panel)panel.scrollTop=0;
      if(isEarnings(data.event))startEarnings(data.event);if(isOptions(data.event))startOptions(data.event);if(isMacro(data.event))startMacro(data.event);
      return data;
    }catch(error){
      if(error.name!=='AbortError'&&request===state.detailRequest&&context===filterKey()+'|'+state.revision){state.detailLoading=false;state.detailError='详情暂时无法读取。'+error.message;renderDetail();toast(state.detailError);}
    }
  }
  function selectEvent(id,date){
    cancelEarnings(true);cancelOptions(true);cancelMacro(true);
    phase('open '+(id.startsWith('group:')?'earnings':id.startsWith('unlockgroup:')?'unlock':'event'));
    if(date&&date!==state.date)selectDate(date);
    state.selected=id;state.detailData=null;state.detailLoading=true;state.detailError='';renderDetail();
    if(mobileDetails()&&!$('detailDialog').open)$('detailDialog').showModal();
    return loadDetail(0);
  }
  function selectDate(date){
    phase('select day');
    const first=new Date(Date.UTC(state.year,state.month-1,1,12)),offset=(first.getUTCDay()+6)%7,last=new Date(Date.UTC(state.year,state.month,0)).getUTCDate(),count=Math.ceil((offset+last)/7)*7;
    const start=dateKey(new Date(Date.UTC(state.year,state.month-1,1-offset,12))),end=dateKey(new Date(Date.UTC(state.year,state.month-1,count-offset,12)));
    const moved=date<start||date>end;
    state.date=date;loadAlmanac(date);if(moved){state.year=+date.slice(0,4);state.month=+date.slice(5,7);}state.day=null;state.dayPage=0;closeDetails();
    if(moved){renderNavigation();renderMonth();renderDay();renderWatchBanner();return load();}
    const old=document.querySelector('.day-cell.selected');if(old){old.classList.remove('selected');const head=old.querySelector('.day-head');if(head)head.setAttribute('aria-pressed','false');}
    const cell=document.querySelector('[data-day="'+date+'"]');if(cell){cell.classList.add('selected');const head=cell.querySelector('.day-head');if(head)head.setAttribute('aria-pressed','true');}
    renderDay();renderWatchBanner();return loadDay();
  }
  async function load(force=false){
    if(state.closed)return;
    const url='/api/calendar?'+params(),key=filterKey();
    if(monthPromise&&monthUrl===url&&!force)return monthPromise;
    if(force)abortChannel('month');
    const request=++state.monthRequest;state.loading=true;renderSources();monthUrl=url;
    monthPromise=(async()=>{
      try{
        const data=await requestChannel('month',url);
        if(request!==state.monthRequest||key!==filterKey()||state.closed)return;
        if(data.revision!==state.revision||force){invalidateContentRequests();state.detailData=null;}
        state.days=new Map((data.days||[]).map(day=>[day.date,day]));state.mainCount=data.main_count||0;state.totalCount=data.total_count||0;state.pendingCount=data.pending_count||0;
        state.sources=Array.isArray(data.sources)?data.sources:[];state.coverage=data.coverage||null;state.fetched=data.fetched_at||null;
        state.refreshing=Boolean(data.refreshing);state.error=data.last_error||'';state.revision=data.revision;state.datasetRevision=data.dataset_revision;
        state.holdingsByDay=data.holdings_by_day||{};if(data.quotes_status)state.quotes=data.quotes_status;if(data.watchlist_fact_date)state.watchlistFactDate=data.watchlist_fact_date;
        state.loading=false;lastLoaded=Date.now();render();renderSources();loadAlmanac(state.date);
        if(state.query.trim())await loadSearch(state.searchPage);else await loadDay();
        if(state.selected)await loadDetail(state.detailPage);
        if($('pendingDialog').open)await renderPending(0);
        if(state.refreshing)schedulePoll();
        return data;
      }catch(error){if(error.name!=='AbortError'&&request===state.monthRequest){state.loading=false;state.error='月历暂时无法读取，已保留现有记录。'+error.message;renderSources();}}
      finally{if(request===state.monthRequest){monthPromise=null;monthUrl=null;}}
    })();
    return monthPromise;
  }
  function schedulePoll(){clearTimeout(state.poll);state.poll=setTimeout(checkStatus,5000);}
  async function checkStatus(){
    if(state.closed||state.statusChecking)return;
    state.statusChecking=true;
    try{
      const data=await getJson('/api/status'),was=state.refreshing;
      state.refreshing=Boolean(data.refreshing);if(data.last_error)state.error=data.last_error;if(Array.isArray(data.sources))state.sources=data.sources;if(data.quotes_status)state.quotes=data.quotes_status;
      // Progress timestamps can change for every source chunk. They must never
      // cause repeated record downloads or month/detail reconstruction.
      const finished=was&&!state.refreshing;
      const stableChanged=!state.refreshing&&data.fetched_at&&data.fetched_at!==state.fetched&&Date.now()-lastLoaded>15000;
      if(finished||stableChanged)await load();
      else renderSources();
      if(state.refreshing)schedulePoll();
    }catch(error){state.error='状态检查失败，现有日历可继续查看。'+error.message;renderSources();}
    finally{state.statusChecking=false;}
  }
  async function refresh(manual){
    if(state.closed||state.refreshing||!state.token)return;
    try{
      state.refreshing=true;renderSources();const result=await post('/api/refresh',range());state.refreshing=result.refreshing!==false;
      if(manual)toast('已请求刷新日程，完成后更新日历。');if(state.refreshing)schedulePoll();else await load();return result;
    }catch(error){state.refreshing=false;state.error='刷新未完成。'+error.message;renderSources();return null;}
  }
  async function checkQuotes(){
    if(state.closed||state.quotesChecking)return;state.quotesChecking=true;
    try{
      const previous=state.quotes.last_success||state.quotes.fetched_at,q=await getJson('/api/quotes/status');state.quotes=q;renderQuotes();
      if((q.last_success||q.fetched_at)!==previous&&!q.refreshing&&!state.refreshing&&!state.dataRefreshing)await load();
    }catch(error){state.quotes={...state.quotes,error:'部分公司数据暂未更新，程序会自动重试。'};renderQuotes();}
    finally{state.quotesChecking=false;}
  }
  function pendingMarkup(data){
    return (data.items||[]).slice(0,PAGE_SIZE).map(e=>{const link=safeUrl(e.source_url);return '<section class="pending-card"><strong>'+esc(e.title||'未命名事件')+'</strong>'+holdingBadge(e)+'<p>'+esc(e.pending_reason||e.reason||'尚未核实可靠时间范围。')+'</p><small>'+esc(e.source_name||'来源未确认')+' · 原文日期仅供核查：'+esc(e.original_date||e.date||'未给出')+'</small>'+(link?'<a href="'+esc(link)+'" target="_blank" rel="noopener noreferrer">核查来源 ↗</a>':'')+'<button class="button remove-event-button" type="button" data-remove-pending="'+esc(e.id)+'">从待核列表移除</button></section>';}).join('')+pagination(data,'pending')||'<div class="empty-state">当前没有待核实记录</div>';
  }
  async function renderPending(page=0){
    const context=filterKey()+'|'+state.revision,request=++state.pendingRequest,key=[context,page].join('|');
    $('pendingIntro').textContent=state.pendingCount+' 条记录尚未落实北京时间/可靠时段，不占主日历。ST 财报已剔除。';
    $('pendingList').innerHTML=loadingMarkup('正在读取待核实记录');
    try{
      const data=caches.pending.get(key)||await requestChannel('pending','/api/pending?'+params({page,limit:PAGE_SIZE}));
      if(request!==state.pendingRequest||context!==filterKey()+'|'+state.revision||state.closed)return;
      cacheSet(caches.pending,key,data);state.pendingData=data;$('pendingIntro').textContent=data.total+' 条记录符合当前筛选，尚未落实北京时间/可靠时段；全库待核 '+state.pendingCount+' 条。';$('pendingList').innerHTML=pendingMarkup(data);
    }catch(error){if(error.name!=='AbortError'&&request===state.pendingRequest&&context===filterKey()+'|'+state.revision)$('pendingList').innerHTML='<div class="empty-state">待核记录暂时无法读取，请稍后重试。</div>';}
  }
  function filtersChanged(){
    state.searchPage=0;state.searchData=null;state.searchLoading=Boolean(state.query.trim());state.searchRequest++;abortChannel('search');
    closeDayPopover();closeDetails();invalidateContentRequests();renderFilters();renderNavigation();if(state.query.trim())renderSearch();renderWatchBanner();return load();
  }
  function moveMonth(delta){
    const d=new Date(Date.UTC(state.year,state.month-1+delta,1,12));state.year=d.getUTCFullYear();state.month=d.getUTCMonth()+1;state.date=dateKey(d);state.days=new Map();state.day=null;closeDayPopover();closeDetails();render();return load();
  }
  function reset(){state.categories=new Set(Object.keys(CATS));state.market='all';state.query='';state.holdingOnly=false;state.focus='all';$('search').value='';$('marketFilter').value='all';return filtersChanged();}
  function toggleHoldings(){state.holdingOnly=!state.holdingOnly;return filtersChanged();}

  function economicVerificationMarkup(rows){const groups=new Map();rows.forEach(m=>{const key=[m.source_url||'',m.source_name||'',m.asof||''].join('|');if(!groups.has(key))groups.set(key,[]);groups.get(key).push(m);});return [...groups.values()].map(items=>{const first=items[0],checks=items.flatMap(m=>(m.corroboration||[]).map(c=>esc(m.label)+'：'+esc(c.source_name)+' '+esc(c.value)+esc(m.unit)+' · '+(c.status==='agree'?'数值一致':'与官方存在分歧')));return '<p class="economic-verification"><strong>'+esc(items.length>1?items.length+'项指标 · 同一官网发布':first.label)+'</strong><br>'+esc(first.source_name)+' · '+esc(stamp(first.asof))+'<br>'+(checks.length?checks.join('<br>'):'尚无第二来源的同口径数值核对')+'</p>';}).join('');}
  function economicMarkup(e,data){
    data=data||{};const busy=state.macroLoading||data.status==='refreshing',rows=Array.isArray(data.metrics)?data.metrics:[],stories=Array.isArray(data.articles)?data.articles:[],offline=data.status==='offline';
    const comparisons='<div class="earnings-comparison"><div class="earnings-comparison-head"><span>本次指标</span><span>市场预期</span><span>实际公布</span></div>'+rows.map(m=>'<div class="earnings-comparison-row"><span class="earnings-metric-name">'+esc(m.label)+'<small>'+esc(m.period||'')+'</small></span><span>'+macroValue(m.expected,m.unit,'未取得预期')+'</span><span>'+macroValue(m.actual,m.unit)+'</span></div>').join('')+'</div>';
    return '<div class="earnings-section-head"><h3>预期与公布值</h3><span class="earnings-stage">'+esc(data.data_stale?'保留上次核实数据':data.verification||'正在核实')+'</span></div>'+(rows.length?comparisons:'<p class="earnings-unavailable">'+(busy?'正在后台获取本次指标，日历可以继续操作。':'尚未取得与本次日期、指标及期次匹配的数值。')+'</p>')+
      '<section class="economic-reading"><h3>数据解读</h3>'+(Array.isArray(data.analysis)?data.analysis:[]).map(x=>'<p>'+esc(x)+'</p>').join('')+'</section>'+
      (data.impact_scenarios||[]).slice(0,3).map(x=>'<article class="economic-scenario"><strong>'+esc(x.condition)+'</strong><span>'+esc((x.assets||[]).join(' · '))+'</span><p>'+esc(x.text)+'</p><small>'+esc(x.basis||'条件情景')+' · 不代表已发生行情</small></article>').join('')+
      '<div class="earnings-live-foot"><span role="status">'+esc(offline?'缓存展示 · 未联网':busy?'后台核对中':data.checked_at?'数据核实于 '+stamp(data.checked_at):'点开后按需获取')+'</span><button class="button earnings-refresh" data-refresh-macro '+(busy?'disabled':'')+'>'+(busy?'获取中…':'刷新本次数据')+'</button></div>'+
      '<section class="earnings-news"><h3>数据来源与交叉核验</h3>'+((data.cross_check&&data.cross_check.note)?'<p class="transfer-note">'+esc(data.cross_check.note)+'</p>':'')+economicVerificationMarkup(rows)+stories.map(a=>{const u=safeUrl(a.url);return u?'<article class="earnings-article"><a href="'+esc(u)+'" target="_blank" rel="noopener noreferrer">'+esc(a.title)+' ↗</a><small>'+esc(a.source_name)+' · '+esc(stamp(a.published_at))+'</small></article>':'';}).join('')+'<div class="economic-source-plan">'+(data.source_plan||[]).map(x=>'<article><strong>'+(safeUrl(x.url)?'<a href="'+esc(safeUrl(x.url))+'" target="_blank" rel="noopener noreferrer">'+esc(x.name)+' ↗</a>':esc(x.name))+'</strong><span>'+esc(x.role)+'</span><small>'+esc(x.access)+' · '+esc(({ok:'已取到数据',partial:'备用入口',error:'本次连接未完成',unmatched:'未匹配到本次发布',awaiting_release:'等待官方公布',cached:'发行包核实快照',waiting:'待本次核实'})[x.status]||'待核实')+'</small></article>').join('')+'</div><p class="earnings-provenance">公布值优先核对官网原文；预期来自另行注明的财经报道，缺失时留空。</p>'+'</section>';
  }
  function culturalDetailMarkup(e){const c=e.culture||{},details=e.details||{};return '<div class="detail-eyebrow">'+esc(e.category==='astronomy'?'西方星象 · 天文与传统解释':'东方历法 · 二十四节气')+' '+badge(e)+'</div><h2 class="detail-title">'+esc(e.title)+'</h2><div class="earnings-when"><span>北京时间 UTC+8</span><strong>'+esc(e.date)+' '+esc(timeLabel(e))+'</strong></div>'+(c.meaning?'<p class="culture-meaning">'+esc(c.meaning)+'</p><div class="culture-advice"><p><b>宜</b>'+esc(c.suitable)+'</p><p><b>不宜</b>'+esc(String(c.avoid||'').replace(/^不宜/,''))+'</p></div><small>'+esc(c.basis)+'</small>':Object.entries(details).filter(([k])=>['天文解释','文化解读','判断边界'].includes(k)).map(([k,v])=>'<section class="culture-explanation"><h3>'+esc(k)+'</h3><p>'+esc(v)+'</p></section>').join(''))+evidenceMarkup(e);}
  function hourNow(){const d=new Date(Date.now()+8*3600000),h=d.getUTCHours(),idx=Math.floor((h+1)/2)%12,names=['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'],start=(idx*2+23)%24;return {name:names[idx]+'时',index:idx,range:pad(start)+':00–'+pad((start+2)%24)+':00',clock:pad(h)+':'+pad(d.getUTCMinutes())};}
  function lunarLabel(day){try{return new Intl.DateTimeFormat('zh-CN-u-ca-chinese',{timeZone:'Asia/Shanghai',month:'long',day:'numeric'}).format(dateObj(day));}catch{return '';}}
  function renderAlmanac(){const d=state.almanac;if(!d||d.date!==state.date)return;const h=hourNow(),t=d.season||{},astro=d.astronomy||[];const row='<div class="almanac-clock"><span>此刻 · 北京时间</span><strong>'+h.clock+' <em>'+h.name+'</em></strong><small>'+h.range+' · 每时辰两小时</small></div><div class="almanac-season"><span>'+esc(longDate(d.date))+' · '+esc(lunarLabel(d.date))+'</span><strong>'+esc(t.name||'节气待覆盖')+'</strong><small>'+esc(t.suitable?'宜 '+t.suitable:'天文节气不等同于当地气候')+'</small></div><button class="almanac-open" data-open-almanac><span>东方历法 / 西方星象</span><strong>'+esc(astro.length?astro.map(x=>x.title).join(' · '):'十二时辰 · 节气解读')+'</strong><small>查看宜忌、天文解释与传统含义 ↗</small></button>';$('almanacContent').innerHTML=row;
    if($('almanacDialog').open)renderAlmanacFull();
  }
  function renderAlmanacFull(){const d=state.almanac;if(!d)return;const h=hourNow(),t=d.season;$('almanacFull').innerHTML='<p class="source-intro">'+esc(longDate(d.date))+' · '+esc(lunarLabel(d.date))+' · 北京时间 UTC+8</p><div class="almanac-current"><span>此刻</span><strong>'+h.name+' '+h.clock+'</strong><p>'+h.range+'</p></div><h3>东方历法 · 十二时辰</h3><div class="hours-grid">'+(d.hours||[]).map((x,i)=>'<div class="'+(i===h.index?'current-hour':'')+'"><strong>'+esc(x.name)+'</strong><span>'+esc(x.traditional_name)+'</span><small>'+esc(x.range)+'</small></div>').join('')+'</div>'+(t?'<section class="culture-explanation"><h3>'+esc(t.name)+'</h3><p>'+esc(t.meaning)+'</p><div class="culture-advice"><p><b>宜</b>'+esc(t.suitable)+'</p><p><b>不宜</b>'+esc(String(t.avoid||'').replace(/^不宜/,''))+'</p></div><small>季节文化与现代生活提示，非每日黄历吉凶。</small></section>':'<p>所选日期暂不在已核验的节气覆盖期。</p>')+'<h3>西方星象 · 当日事项</h3>'+((d.astronomy||[]).map(e=>'<section class="culture-explanation"><strong>'+esc(e.title)+'</strong><small>'+esc(timeLabel(e))+' 北京时间</small><p>'+esc(e.details['天文解释'])+'</p><p>'+esc(e.details['文化解读'])+'</p><a href="'+esc(safeUrl(e.source_url)||'#')+'" target="_blank" rel="noopener noreferrer">NASA/JPL星历来源 ↗</a></section>').join('')||'<p>当天没有已收录的水星逆行/顺行或水星合金星事件。</p>')+'<p class="culture-boundary">天文事件由NASA/JPL星历计算一小时时段；传统含义不判定交易吉凶。'+esc(d.note)+'</p><p><a href="https://www.hko.gov.hk/sc/gts/time/24solarterms.htm" target="_blank" rel="noopener noreferrer">香港天文台 · 二十四节气解释 ↗</a></p>';}
  async function loadAlmanac(date=state.date){try{const d=await requestChannel('almanac','/api/almanac?'+new URLSearchParams({date}));if(state.date!==date||state.closed)return;state.almanac=d;renderAlmanac();}catch(error){if(error.name!=='AbortError')$('almanacContent').textContent='历法暂未读取，金融日历仍可操作。';}}
  async function openHistory(){const area=$('historyContent');$('historyDialog').showModal();area.innerHTML=loadingMarkup('正在读取本机版本备份');try{const d=await getJson('/api/updates/history');area.innerHTML='<p class="source-intro">当前程序 '+esc(d.current_version)+'。'+esc(d.note)+'</p>'+(d.backup_error?'<p class="source-error">'+esc(d.backup_error)+'</p>':'')+(d.items||[]).map(x=>'<article class="history-item"><div><strong>'+esc(x.version)+'</strong><small>升级至 '+esc(x.replaced_by)+' 前的程序备份<br>'+esc(stamp(x.created_at))+'</small></div>'+(x.version!==d.current_version?'<button class="button" data-rollback="'+esc(x.id)+'">回退到此版</button>':'<span>当前版本</span>')+'</article>').join('')+(!(d.items||[]).length?'<p>本机尚无可用的历史程序备份；后续升级将自动保存。</p>':'');}catch{area.innerHTML='<p class="source-error">备份目录暂时无法读取，未更改程序文件。</p>';}}
  async function rollbackVersion(id){if(!window.confirm('确定回退到所选旧版程序？收藏、提醒和持仓代码保留。回退后自动升级将暂停，手动检查更新可恢复。'))return;try{const d=await post('/api/updates/rollback',{id});$('historyContent').innerHTML='<div class="rollback-ready"><h3>已安排回退至 '+esc(d.version)+'</h3><p>'+esc(d.message)+'</p><p>请使用右上角“退出应用”，再从桌面“时序”重新打开。</p></div>';}catch(error){toast(error.message);}}

  function qualityMarkup(e){const q=e.data_quality;if(!q)return '';return '<div class="quality-label quality-'+esc(q.level||'secondary')+'"><strong>'+esc(q.label||'来源待核')+'</strong><span>'+esc(q.basis||'')+'</span>'+(q.warnings||[]).map(x=>'<small>'+esc(x)+'</small>').join('')+'</div>';}
  function eventActionsMarkup(e){return '<div class="event-manage-actions">'+(e.is_personal?'<button class="button" type="button" data-edit-personal="'+esc(e.id)+'">✎ 编辑</button>':'')+'<button class="button" type="button" data-export-event="'+esc(e.id)+'">发送到日历 ↗</button><button class="button remove-event-button" type="button" data-remove-event="'+esc(e.id)+'">删除日程</button></div>';}
  function personalDetailMarkup(e){const r=e.reminder||{},cap=state.personalStatus.scheduler||{},armed=r.state==='scheduled';return '<div class="detail-eyebrow category-personal">我的日程 '+(e.import_uid?'· 从文件导入':'· 本人创建')+'</div><h2 class="detail-title">'+esc(e.title)+'</h2><div class="earnings-when"><span>北京时间 UTC+8</span><strong>'+esc(e.date)+' '+esc(timeLabel(e))+'</strong></div>'+(e.location?'<section class="personal-detail-section"><span>地点</span><p>'+esc(e.location)+'</p></section>':'')+(e.description?'<section class="personal-detail-section"><span>说明</span><p>'+esc(e.description)+'</p></section>':'')+'<section class="personal-detail-section"><span>提醒</span><p>'+esc(r.at?stamp(r.at)+' · '+({scheduled:'待提醒',fired:'已触发',missed:'已错过',failed:'触发失败',cancelled:'已取消'}[r.state]||'处理中'):'未设置提醒')+'</p>'+(armed?'<small>'+esc(cap.status==='ready'?'Windows后台提醒已配置，不必打开时序窗口。':cap.status==='registering'?'正在配置Windows后台提醒。':cap.last_error||'Windows后台提醒尚未就绪，请编辑此日程重新保存提醒。')+'</small>':'')+'</section><p class="transfer-note">保存在本机；不会发送到金融数据源。导出或发送到系统日历由你主动操作。</p>';}
  function personalFormVisibility(){const all=$('personalAllDay').checked;$('personalTimeLabel').hidden=all;$('personalEndTimeLabel').hidden=all;$('personalReminderFields').hidden=!$('personalNotify').checked;}
  function defaultReminderAt(){const date=$('personalDate').value,time=$('personalAllDay').checked?'09:00':$('personalTime').value;if(!date||!time)return;const d=new Date(date+'T'+time+':00+08:00'),at=$('personalAllDay').checked?d:new Date(d.getTime()-15*60000);$('personalReminderAt').value=dateKey(new Date(at.getTime()+8*3600000))+'T'+new Date(at.getTime()+8*3600000).toISOString().slice(11,16);}
  function openPersonal(e=null){state.personalEditing=e;state.personalBusy=false;$('personalTitle').textContent=e?'编辑日程':'新建日程';$('personalEventTitle').value=e?e.title:'';$('personalDate').value=e?e.date:state.date;$('personalAllDay').checked=Boolean(e&&e.all_day);$('personalImportant').checked=Boolean(e&&e.importance==='high');$('personalTime').value=e&&e.start_at?e.start_at.slice(11,16):'19:00';$('personalEndTime').value=e&&e.end_at?e.end_at.slice(11,16):'20:00';$('personalEndDate').value=e&&e.end_at?(e.all_day?dateKey(new Date(Date.parse(e.end_at)-1+8*3600000)):e.end_at.slice(0,10)):$('personalDate').value;$('personalDescription').value=e?e.description||'':'';$('personalLocation').value=e?e.location||'':'';$('personalNotify').checked=Boolean(e&&e.reminder&&e.reminder.state==='scheduled');$('personalPopup').checked=!e||!e.reminder||(e.reminder.channels||[]).includes('popup');$('personalSound').checked=!e||!e.reminder||(e.reminder.channels||[]).includes('sound');defaultReminderAt();if(e&&e.reminder&&e.reminder.at)$('personalReminderAt').value=e.reminder.at.slice(0,16);$('personalError').textContent='';$('savePersonal').disabled=false;$('savePersonal').textContent='保存日程';personalFormVisibility();$('personalDialog').showModal();}
  function personalPayload(){const notify=$('personalNotify').checked,at=$('personalReminderAt').value,channels=[$('personalPopup').checked?'popup':null,$('personalSound').checked?'sound':null].filter(Boolean);if(notify&&(!at||!channels.length))throw new Error('请选择提醒时间和至少一种提醒方式。');return {title:$('personalEventTitle').value,date:$('personalDate').value,time:$('personalTime').value,end_date:$('personalEndDate').value,end_time:$('personalAllDay').checked?'':$('personalEndTime').value,all_day:$('personalAllDay').checked,important:$('personalImportant').checked,description:$('personalDescription').value,location:$('personalLocation').value,reminder_at:notify?at+(at.length===16?':00':'')+'+08:00':null,channels,expected_updated_at:state.personalEditing&&state.personalEditing.updated_at};}
  async function savePersonal(event){if(event)event.preventDefault();if(state.personalBusy||!state.token)return;try{const payload=personalPayload();state.personalBusy=true;$('savePersonal').disabled=true;$('savePersonal').textContent='保存中…';const data=await post('/api/personal/save',{event:payload,...(state.personalEditing?{id:state.personalEditing.id}:{})});$('personalDialog').close();closeDetails();state.date=data.event.date;state.year=+state.date.slice(0,4);state.month=+state.date.slice(5,7);state.categories.add('personal');state.market='all';state.holdingOnly=false;state.query='';state.focus='all';$('search').value='';$('marketFilter').value='all';renderFilters();await load(true);await loadPersonalStatus();await selectEvent(data.event.id,data.event.date);const scheduled=payload.reminder_at,ok=data.scheduler&&data.scheduler.status==='ready';toast(scheduled?(ok?'日程已保存，Windows后台提醒已配置。':data.scheduler&&data.scheduler.status==='registering'?'日程已保存，正在配置Windows后台提醒。':'日程已保存，后台提醒尚未就绪：'+(data.scheduler&&data.scheduler.last_error||'请在Windows桌面版中使用。')):'日程已保存。');if(scheduled&&data.scheduler&&data.scheduler.status==='registering'){state.personalStatusDeadline=Date.now()+60000;pollPersonalStatus();}}catch(error){$('personalError').textContent=error.message;}finally{state.personalBusy=false;$('savePersonal').disabled=false;$('savePersonal').textContent='保存日程';}}
  async function loadPersonalStatus(){try{const d=await getJson('/api/personal/status');state.personalStatus=d;$('personalCount').textContent=String(d.count||0);$('removedCount').textContent=String(d.removed_count||0);return d;}catch{return state.personalStatus;}}
  async function pollPersonalStatus(){clearTimeout(state.personalStatusTimer);const d=await loadPersonalStatus();if(d.scheduler&&d.scheduler.status==='registering'&&Date.now()<state.personalStatusDeadline)state.personalStatusTimer=setTimeout(pollPersonalStatus,1500);else if(d.scheduler&&d.scheduler.status==='ready')toast('Windows后台提醒已就绪，关闭时序窗口仍可提醒。');else if(d.scheduler&&d.scheduler.last_error)toast('日程已保存，后台提醒未完成：'+d.scheduler.last_error);}
  async function removeCurrentEvent(id){const e=state.detailData&&state.detailData.event;if(!e||e.id!==id||state.personalBusy)return;state.personalBusy=true;try{const d=await post('/api/personal/remove',{...range(),event_id:id});closeDetails();await Promise.all([load(true),loadFavorites(),loadPersonalStatus()]);toast(d.warning||'已删除。可在左侧“已移除”中恢复；联网刷新不会重新添加。');}catch(error){toast(error.message);}finally{state.personalBusy=false;}}
  async function removeCurrentGroup(kind,market){if(state.personalBusy)return;if(!window.confirm('从你的日历移除 '+state.date+' 的'+market+(kind==='earnings'?'财报':'重大解禁')+'分组？可以在“已移除”整组恢复；相关收藏提醒将取消。'))return;state.personalBusy=true;try{await post('/api/personal/remove-group',{...range(),date:state.date,kind,group_market:market});closeDetails();await Promise.all([load(true),loadFavorites(),loadPersonalStatus()]);toast('当天这一组已移除，可在“已移除”恢复。');}catch(error){toast(error.message);}finally{state.personalBusy=false;}}
  async function removePendingEvent(id){try{await post('/api/personal/remove',{...range(),event_id:id});await Promise.all([load(true),loadPersonalStatus()]);await renderPending(0);toast('已从待核列表移除，可在“已移除”中恢复。');}catch(error){toast(error.message);}}
  async function loadRemoved(page=0){$('removedList').innerHTML=loadingMarkup('正在读取已移除的日程');try{const d=await getJson('/api/personal/removed?'+new URLSearchParams({page}));state.removedPage=d.page||0;$('removedList').innerHTML=(d.items||[]).map(x=>'<article class="removed-item"><div><strong>'+esc(x.summary.title||'日程')+'</strong><small>'+esc(x.summary.date)+' · '+esc(x.summary.market||'')+' · '+(x.kind==='personal'?'个人日程':'已收录事件')+'</small></div><button class="button" type="button" data-restore-event="'+esc(x.id)+'">恢复</button></article>').join('')+pagination(d,'removed')||'<div class="empty-state">尚未移除任何日程。</div>';}catch(error){$('removedList').innerHTML='<p class="source-error">'+esc(error.message)+'</p>';}}
  async function restoreEvent(id){try{await post('/api/personal/restore',{id});await Promise.all([load(true),loadPersonalStatus(),loadRemoved(state.removedPage)]);toast('日程已恢复。');}catch(error){toast(error.message);}}
  function calendarExportSelection(){const scope=$('exportScope').value,selection={scope,include_estimated:$('exportEstimated').checked?'1':'0'};if(scope==='visible')Object.assign(selection,Object.fromEntries(new URLSearchParams(params())));if(scope==='event'){if(!state.exportEvent)throw new Error('请先选择一条日程。');Object.assign(selection,range(),{id:state.exportEvent.id});}return selection;}
  function updateExportLink(){try{const selection=calendarExportSelection();$('exportEstimatedOption').hidden=selection.scope==='personal'||selection.scope==='event'&&state.exportEvent&&state.exportEvent.is_personal;$('downloadCalendar').href='/api/calendar/export?'+new URLSearchParams(selection);const r=range();$('exportRange').textContent=selection.scope==='personal'?'导出你在本机创建或导入的全部日程。':selection.scope==='visible'?'当前窗口：'+r.start+' 至 '+r.end+'；沿用当前市场、类别与搜索筛选。':selection.scope==='event'?state.exportEvent.title+' · '+state.exportEvent.date:'导出仍在当前日历中可核实的收藏事件。';}catch(error){$('exportRange').textContent=error.message;}}
  function openCalendarTransfer(e=null){state.exportEvent=e;state.importText='';state.importPreview=null;state.importBusy=false;$('exportScope').value=e?'event':'personal';$('exportEventOption').disabled=!e;$('exportEstimated').checked=false;$('calendarImportFile').value='';$('importPreview').innerHTML='';$('importFileName').textContent='最大2MB。先预览，再导入；相同UID不重复添加。';$('previewImport').disabled=true;$('commitImport').disabled=true;$('commitImport').textContent='导入到我的日程';$('calendarImportStatus').textContent='';$('windowsTransferStatus').textContent='';$('importEnableReminders').checked=false;updateExportLink();$('transferDialog').showModal();}
  async function sendWindows(){if(state.personalBusy)return;state.personalBusy=true;$('sendToWindows').disabled=true;$('windowsTransferStatus').textContent='正在生成标准日历文件…';try{const d=await post('/api/calendar/windows',{selection:calendarExportSelection()});$('windowsTransferStatus').textContent='已导出 '+d.exported+' 项，跳过 '+d.excluded+' 项。\n'+d.message+(d.path?'\n文件：'+d.path:'');}catch(error){$('windowsTransferStatus').textContent=error.message;}finally{state.personalBusy=false;$('sendToWindows').disabled=false;}}
  async function readImportFile(){state.importText='';state.importPreview=null;$('commitImport').disabled=true;$('previewImport').disabled=true;$('importPreview').innerHTML='';$('calendarImportStatus').textContent='';const file=$('calendarImportFile').files&&$('calendarImportFile').files[0];if(!file)return;try{if(file.size>2000000)throw new Error('请选择2MB以内的日历文件。');const bytes=await file.arrayBuffer(),array=new Uint8Array(bytes);let encoding='utf-8';if(array[0]===255&&array[1]===254)encoding='utf-16le';if(array[0]===254&&array[1]===255)encoding='utf-16be';state.importText=new TextDecoder(encoding,{fatal:true}).decode(bytes);$('importFileName').textContent=file.name+' · '+Math.ceil(file.size/1024)+'KB · 尚未导入';$('previewImport').disabled=false;}catch(error){$('calendarImportStatus').textContent=error.message;}}
  async function previewCalendarImport(){if(!state.importText||state.importBusy)return;state.importBusy=true;$('previewImport').disabled=true;$('calendarImportStatus').textContent='';try{const d=await post('/api/calendar/import',{action:'preview',text:state.importText});state.importPreview=d;$('importPreview').innerHTML='<div class="import-summary"><strong>可导入 '+d.count+' 项</strong><span>'+d.rejected+' 项未通过 · '+d.reminders+' 项含提醒</span></div>'+(d.warnings||[]).map(x=>'<p class="import-warning">'+esc(x)+'</p>').join('')+(d.items||[]).map(x=>'<div class="import-preview-row"><strong>'+esc(x.title)+'</strong><time>'+esc(x.start_at.replace('T',' ').replace('+08:00',''))+' 北京时间'+(x.all_day?' · 全天':'')+'</time></div>').join('')+(d.count>20?'<p>仅预览前20项，导入将处理全部通过的记录。</p>':'')+(d.errors||[]).slice(0,10).map(x=>'<p class="import-warning">'+esc(x.title)+'：'+esc(x.reason)+'</p>').join('');$('commitImport').disabled=!d.count;$('commitImport').textContent='导入 '+d.count+' 项到我的日程';}catch(error){$('calendarImportStatus').textContent=error.message;state.importPreview=null;$('commitImport').disabled=true;}finally{state.importBusy=false;$('previewImport').disabled=false;}}
  async function commitCalendarImport(){if(!state.importText||!state.importPreview||state.importBusy)return;state.importBusy=true;$('commitImport').disabled=true;$('calendarImportStatus').textContent='';try{const d=await post('/api/calendar/import',{action:'import',text:state.importText,enable_reminders:$('importEnableReminders').checked});$('calendarImportStatus').textContent='已导入 '+d.created+' 项；跳过重复 '+d.duplicates+' 项；未通过 '+d.rejected+' 项。';state.importText='';state.importPreview=null;$('importFileName').textContent=$('importFileName').textContent.replace('尚未导入','处理完成');$('calendarImportFile').value='';$('previewImport').disabled=true;$('commitImport').textContent='导入完成';if(d.created&&d.first_date){state.date=d.first_date;state.year=+state.date.slice(0,4);state.month=+state.date.slice(5,7);state.categories=new Set(['personal']);state.market='all';state.holdingOnly=false;state.query='';state.focus='personal';state.view='agenda';$('search').value='';$('marketFilter').value='all';renderFilters();}await Promise.all([load(true),loadPersonalStatus()]);updateExportLink();if(d.scheduler&&d.scheduler.status==='registering'){state.personalStatusDeadline=Date.now()+60000;pollPersonalStatus();}}catch(error){$('calendarImportStatus').textContent=error.message;$('commitImport').disabled=false;}finally{state.importBusy=false;}}

  if(window.__CALENDAR_V13_TEST__){
    window.__CALENDAR_V13_TEST__({state,range,params,filterKey,applyBootstrap,watchlistPayload,stamp,timePrecision,timeLabel,dateBasis,logoMarkup,companyRow,row,cellEntry,uniqueCompanyLogos,pagination,eventDetailMarkup,detailMarkup,renderDetail,closeDetails,renderMonth,renderDay,renderAgenda,renderSources,renderPending,renderUpdates,renderWatchBanner,selectDate,selectEvent,load,loadDay,loadDetail,checkStatus,checkQuotes,checkUpdates,renderNavigation,renderSearch,loadSearch,highlightSearch,personalPayload,personalDetailMarkup,eventActionsMarkup,qualityMarkup,calendarExportSelection,openPersonal,savePersonal,removeCurrentEvent,restoreEvent,loadRemoved,loadPersonalStatus,updateExportLink,monthPreview,isEconomic,economicMarkup,hourNow,renderAlmanac,loadAlmanac,openHistory,renderQuotes,quoteRefreshNote,refreshData,renderDesktop,checkDesktop,repairDesktop,openInstallFolder,filtersChanged,pendingMarkup,requestChannel,caches,flights,PAGE_SIZE,isEarnings,earningsMetrics,earningsLiveMarkup,earningsDetailMarkup,startEarnings,loadEarnings,cancelEarnings,earningsVisible,handleEarningsVisibility,isOptions,optionsLiveMarkup,optionsDetailMarkup,startOptions,loadOptions,cancelOptions,optionsVisible,handleOptionsVisibility,isMacro,macroValue,macroLiveMarkup,macroDetailMarkup,startMacro,loadMacro,cancelMacro,macroVisible,handleMacroVisibility,metricUnit,metricKind,keyFields,evidenceMarkup,favoriteButtonMarkup,favoriteFor,renderFavorites,applyFavorites,loadFavorites,favoriteAction,toggleFavorite,openFavorites,openFavorite,reminderDefault,reminderPayload,openReminder,saveReminder});
    return;
  }
  document.addEventListener('click',event=>{
    const b=event.target.closest('button');
    if(!b){const cell=event.target.closest('.day-cell');if(cell){selectDate(cell.dataset.day);showDayPopover(cell.dataset.day,cell);}else if(!event.target.closest('#dayPopover'))closeDayPopover();return;}
    if(b.hasAttribute('data-edit-personal')){const e=state.detailData&&state.detailData.event;if(e&&e.is_personal)openPersonal(e);return;}
    if(b.hasAttribute('data-remove-pending')){removePendingEvent(b.dataset.removePending);return;}
    if(b.hasAttribute('data-remove-group')){removeCurrentGroup(b.dataset.removeGroup,b.dataset.groupMarket);return;}
    if(b.hasAttribute('data-remove-event')){removeCurrentEvent(b.dataset.removeEvent);return;}
    if(b.hasAttribute('data-export-event')){const e=state.detailData&&state.detailData.event;if(e)openCalendarTransfer(e);return;}
    if(b.hasAttribute('data-restore-event')){restoreEvent(b.dataset.restoreEvent);return;}
    if(b.dataset.pageKind==='removed'){loadRemoved(Number(b.dataset.pageIndex));return;}
    if(b.hasAttribute('data-open-almanac')){renderAlmanacFull();$('almanacDialog').showModal();return;}
    if(b.hasAttribute('data-rollback')){rollbackVersion(b.dataset.rollback);return;}
    if(b.hasAttribute('data-toggle-favorite')){const e=state.detailData&&state.detailData.event;if(e&&e.id===b.dataset.toggleFavorite)toggleFavorite(e);return;}
    if(b.hasAttribute('data-open-favorite')){openFavorite(b.dataset.openFavorite);return;}
    if(b.hasAttribute('data-remind-favorite')){openReminder(b.dataset.remindFavorite);return;}
    if(b.hasAttribute('data-remove-favorite')||b.hasAttribute('data-cancel-reminder')||b.hasAttribute('data-dismiss-reminder')){const action=b.hasAttribute('data-remove-favorite')?'remove':b.hasAttribute('data-cancel-reminder')?'cancel':'dismiss',id=b.dataset.removeFavorite||b.dataset.cancelReminder||b.dataset.dismissReminder;favoriteAction({action,id}).catch(error=>toast(error.message));return;}
    if(b.hasAttribute('data-favorites-page')){state.favoritesPage=Math.max(0,Number(b.dataset.favoritesPage)||0);renderFavorites();return;}
    if(b.hasAttribute('data-refresh-macro')){if(state.detailData&&isMacro(state.detailData.event))startMacro(state.detailData.event,true);return;}
    if(b.hasAttribute('data-refresh-options')){if(state.detailData&&isOptions(state.detailData.event))startOptions(state.detailData.event,true);return;}
    if(b.hasAttribute('data-open-sources')){$('sourcesDialog').showModal();renderSources();return;}
    if(b.hasAttribute('data-open-pending')){renderPending();$('pendingDialog').showModal();return;}
    if(b.hasAttribute('data-open-day')){closeDayPopover();$('dayList').scrollIntoView({block:'start'});return;}
    if(b.hasAttribute('data-refresh-earnings')){if(state.detailData&&isEarnings(state.detailData.event))startEarnings(state.detailData.event,true);return;}
    if(b.hasAttribute('data-clear-search')){state.query='';$('search').value='';return filtersChanged();}
    if(b.dataset.pageKind==='search')return loadSearch(Number(b.dataset.pageIndex));
    if(b.dataset.view){state.view=b.dataset.view;state.focus='all';renderNavigation();if(state.view==='month')renderMonth();else renderAgenda();return;}
    if(b.dataset.date){const anchor=b.closest('.day-cell')||b;selectDate(b.dataset.date);showDayPopover(b.dataset.date,anchor);return;}
    if(b.dataset.entry){closeDayPopover();selectEvent(b.dataset.entry,b.dataset.entryDate);return;}
    if(b.dataset.event){closeDayPopover();selectEvent(b.dataset.event,b.dataset.eventDate);return;}
    if(b.dataset.pageKind){const page=Math.max(0,Number(b.dataset.pageIndex)||0);phase('page '+b.dataset.pageKind);if(b.dataset.pageKind==='detail')loadDetail(page);else if(b.dataset.pageKind==='day')loadDay(page);else renderPending(page);return;}
    if(b.hasAttribute('data-retry-day')){loadDay(state.dayPage);return;}
    if(b.hasAttribute('data-retry-detail'))loadDetail(state.detailPage);
  });
  document.addEventListener('change',event=>{if(event.target.dataset.category){const c=event.target.dataset.category;event.target.checked?state.categories.add(c):state.categories.delete(c);state.focus='all';filtersChanged();}});
  document.addEventListener('error',event=>{const img=event.target;if(img&&img.matches&&img.matches('img.company-logo')){img.hidden=true;const fallback=img.parentElement.querySelector('.logo-fallback');if(fallback)fallback.hidden=false;}},true);
  $('newEventButton').addEventListener('click',()=>openPersonal());$('closePersonal').addEventListener('click',()=>$('personalDialog').close());$('cancelPersonal').addEventListener('click',()=>$('personalDialog').close());$('personalForm').addEventListener('submit',savePersonal);
  $('personalAllDay').addEventListener('change',()=>{personalFormVisibility();defaultReminderAt();});$('personalNotify').addEventListener('change',personalFormVisibility);for(const id of ['personalDate','personalTime'])$(id).addEventListener('change',defaultReminderAt);
  $('personalHomeButton').addEventListener('click',()=>{state.categories=new Set(['personal']);state.market='all';state.holdingOnly=false;state.focus='personal';state.query='';$('search').value='';$('marketFilter').value='all';state.view='agenda';filtersChanged();});
  $('removedButton').addEventListener('click',()=>{loadRemoved();$('removedDialog').showModal();});$('closeRemoved').addEventListener('click',()=>$('removedDialog').close());
  $('calendarTransferButton').addEventListener('click',()=>openCalendarTransfer());$('closeTransfer').addEventListener('click',()=>$('transferDialog').close());$('exportScope').addEventListener('change',updateExportLink);$('exportEstimated').addEventListener('change',updateExportLink);$('sendToWindows').addEventListener('click',sendWindows);$('calendarImportFile').addEventListener('change',readImportFile);$('previewImport').addEventListener('click',previewCalendarImport);$('commitImport').addEventListener('click',commitCalendarImport);
  $('favoritesButton').addEventListener('click',openFavorites);$('refreshFavorites').addEventListener('click',loadFavorites);$('closeReminder').addEventListener('click',()=>$('reminderDialog').close());$('saveReminder').addEventListener('click',saveReminder);
  $('historyButton').addEventListener('click',openHistory);$('closeHistory').addEventListener('click',()=>$('historyDialog').close());$('closeAlmanac').addEventListener('click',()=>$('almanacDialog').close());
  $('updateButton').addEventListener('click',()=>checkUpdates(true));$('closePopover').addEventListener('click',closeDayPopover);
  document.addEventListener('keydown',event=>{if(event.key==='Escape')closeDayPopover();});
  $('ipoHomeButton').addEventListener('click',()=>{state.categories=new Set(['ipo']);state.focus='ipo';state.holdingOnly=false;state.market='all';$('marketFilter').value='all';state.view='agenda';filtersChanged();});
  $('allEventsButton').addEventListener('click',()=>{state.view='month';reset();});
  $('holdingOnly').addEventListener('change',e=>{state.holdingOnly=e.target.checked;filtersChanged();});$('holdingsOnlyButton').addEventListener('click',toggleHoldings);
  $('holdingsTodayButton').addEventListener('click',()=>{state.holdingOnly=true;state.categories=new Set(Object.keys(CATS));state.date=today();state.year=+state.date.slice(0,4);state.month=+state.date.slice(5,7);filtersChanged();});
  $('manageWatchlist').addEventListener('click',openWatchlist);$('closeWatchlist').addEventListener('click',()=>$('watchlistDialog').close());
  $('saveWatchlist').addEventListener('click',async()=>{
    try{
      const payload=watchlistPayload($('watchlistInput').value,$('watchlistFactDate').value),symbols=payload.symbols,date=payload.fact_date;
      const saved=await post('/api/watchlist',payload);
      state.watchlist=Array.isArray(saved.watchlist)?saved.watchlist:saved.watchlist&&saved.watchlist.symbols||saved.symbols||symbols;
      state.watchlistFactDate=saved.fact_date||saved.watchlist_fact_date||date;$('watchlistDialog').close();await load(true);toast('本机证券代码列表已更新。');
    }catch(error){$('watchlistError').textContent=error.message;}
  });
  $('prevMonth').addEventListener('click',()=>moveMonth(-1));$('nextMonth').addEventListener('click',()=>moveMonth(1));$('todayButton').addEventListener('click',()=>selectDate(today()));$('resetFilters').addEventListener('click',reset);
  let searchTimer;
  $('search').addEventListener('input',event=>{state.query=event.target.value;clearTimeout(searchTimer);searchTimer=setTimeout(filtersChanged,180);});
  $('marketFilter').addEventListener('change',event=>{state.market=event.target.value;filtersChanged();});
  $('refreshButton').addEventListener('click',refreshData);
  $('desktopTools').addEventListener('toggle',()=>{if($('desktopTools').open){state.desktopDeadline=Date.now()+60000;checkDesktop();}else{clearTimeout(state.desktopTimer);state.desktopTimer=null;}});
  $('repairDesktop').addEventListener('click',repairDesktop);$('openInstallFolder').addEventListener('click',openInstallFolder);
  $('quotesRefresh').addEventListener('click',refreshData);
  $('shutdownButton').addEventListener('click',async()=>{
    if(!state.token||state.closed)return;
    try{
      await post('/api/shutdown');state.closed=true;state.monthRequest++;state.dayRequest++;state.detailRequest++;state.pendingRequest++;
      cancelEarnings(true);cancelOptions(true);cancelMacro(true);flights.forEach(flight=>flight.controller.abort());state.timers.forEach(clearInterval);clearTimeout(state.poll);clearTimeout(state.desktopTimer);clearTimeout(state.personalStatusTimer);
      $('refreshButton').disabled=true;$('quotesRefresh').disabled=true;$('connectionTitle').textContent='应用服务已退出';$('connectionText').textContent='联网更新已停止，可关闭窗口。';
    }catch(error){toast('退出未完成。'+error.message);}
  });
  $('closeDetailDrawer').addEventListener('click',closeDetails);
  if(window.matchMedia){const screen=window.matchMedia('(max-width:1099px)');if(screen.addEventListener)screen.addEventListener('change',()=>{if(state.selected)renderDetail();});}
  $('detailDialog').addEventListener('close',()=>{if(state.selected){cancelEarnings(true);cancelOptions(true);cancelMacro(true);state.selected=null;state.detailRequest++;abortChannel('detail');renderDetail();}});
  document.addEventListener('visibilitychange',()=>{handleEarningsVisibility();handleOptionsVisibility();handleMacroVisibility();if(!document.hidden&&state.focus==='favorites')loadFavorites();});
  $('closeDialog').addEventListener('click',closeDetails);$('closeSources').addEventListener('click',()=>$('sourcesDialog').close());$('closePending').addEventListener('click',()=>$('pendingDialog').close());
  renderFilters();render();renderSources();renderUpdates();
  (async()=>{try{applyBootstrap(await getJson('/api/bootstrap'));}catch{state.error='无法读取本机服务配置。';}await load();await Promise.all([checkQuotes(),checkUpdates(),loadFavorites(),loadPersonalStatus()]);})();
  state.timers.push(setInterval(()=>{if(!document.hidden)loadPersonalStatus();},60000),setInterval(()=>{if(!document.hidden)renderAlmanac();},60000),setInterval(checkStatus,5*60*1000),setInterval(()=>refresh(false),15*60*1000),setInterval(checkQuotes,60*1000),setInterval(()=>checkUpdates(),60*1000),setInterval(()=>{if(!document.hidden&&state.focus==='favorites')loadFavorites();},30000));
}());
