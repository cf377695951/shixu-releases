"""Windows desktop launcher. Python 3.11+, no third-party dependencies.

The launcher starts only this calendar's loopback service. It never registers
startup tasks or changes the system browser's security settings.
"""
from __future__ import annotations

import argparse
import contextlib
import ctypes
import json
import ntpath
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

ROOT = Path(sys._MEIPASS) if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
APP_NAME = "时序"
APP_ID = "willance-event-calendar"
APP_VERSION = "1.10.0"
MAX_READY_SIZE = 16_384
CAPTION_NAVY = 0x004C2C10  # COLORREF is 0x00BBGGRR: #102C4C.
CAPTION_TEXT = 0x00FFFFFF
_window_icons: dict[tuple[str, int], int] = {}


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Local calendar requests must not redirect")


def runtime_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if not base:
        base = str(Path.home() / ".local" / "share")
    target = Path(base) / "Willance" / "EventCalendarV1" / "runtime"
    target.mkdir(parents=True, exist_ok=True, mode=0o700)
    return target


def validated_url(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("Invalid calendar address")
    parsed = urlsplit(value)
    if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1"
            or parsed.username or parsed.password or parsed.query
            or parsed.fragment or parsed.path not in ("", "/")
            or not parsed.port or not 1 <= parsed.port <= 65535):
        raise ValueError("Calendar address must be a loopback HTTP origin")
    return f"http://127.0.0.1:{parsed.port}/"


def local_json(url: str, *, token: str | None = None,
               method: str = "GET") -> dict:
    headers = {"Accept": "application/json"}
    if token:
        headers["X-Calendar-Token"] = token
    request = Request(url, data=b"{}" if method == "POST" else None,
                      headers=headers, method=method)
    with build_opener(ProxyHandler({}), NoRedirects()).open(request, timeout=2) as response:
        raw = response.read(65_537)
        if len(raw) > 65_536:
            raise ValueError("Unexpectedly large local response")
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise ValueError("Invalid local response")
        return result


def read_running(ready: Path) -> str | None:
    try:
        if ready.stat().st_size > MAX_READY_SIZE:
            return None
        payload = json.loads(ready.read_text(encoding="utf-8"))
        url = validated_url(payload["url"])
        health = local_json(url + "api/health")
        if health.get("ok") is True and health.get("app") == APP_ID:
            return url
    except (OSError, ValueError, KeyError, TypeError, URLError):
        pass
    return None


@contextlib.contextmanager
def startup_lock():
    """Serialize desktop launches for this user without leaving stale locks."""
    if os.name != "nt":
        import fcntl
        with (runtime_dir() / "launch.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            yield
        return
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
    kernel.CreateMutexW.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.ReleaseMutex.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    mutex = kernel.CreateMutexW(None, False, "Local\\WillanceEventCalendarV1Launch")
    if not mutex:
        raise OSError(ctypes.get_last_error(), "Cannot obtain calendar startup lock")
    acquired = kernel.WaitForSingleObject(mutex, 35_000)
    if acquired not in (0, 0x80):
        kernel.CloseHandle(mutex)
        raise RuntimeError("另一个日历启动过程仍在进行，请稍后重试。")
    try:
        yield
    finally:
        kernel.ReleaseMutex(mutex)
        kernel.CloseHandle(mutex)


def python_for_server() -> str:
    if not getattr(sys, "frozen", False):
        bundled = ROOT / "runtime" / ("pythonw.exe" if os.name == "nt" else "python")
        if bundled.is_file():
            return str(bundled)
    candidate = Path(sys.executable)
    if os.name == "nt" and candidate.name.lower() == "python.exe":
        hidden = candidate.with_name("pythonw.exe")
        if hidden.is_file():
            return str(hidden)
    return str(candidate)


def server_command(ready: Path) -> list[str]:
    command = [python_for_server()]
    if getattr(sys, "frozen", False):
        command.append("--calendar-server")
    else:
        command.append(str(ROOT / "app.py"))
    return command + ["--port", "0", "--ready-file", str(ready)]


def find_edge() -> str | None:
    candidates = []
    for name in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        value = os.environ.get(name)
        if value:
            candidates.append(Path(value) / "Microsoft" / "Edge" / "Application" / "msedge.exe")
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return shutil.which("msedge")


def edge_command(edge: str, url: str) -> list[str]:
    profile = runtime_dir().parent / 'desktop-profile'
    profile.mkdir(parents=True, exist_ok=True, mode=0o700)
    # Chromium's UI-only dark preference is confined to this separate profile;
    # the calendar declares color-scheme:light and keeps its own page palette.
    # It gives custom Chromium titlebars an alternative to the system accent
    # where Windows' per-window caption attributes are unavailable/ignored.
    return [edge, f"--app={validated_url(url)}", f"--user-data-dir={profile}",
            "--force-dark-mode", "--no-first-run", "--no-default-browser-check", "--new-window"]


def _windows_arguments(command_line: str) -> list[str]:
    """Use Windows' argument parser, avoiding fragile path substring tests."""
    from ctypes import wintypes
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
    kernel.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel.LocalFree.restype = wintypes.HLOCAL
    count = ctypes.c_int()
    argv = shell.CommandLineToArgvW(command_line, ctypes.byref(count))
    if not argv:
        return []
    try:
        return [argv[index] for index in range(count.value)]
    finally:
        kernel.LocalFree(ctypes.cast(argv, wintypes.HLOCAL))


def _owns_edge_arguments(arguments: list[str], profile: Path) -> bool:
    """The dedicated Edge profile and a loopback app origin must both match."""
    options = {}
    for index, value in enumerate(arguments):
        if value.startswith('--') and '=' in value:
            key, option = value.split('=', 1)
            options[key.lower()] = option
        elif value.lower() in ('--user-data-dir', '--app') and index + 1 < len(arguments):
            options[value.lower()] = arguments[index + 1]
    expected = ntpath.normcase(ntpath.normpath(str(profile)))
    supplied = options.get('--user-data-dir', '')
    if not supplied or ntpath.normcase(ntpath.normpath(supplied)) != expected:
        return False
    try:
        validated_url(options.get('--app'))
    except (ValueError, TypeError):
        return False
    return True


def _owned_edge_pids(profile: Path, *, timeout: float = 3.0) -> set[int]:
    """Inspect Edge only, once per short branding session; never terminate it."""
    import base64
    code = ("[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);"
            "@(Get-CimInstance Win32_Process -Filter \"Name='msedge.exe'\" | "
            "Select-Object ProcessId,CommandLine)|ConvertTo-Json -Compress")
    encoded = base64.b64encode(code.encode('utf-16-le')).decode('ascii')
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive',
                             '-EncodedCommand', encoded], stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            creationflags=subprocess.CREATE_NO_WINDOW, timeout=max(.1, min(timeout, 3.0)))
    if result.returncode:
        return set()
    rows = json.loads(result.stdout.decode('utf-8-sig').strip() or '[]')
    if isinstance(rows, dict):
        rows = [rows]
    return {int(row['ProcessId']) for row in rows if isinstance(row, dict)
            and _owns_edge_arguments(_windows_arguments(row.get('CommandLine') or ''), profile)}


def _owns_calendar_window(pid: int, owned_pids: set[int], window_class: str,
                          title: str) -> bool:
    return (pid in owned_pids and window_class == 'Chrome_WidgetWin_1'
            and (title == APP_NAME or title.startswith('时序 ·')
                 or title.startswith('时序投资日历')
                 or any(title.startswith(APP_NAME + separator)
                        for separator in (' - ', ' – ', ' — '))))


class _WindowsBranding:
    """Documented per-window APIs only; all pointer-size signatures are explicit."""
    def __init__(self):
        from ctypes import wintypes
        self.w = wintypes
        self.user = ctypes.WinDLL('user32', use_last_error=True)
        self.dwm = ctypes.WinDLL('dwmapi', use_last_error=True)
        self.callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        self.user.EnumWindows.argtypes = [self.callback_type, wintypes.LPARAM]
        self.user.EnumWindows.restype = wintypes.BOOL
        self.user.IsWindowVisible.argtypes = [wintypes.HWND]
        self.user.IsWindowVisible.restype = wintypes.BOOL
        self.user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user.GetWindowThreadProcessId.restype = wintypes.DWORD
        for name in ('GetWindowTextW', 'GetClassNameW'):
            getattr(self.user, name).argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
            getattr(self.user, name).restype = ctypes.c_int
        self.user.SetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
        self.user.SetWindowTextW.restype = wintypes.BOOL
        self.user.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
                                        ctypes.c_int, ctypes.c_int, wintypes.UINT]
        self.user.LoadImageW.restype = wintypes.HANDLE
        self.user.SendMessageTimeoutW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
            wintypes.LPARAM, wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_size_t)]
        self.user.SendMessageTimeoutW.restype = wintypes.LPARAM
        self.dwm.DwmSetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD,
            ctypes.c_void_p, wintypes.DWORD]
        self.dwm.DwmSetWindowAttribute.restype = ctypes.c_long
        self.build = sys.getwindowsversion().build

    def windows(self, owned_pids: set[int]) -> list[int]:
        found = []
        def visit(hwnd, unused):
            if not self.user.IsWindowVisible(hwnd):
                return True
            pid = self.w.DWORD()
            self.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value not in owned_pids:
                return True
            title, kind = ctypes.create_unicode_buffer(1024), ctypes.create_unicode_buffer(256)
            self.user.GetWindowTextW(hwnd, title, len(title))
            self.user.GetClassNameW(hwnd, kind, len(kind))
            if _owns_calendar_window(pid.value, owned_pids, kind.value, title.value):
                found.append(hwnd)
            return True
        callback = self.callback_type(visit)
        self.user.EnumWindows(callback, 0)
        return found

    def _attribute(self, hwnd: int, attribute: int, value: int) -> bool:
        color = self.w.DWORD(value)
        return self.dwm.DwmSetWindowAttribute(hwnd, attribute, ctypes.byref(color), ctypes.sizeof(color)) == 0

    def apply(self, hwnd: int, icon: Path | None) -> dict:
        title = ctypes.create_unicode_buffer(APP_NAME)
        result = ctypes.c_size_t()
        self.user.SendMessageTimeoutW(hwnd, 0x0C, 0, ctypes.cast(title, ctypes.c_void_p).value,
                                     0x2, 100, ctypes.byref(result))
        # Color attributes 34/35/36 are documented for Windows 11 build 22000+.
        caption, text = False, False
        if self.build >= 22000:
            caption = self._attribute(hwnd, 35, CAPTION_NAVY)
            text = self._attribute(hwnd, 36, CAPTION_TEXT)
            self._attribute(hwnd, 34, CAPTION_NAVY)
        # Attribute 20 is a documented per-window dark-caption fallback. Its
        # HRESULT is checked; older Windows/Edge frames may not support it.
        dark = False
        if not caption and self.build >= 17763:
            dark = self._attribute(hwnd, 20, 1)
        icons = 0
        if icon is not None and icon.is_file():
            for flag, size in ((0, 16), (1, 32)):
                key = (str(icon), size)
                if key not in _window_icons:
                    handle = self.user.LoadImageW(None, str(icon), 1, size, size, 0x10)
                    if handle:
                        _window_icons[key] = handle
                handle = _window_icons.get(key)
                if handle:
                    result = ctypes.c_size_t()
                    if self.user.SendMessageTimeoutW(hwnd, 0x80, flag, handle,
                                                    0x2, 100, ctypes.byref(result)):
                        icons += 1
        return {'caption': 'navy-requested' if caption and text else 'dark-allowed' if dark else 'system',
                'caption_api_accepted': caption, 'text_api_accepted': text,
                'icons_set': icons, 'windows_build': self.build}


def _run_branding_session(url: str, timeout: float) -> dict:
    """Run only after this exact installed version has passed local health."""
    started = time.monotonic()
    status: dict = {'version': APP_VERSION, 'app': APP_NAME, 'status': 'waiting'}
    until = started + max(0.1, min(timeout, 12.0))
    while time.monotonic() < until:
        try:
            health = local_json(url + 'api/health')
            if health.get('ok') is True and health.get('app') == APP_ID and health.get('version') == APP_VERSION:
                break
        except Exception:
            pass
        time.sleep(.15)
    else:
        return {**status, 'status': 'health-not-confirmed'}
    try:
        from desktop.install import migrate_shortcuts
        status['shortcut'] = migrate_shortcuts(ROOT, Path(python_for_server()))
    except Exception as error:
        status['shortcut'] = {'status': 'preserved', 'note': str(error)}
    # A redirected Desktop/COM call can be slower than the native styling. Give
    # the new Edge frame its own bounded discovery budget after link migration.
    until = time.monotonic() + max(.1, min(timeout, 12.0))
    try:
        native = _WindowsBranding()
    except Exception as error:
        return {**status, 'status': 'native-unavailable',
                'window': {'caption': 'system', 'error': str(error)[:500]}}
    # A service-owned HICON remains valid for the service lifetime. A launcher
    # exits shortly: do not replace Edge's own favicon with a temporary HICON.
    persistent_host = Path(sys.argv[0]).name.lower() == 'app.py' or '--calendar-server' in sys.argv
    icon = ROOT / 'branding' / 'shixu.ico' if persistent_host else None
    profile = runtime_dir().parent / 'desktop-profile'
    pids: set[int] = set()
    queried = False
    seen = set()
    try:
        while time.monotonic() < until:
            if not pids or not queried:
                pids = _owned_edge_pids(profile, timeout=until - time.monotonic())
                queried = True
            for hwnd in native.windows(pids):
                status['window'] = native.apply(hwnd, icon)
                seen.add(hwnd)
            if seen:
                # Edge can finish setting its frame after becoming visible.
                for delay in (.2, .4, .7):
                    remaining = until - time.monotonic()
                    if remaining <= 0:
                        break
                    time.sleep(min(delay, remaining))
                    for hwnd in native.windows(pids):
                        status['window'] = native.apply(hwnd, icon)
                break
            time.sleep(.35)
    except Exception as error:
        status['window'] = {'caption': 'system', 'error': str(error)[:500]}
        status['status'] = 'native-unavailable'
        return status
    status['status'] = 'applied' if seen else 'no-owned-window'
    return status


def _branding_snapshot(result: dict | None = None) -> dict:
    """Small local status for the UI; no process command lines or credentials."""
    result = result or {}
    shortcut = result.get('shortcut') if isinstance(result.get('shortcut'), dict) else {}
    window = result.get('window') if isinstance(result.get('window'), dict) else {}
    raw_state = result.get('status') or 'not-checked'
    supported = os.name == 'nt'
    shortcut_ready = shortcut.get('status') == 'ready'
    needs_reopen = raw_state == 'applied' and window.get('caption') != 'navy-requested'
    incomplete_cleanup = bool(shortcut.get('preserved') or shortcut.get('unmatched'))
    errors = [str(value)[:500] for value in (result.get('note'), shortcut.get('note'), window.get('error')) if value]
    if not supported:
        state, message = 'unsupported', '桌面入口修复仅支持Windows；当前可查看程序位置。'
    elif raw_state in ('waiting', 'repairing', 'running'):
        state, message = 'repairing', '正在核对这份安装的桌面入口和窗口，请稍候。'
    elif shortcut_ready and not incomplete_cleanup:
        state = 'ready' if raw_state == 'applied' and not needs_reopen else 'partial'
        message = '桌面入口已更新为“时序”，以后从这个入口打开即可。'
        if state == 'partial':
            message += ' 标题栏样式尚未确认；请完整退出并关闭旧日历窗口，再从新入口重开，系统不支持时保留系统颜色。'
    elif shortcut_ready:
        state, message = 'partial', '新“时序”入口已创建，部分旧入口未能移除或无法确认归属，已保留；请以后从新入口打开。'
    elif raw_state == 'not-checked':
        state, message = 'not-checked', '桌面入口尚未核对，可点“修复桌面入口”；程序已安装在下方位置。'
    else:
        state, message = 'error', '桌面入口尚未更新，原入口仍可用；可点“修复桌面入口”重试。'
    return {'supported': supported, 'app': APP_NAME, 'version': APP_VERSION,
            'install_dir': str(ROOT), 'launcher_path': str(ROOT/'desktop'/'launcher.py'),
            'shortcut_path': str(shortcut.get('shortcut') or result.get('shortcut_path') or ''),
            'state': state, 'error': '；'.join(errors)[:1000], 'message': message,
            'shortcut': shortcut, 'window': window, 'requires_reopen': needs_reopen,
            'updated_at': result.get('updated_at')}


def desktop_status() -> dict:
    """Read status only; opening the settings section never runs COM or scans Edge."""
    try:
        path = runtime_dir()/'branding-status.json'
        if path.stat().st_size > 32_768:
            raise ValueError('桌面入口状态文件超出限制')
        result = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(result, dict):
            raise ValueError('桌面入口状态格式无效')
        # Older snapshots can be informative but cannot claim the latest repair.
        if result.get('version') != APP_VERSION:
            result = {**result, 'status': 'not-checked', 'shortcut': {},
                      'note': '升级后尚未确认桌面入口。'}
        return _branding_snapshot(result)
    except FileNotFoundError:
        return _branding_snapshot()
    except (OSError, ValueError, TypeError) as error:
        return _branding_snapshot({'status': 'not-checked', 'note': str(error)[:300]})


def _save_branding_status(result: dict) -> dict:
    result = {**result, 'version': APP_VERSION, 'updated_at': time.time()}
    target = runtime_dir()/'branding-status.json'
    temporary = target.with_name('branding-status.' + str(os.getpid()) + '.tmp')
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(target)
    return _branding_snapshot(result)


def request_desktop_repair(url: str) -> dict:
    """Explicit UI action; one bounded background job, same scope as startup."""
    url = validated_url(url)
    if os.name != 'nt':
        return _branding_snapshot()
    start_branding_session(url, background=True)
    # Return a real immediate state; the worker writes its terminal snapshot.
    status = desktop_status()
    if status['state'] in ('not-checked', 'ready', 'partial', 'error'):
        status.update(state='repairing', message='正在核对这份安装的桌面入口和窗口，请稍候。')
    return status


def start_branding_session(url: str, *, background: bool = True,
                           timeout: float = 8.0):
    """Best-effort, bounded branding; never affects calendar startup success.

    Called by the newly healthy server too, so the first launch after an update
    works even when the old launcher module was already loaded in memory.
    """
    url = validated_url(url)
    if os.name != 'nt':
        return {'status': 'unsupported', 'note': 'Windows专用窗口品牌设置'}
    def work():
        lock = runtime_dir() / 'branding.lock'
        try:
            # Health, redirected Desktop COM and native discovery have separate
            # budgets. Do not break a live migration after only thirty seconds.
            if lock.exists() and time.time() - lock.stat().st_mtime > 120:
                lock.unlink(missing_ok=True)
            try:
                descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                return {'status': 'already-running'}
            os.close(descriptor)
            try:
                _save_branding_status({'status': 'repairing'})
                result = _run_branding_session(url, timeout)
            except Exception as error:
                result = {'version': APP_VERSION, 'status': 'preserved', 'note': str(error)}
            finally:
                lock.unlink(missing_ok=True)
            _save_branding_status(result)
            return result
        except Exception:
            return {'status': 'preserved'}
    if not background:
        return work()
    thread = threading.Thread(target=work, name='calendar-window-branding', daemon=True)
    thread.start()
    return thread


def start_server(ready: Path, expected_version: str | None = None) -> str:
    expected_version = expected_version or APP_VERSION
    existing = read_running(ready)
    if existing:
        health=local_json(existing+'api/health')
        if health.get('version')==expected_version:
            return existing
        # Upgrade only the identified calendar service; never touch other tasks.
        stop_server(ready)
        deadline=time.monotonic()+5
        while read_running(ready) and time.monotonic()<deadline:time.sleep(.1)
        if read_running(ready):raise RuntimeError('旧版日历尚未退出，请在日历中退出后重试。')
    if not getattr(sys, "frozen", False) and not (ROOT / "app.py").is_file():
        raise RuntimeError("未找到 app.py。请先完整解压安装包，不要在压缩包内直接运行。")
    ready.unlink(missing_ok=True)
    log_path = runtime_dir() / "service.log"
    if log_path.exists() and log_path.stat().st_size > 2_000_000:
        old = log_path.with_suffix(".previous.log")
        old.unlink(missing_ok=True)
        log_path.replace(old)
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    with log_path.open("ab") as log:
        process = subprocess.Popen(
            server_command(ready), cwd=str(ROOT),
            stdin=subprocess.DEVNULL, stdout=log, stderr=log,
            creationflags=flags,
        )
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"日历服务启动失败。请查看 {log_path}")
        url = read_running(ready)
        if url:
            return url
        time.sleep(0.15)
    # This child belongs to the launch attempt; do not leave a failed startup.
    process.terminate()
    raise RuntimeError(f"日历启动超时。请查看 {log_path}")


def stop_server(ready: Path) -> bool:
    url = read_running(ready)
    if not url:
        return False
    token = local_json(url + "api/bootstrap").get("token")
    if not isinstance(token, str) or not token:
        raise RuntimeError("本机日历未返回退出令牌，未执行关闭。")
    local_json(url + "api/shutdown", token=token, method="POST")
    return True


def stop_for_update(ready: Path) -> None:
    """Only stop the service identified by this calendar's private ready file."""
    if not read_running(ready):
        return
    stop_server(ready)
    deadline = time.monotonic() + 5
    while read_running(ready) and time.monotonic() < deadline:
        time.sleep(.1)
    if read_running(ready):
        raise RuntimeError('日历服务尚未退出，保留原版本，请稍后重开。')


def launch_with_updates(ready: Path) -> str:
    """Apply a verified staged app update at the existing launch boundary."""
    from desktop.updater import UpdateManager
    manager = UpdateManager(ROOT, APP_VERSION)
    transaction = ROOT / '.updates' / 'transaction.json'
    if transaction.exists():
        # A crashed promotion is rolled back before any app code is started.
        old = json.loads(transaction.read_text(encoding='utf-8'))['from_version']
        stop_for_update(ready)
        manager.rollback_last()
        url = start_server(ready, expected_version=old)
        if local_json(url + 'api/health').get('version') != old:
            raise RuntimeError('恢复原版本后，服务版本核验未通过。')
        return url
    if not (ROOT / '.updates' / 'pending.json').exists():
        return start_server(ready)
    stop_for_update(ready)
    try:
        target = manager.apply_pending()
        if not target:
            return start_server(ready, expected_version=manager.current_version)
        url = start_server(ready, expected_version=target)
        if local_json(url + 'api/health').get('version') != target:
            raise RuntimeError('新版服务版本核验未通过。')
        manager.confirm_started(running_version=target)
        return url
    except Exception:
        stop_for_update(ready)
        manager.rollback_last()
        url = start_server(ready, expected_version=APP_VERSION)
        if local_json(url + 'api/health').get('version') != APP_VERSION:
            raise RuntimeError('自动回退后，原版本启动未通过。')
        return url


def show_error(message: str) -> None:
    if os.name == "nt":
        ctypes.windll.user32.MessageBoxW(None, message, APP_NAME, 0x10)
    else:
        print(message, file=sys.stderr)


def main() -> int:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--stop", action="store_true", help="仅退出本日历服务")
    parser.add_argument("--browser", action="store_true", help="使用普通浏览器窗口")
    parser.add_argument("--print-url", action="store_true", help="启动后只打印本机地址")
    parser.add_argument("--install", action="store_true", help="安装本程序并创建桌面快捷方式")
    parser.add_argument("--uninstall", action="store_true", help="移除本程序安装与快捷方式")
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        show_error("需要 Python 3.11 或更新版本；请从 https://www.python.org/downloads/windows/ 安装。")
        return 1
    try:
        if args.install or args.uninstall:
            if os.name != "nt":
                raise RuntimeError("桌面安装入口只用于 Windows。")
            from desktop.install import install, uninstall
            if args.uninstall:
                uninstall()
            else:
                install()
            return 0
        ready = runtime_dir() / "ready.json"
        with startup_lock():
            if args.stop:
                stop_server(ready)
                return 0
            url = launch_with_updates(ready)
        if args.print_url:
            print(url)
            return 0
        edge = find_edge()
        if edge and not args.browser:
            flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            subprocess.Popen(edge_command(edge, url),
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=flags)
            # The service also runs this helper on upgrade. This synchronous
            # fallback survives launcher exit when reopening an existing service.
            start_branding_session(url, background=False)
        else:
            import webbrowser
            webbrowser.open(url, new=1)
        return 0
    except Exception as error:
        show_error(str(error))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
