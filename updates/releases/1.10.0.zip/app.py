"""Willance Event Calendar V1. Local-only desktop service; Python stdlib."""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import calendar
import copy
import datetime as dt
import gzip
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from selection_policy import apply_policy,is_st,evidence_quality
from timing_policy import normalize_events
from quote_service import QuoteService
from quotes import quote_key
from logos import apply_branding, logo_asset, prewarm
from desktop.updater import UpdateManager, UpdateError, verify_installed_baseline
from ir_policy import add_verified_ir_events
from retention_policy import retain_failed_sources,event_source

ROOT = Path(__file__).resolve().parent
UTC = dt.timezone.utc
BJ = dt.timezone(dt.timedelta(hours=8))
VERSION = '1.10.0'
CATEGORIES = {'macro','earnings','unlock','options','crypto','season','holiday','politics','ipo','astronomy'}
MAX_CACHE = 40 * 1024 * 1024

def utcnow():
    return dt.datetime.now(UTC).isoformat(timespec='seconds')

def period(start=None, end=None):
    today=dt.datetime.now(BJ).date()
    first=dt.date.fromisoformat(start) if start else today.replace(day=1)
    last=dt.date.fromisoformat(end) if end else dt.date(first.year, first.month, calendar.monthrange(first.year,first.month)[1])
    if last < first or (last-first).days > 62:
        raise ValueError('日期范围须为1至63天')
    return first.isoformat(),last.isoformat()

def month_key(start, end):
    return start+'_'+end

def atomic_json(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.tmp')
    with temp.open('w',encoding='utf-8') as f:
        json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False)
    os.replace(temp,path)

def normalize_exact_event(item):
    e=copy.deepcopy(item)
    value=str(e.get('time',''))
    if not re.fullmatch(r'\d{2}:\d{2}',value): return e
    hh,mm=map(int,value.split(':'))
    if not (0<=hh<24 and 0<=mm<60): raise ValueError('事件时刻无效')
    zone=e.get('timezone')
    if zone in ('Asia/Shanghai','Asia/Hong_Kong','UTC+08:00'): return e
    day=dt.date.fromisoformat(e['date'])
    if zone in ('UTC','Etc/UTC'): tz=UTC
    elif zone=='America/New_York':
        if day.year<2007: raise ValueError('美东历史时区规则未支持')
        march=dt.date(day.year,3,1); november=dt.date(day.year,11,1)
        dst_start=march+dt.timedelta(days=(6-march.weekday())%7+7)
        dst_end=november+dt.timedelta(days=(6-november.weekday())%7)
        # US clock-change days have ambiguous/missing local times. Refuse to guess.
        if (day==dst_start and 2<=hh<3) or (day==dst_end and 1<=hh<2):
            raise ValueError('美东夏令时切换时刻歧义')
        local=dt.datetime.combine(day,dt.time(hh,mm))
        daylight=dt.datetime.combine(dst_start,dt.time(3))<=local<dt.datetime.combine(dst_end,dt.time(2))
        tz=dt.timezone(dt.timedelta(hours=-4 if daylight else -5))
    else: raise ValueError('精确时刻的原始时区未支持')
    converted=dt.datetime.combine(day,dt.time(hh,mm),tzinfo=tz).astimezone(BJ)
    e.setdefault('details',{}).update(original_date=e['date'],original_time=value,original_timezone=zone)
    e.update(date=converted.date().isoformat(),time=converted.strftime('%H:%M'),timezone='Asia/Shanghai')
    return e

def safe_event(item):
    if not isinstance(item,dict): raise ValueError('事件不是对象')
    e=normalize_exact_event(item)
    if e.get('is_personal'):raise ValueError('金融来源不能写入个人日程')
    if not isinstance(e.get('id'),str) or not 1<=len(e['id'])<=300: raise ValueError('事件ID缺失')
    if not isinstance(e.get('title'),str) or not e['title'].strip(): raise ValueError('事件标题缺失')
    dt.date.fromisoformat(e['date'])
    if e.get('category') not in CATEGORIES: raise ValueError('未知分类')
    if e.get('status') not in ('confirmed','estimated'): raise ValueError('确认状态缺失')
    parsed=urlsplit(e.get('source_url',''))
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password: raise ValueError('证据链接不是HTTPS')
    if not isinstance(e.get('details',{}),dict): raise ValueError('详情不是对象')
    return e

class CalendarStore:
    def __init__(self, cache_dir, offline=False):
        self.cache=Path(cache_dir); self.cache.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock(); self.snapshots={}; self.pending=[]; self.running=False
        self.last_error=None; self.offline=offline; self.closed=False; self.last_request=time.monotonic()
        self.attempts={}; self.seed={}; self.interim={}; self.progress_range=None
        self._active_range=None;self._network_stop=threading.Event();self._network_thread=None
        self._macro_prefetch_attempts={};self._network_status={'enabled':not offline,'policy':'free_official','calendar_interval_seconds':900,'macro_recent_interval_seconds':120,'last_cycle_at':None,'queued_macro':0}
        self._projection_lock=threading.Lock()
        self._projection_cache={}; self._baseline_cache={}; self._watchlist_revision=0
        seed_path=ROOT/'seed_verified.json'
        if seed_path.exists():
            self.seed=json.loads(seed_path.read_text(encoding='utf-8'))
            self.seed['events']=[safe_event(x) for x in self.seed.get('events',[])]
        packaged=ROOT/'initial_snapshot.json'
        if packaged.exists() and packaged.stat().st_size<=MAX_CACHE:
            try:
                val=json.loads(packaged.read_text(encoding='utf-8'))
                a,b=period(val['range']['start'],val['range']['end'])
                val['events']=[safe_event(x) for x in val.get('events',[])]
                val['distribution_snapshot']=True
                for source in val.get('sources',[]):
                    if source.get('status')=='ok': source['status']='cached'
                    source['distribution_snapshot']=True
                    source['note']='发行包附带的真实联网快照，核实与获取时间保持原值；不代表当前已重新联网核实。'
                self.snapshots[month_key(a,b)]=val
            except (ValueError,KeyError,TypeError,OSError): pass
        for path in sorted(self.cache.glob('snapshot_*.json')):
            try:
                if path.stat().st_size>MAX_CACHE: continue
                val=json.loads(path.read_text(encoding='utf-8'))
                a,b=period(val['range']['start'],val['range']['end'])
                val['events']=[safe_event(x) for x in val.get('events',[])]
                packaged_prior=self.snapshots.get(month_key(a,b))
                if packaged_prior:
                    val=retain_failed_sources(val,packaged_prior,a,b)
                    known={source.get('id') for source in val.get('sources',[])}
                    added_sources={source.get('id'):copy.deepcopy(source) for source in packaged_prior.get('sources',[]) if source.get('id') not in known}
                    merged={e['id']:e for e in val['events']}
                    for event in packaged_prior.get('events',[]):
                        source_id=event_source(event,a,b)
                        if source_id in added_sources and event['id'] not in merged:
                            event=copy.deepcopy(event);event['data_stale']=True
                            event.setdefault('details',{})['刷新状态']='升级新增数据源，使用发行包原核实快照，等待本机联网更新'
                            merged[event['id']]=event
                    for source in added_sources.values():
                        if source.get('status')=='ok':source['status']='cached'
                    val['events']=list(merged.values());val.setdefault('sources',[]).extend(added_sources.values())
                self.snapshots[month_key(a,b)]=val
            except (ValueError,KeyError,TypeError,OSError):
                continue
        self.watchlist_file=self.cache/'watchlist.json'
        self.watchlist={"symbols":[],"fact_date":None,"note":"未设置本机持仓代码"}
        for file in [ROOT/'watchlist.default.json',self.watchlist_file]:
            try:
                if file.stat().st_size>32768:continue
                self.watchlist=self.validate_watchlist(json.loads(file.read_text(encoding='utf-8')))
            except (OSError,ValueError,TypeError,KeyError):continue
        self.quotes=QuoteService(self.cache/'quotes',self.collect_companies,self.seed.get('events',[]),self.offline)
        self.updates=UpdateManager(ROOT, VERSION)
        self.earnings=EarningsService(self.cache/'earnings',offline=self.offline)
        self.options=OptionsService(self.cache/'options',offline=self.offline)
        self.macro=MacroService(self.cache/'macro',offline=self.offline)
        self.economic=EconomicService(self.cache/'economic',offline=self.offline,news_client=_el_EquationClient())
        self.favorites=FavoritesStore(self.cache,app_root=ROOT)
        self.personal=PersonalCalendarStore(self.cache,app_root=ROOT)
    def validate_watchlist(self,data):
        if not isinstance(data,dict) or not isinstance(data.get('symbols'),list):raise ValueError('持仓代码格式无效')
        if len(data['symbols'])>100:raise ValueError('本机自选最多100项')
        symbols={}
        for item in data['symbols']:
            if not isinstance(item,dict):raise ValueError('持仓证券格式无效')
            market=item.get('market','A股');ticker=str(item.get('ticker','')).strip().upper()
            key=quote_key(market,ticker)
            market,ticker=key.split(':',1)
            symbol={'market':market,'ticker':ticker,'name':str(item.get('name',''))[:80]}
            if item.get('asset_type')=='fund':symbol['asset_type']='fund'
            symbols[key]=symbol
        fact=data.get('fact_date')
        if fact:dt.date.fromisoformat(fact)
        return {'symbols':list(symbols.values()),'fact_date':fact,'note':str(data.get('note') or '用户在本机维护的持仓/关注证券代码；不包含股数、成本或账户金额')[:300]}
    def set_watchlist(self,data):
        valid=self.validate_watchlist(data)
        with self.lock:
            atomic_json(self.watchlist_file,valid);self.watchlist=valid
            self._watchlist_revision+=1
        return copy.deepcopy(valid)
    def collect_companies(self):
        companies={}
        with self.lock:
            datasets=list(self.snapshots.values())+list(self.interim.values())
            watch=copy.deepcopy(self.watchlist.get('symbols',[]))
        for dataset in datasets:
            for event in dataset.get('events',[]):
                c=event.get('company')
                if not c or is_st(event) or event.get('category')=='ipo':continue
                ticker=str(c.get('ticker','')).replace('.HK','')
                if event.get('market')=='A股' and re.fullmatch(r'(?:200|900)\d{3}',ticker):continue
                if event.get('market')=='港股' and re.fullmatch(r'8\d{4}',ticker):continue
                company=dict(c,market=event.get('market'))
                try:companies[quote_key(company)]=company
                except ValueError:continue
        # Prioritize explicit user securities in the first batch; only public codes are sent.
        priority=[]
        for c in watch:
            if c.get('asset_type')=='fund':continue
            try:key=quote_key(c)
            except ValueError:continue
            priority.append(c);companies.pop(key,None)
        return priority+list(companies.values())
    def start_services(self):
        threading.Thread(target=prewarm,name="calendar-logo-cache",daemon=True).start()
        threading.Thread(target=self.personal.resume_reminders,name='personal-reminder-resume',daemon=True).start()
        self.quotes.start()
        if not self.offline:self.updates.start_background()
        threading.Thread(target=self.quotes.request,name='calendar-cap-start',daemon=True).start()
        if not self.offline and not self._network_thread:
            self._network_thread=threading.Thread(target=self._network_clock,name='calendar-public-data-clock',daemon=True);self._network_thread.start()
    def _network_clock(self):
        while not self.closed and not self._network_stop.is_set():
            try:self._network_tick()
            except Exception:
                with self.lock:self._network_status['last_error']='本轮后台取数未完成，将自动重试；已有数据保持原核实时间。'
            if self._network_stop.wait(60):break
    def _network_tick(self,now=None,ticks=None):
        if self.offline or self.closed:return 0
        now=(now or dt.datetime.now(BJ)).astimezone(BJ);ticks=time.monotonic()if ticks is None else ticks
        first=now.date().replace(day=1);next_month=(first.replace(day=28)+dt.timedelta(days=4)).replace(day=1)
        with self.lock:
            active=self._active_range or ((first-dt.timedelta(days=first.weekday())).isoformat(),(next_month+dt.timedelta(days=6)).isoformat())
            datasets=[self.seed]+list(self.snapshots.values())+list(self.interim.values())
            public={e['id']:e for d in datasets for e in d.get('events',[])if e.get('category')=='macro'and not e.get('is_personal')}
        self.request_refresh(*active);self.updates.start_background()
        normalized=normalize_events(list(public.values()))['events'];due=[]
        for event in normalized:
            instant=_ec_date(event.get('start_at'))
            if not instant or not 0<=(now-instant).total_seconds()<=172800:continue
            if not economic_kind(event)and not macro_supported(event):continue
            interval=120 if(now-instant).total_seconds()<7200 else 900
            if ticks-self._macro_prefetch_attempts.get(event['id'],-1e9)<interval:continue
            due.append(event)
        due.sort(key=lambda e:e['start_at'],reverse=True);queued=0
        for event in due[:2]:
            service=self.economic if economic_kind(event)else self.macro
            service.snapshot(event);self._macro_prefetch_attempts[event['id']]=ticks;queued+=1
        if len(self._macro_prefetch_attempts)>200:
            self._macro_prefetch_attempts=dict(sorted(self._macro_prefetch_attempts.items(),key=lambda p:p[1],reverse=True)[:200])
        with self.lock:self._network_status.update(last_cycle_at=now.isoformat(timespec='seconds'),queued_macro=queued,last_error=None)
        return queued
    def project(self,result,start,end,watchlist=None,quotes_snapshot=None):
        watchlist=self.watchlist if watchlist is None else watchlist
        result['sources']=[s for s in result.get('sources',[]) if s.get('id') not in ('a-marketcap','fed')]
        raw=[e for e in result.get('events',[]) if not is_st(e)]
        existing_terms={(e.get('date'),e.get('title'))for e in raw if e.get('category')=='season'}
        raw += [e for e in cultural_events(ROOT) if start<=e['date']<=end and (e.get('category')!='season' or (e['date'],e['title'])not in existing_terms)]
        timed=normalize_events(add_verified_ir_events(raw))
        if quotes_snapshot is None:_,quotes_snapshot=self.quotes.snapshot()
        self.quotes.decorate(timed['events'],quotes_snapshot);self.quotes.decorate(timed.get('pending',[]),quotes_snapshot)
        # Current quote names are a second ST exclusion guard against old report names.
        for e in timed['events']+timed.get('pending',[]):
            c=e.get('company') or {}
            if c.get('security_name') and e.get('market')=='A股':c['name']=c['security_name']
        selected=apply_policy(timed['events'],watchlist)
        pending_selected=apply_policy(timed.get('pending',[]),watchlist)
        selected['events']=[e for e in selected['events'] if start<=e['date']<=end]
        cultural_enrich(selected['events']);apply_branding(selected['events'])
        try:selected['events']=self.personal.apply(selected['events'],start,end)
        except (RuntimeError,OSError,ValueError):result['sources'].append({'id':'personal-calendar','name':'个人日历','status':'error','error':'个人日历暂时无法读取，原文件已保留；金融日历仍可查看。'})
        for e in selected['events']:e['data_quality']=evidence_quality(e)
        result['events']=selected['events']
        pending_items=pending_selected['events']+pending_selected['pending']+selected['pending']
        try:result['pending']=self.personal.apply(pending_items,start,end,include_personal=False)
        except (RuntimeError,OSError,ValueError):result['pending']=pending_items
        result['personal_revision']=self.personal.revision_token()
        result['filtered']=selected['filtered']
        result['filtered']['st_removed']+=sum(is_st(e) for e in result.get('_raw_events_for_count',[]))
        result['major_unlock_ratio']=selected['major_unlock_ratio']
        result['quotes_status']=self.quotes.status()
        result['watchlist_fact_date']=watchlist.get('fact_date')
        result['watchlist_note']=watchlist.get('note')
        result['timezone']='Asia/Shanghai';result['version']=VERSION
        return result
    def baseline(self,start,end):
        events=[copy.deepcopy(e) for e in self.seed.get('events',[]) if start<=e['date']<=end]
        return {'events':events,'sources':[{'id':'verified-baseline','name':'官方日程核验基线','status':'baseline','last_success':self.seed.get('checked_at'),'coverage':self.seed.get('coverage',[]),'error':None,'note':'已核实快照；联网源刷新状态单独列示，不代表全部日历已实时更新。'}], 'fetched_at':None,'coverage':self.seed.get('coverage',[]),'range':{'start':start,'end':end}}
    def request_refresh(self,start,end,force=False):
        key=month_key(start,end)
        with self.lock:
            if self.offline or self.closed: return False
            old=self.snapshots.get(key)
            recent=self.attempts.get(key,0)
            if not force and time.monotonic()-recent < 300: return False
            if not force and old:
                try:
                    checked=dt.datetime.fromisoformat(old['fetched_at'])
                    if (dt.datetime.now(UTC)-checked).total_seconds()<900: return False
                except (ValueError,KeyError,TypeError): pass
            if (start,end) in self.pending: return self.running
            self.attempts[key]=time.monotonic()
            if len(self.pending)>=3: self.pending.pop(0)
            self.pending.append((start,end))
            if not self.running:
                self.running=True
                threading.Thread(target=self._worker,name='calendar-refresh',daemon=True).start()
            return True
    def _progress(self,start,end):
        key=month_key(start,end)
        def update(payload):
            source=copy.deepcopy(payload)
            items=source.pop('events',[])
            clean=[]
            for item in items:
                try:
                    e=safe_event(item)
                    if start<=e['date']<=end:clean.append(e)
                except (ValueError,TypeError,KeyError):pass
            with self.lock:
                # Copy-on-publish: request threads may retain this snapshot while
                # building a projection; never change its dictionaries in place.
                current=dict(self.interim.get(key) or self.snapshots.get(key) or self.baseline(start,end))
                merged={e['id']:e for e in current['events']}
                # A fully parsed source replaces its own range, including removed events.
                source_name=source.get('name')
                if source.get('status') in ('ok','partial'):
                    source_ids={e.get('source_name') for e in clean}
                    if source.get('id')=='fed':
                        merged={i:e for i,e in merged.items() if 'fomccalendars.htm' not in e.get('source_url','')}
                    elif source_ids:
                        merged={i:e for i,e in merged.items() if e.get('source_name') not in source_ids}
                for e in clean:merged[e['id']]=e
                current['events']=list(merged.values())
                sources={x.get('id'):x for x in current.get('sources',[])}
                sources[source.get('id')]=source
                current['sources']=list(sources.values())
                self.interim[key]=current
                self.progress_range=key
        return update
    def _worker(self):
        while True:
            with self.lock:
                if not self.pending or self.closed:
                    self.running=False; self.progress_range=None; return
                start,end=self.pending.pop(0)
                key=month_key(start,end)
                self.interim[key]=dict(self.snapshots.get(key) or self.baseline(start,end))
                self.progress_range=key
            try:
                from providers import refresh_data
                with ThreadPoolExecutor(max_workers=5) as pool:
                    main_future=pool.submit(refresh_data,start,end,self.cache/'providers',self._progress(start,end))
                    extras=[]
                    for module_name,function_name,cache_name in [('additional_sources','refresh_additional','additional'),('hk_earnings','refresh_hk','hk'),('ipo','refresh_ipo','ipo'),('timing_policy','refresh_fomc','fomc_public')]:
                        try:
                            import importlib
                            function=getattr(importlib.import_module(module_name),function_name)
                            extras.append((cache_name,pool.submit(function,start,end,self.cache/cache_name)))
                        except ImportError:
                            pass
                    result=main_future.result()
                    for cache_name,future in extras:
                        try:
                            extra=future.result()
                            all_events={e['id']:e for e in result.get('events',[])}
                            all_events.update({e['id']:e for e in extra.get('events',[])})
                            result['events']=list(all_events.values())
                            if cache_name=='hk':
                                result['sources']=[x for x in result.get('sources',[]) if x.get('id')!='hk-earnings']
                            result.setdefault('sources',[]).extend(extra.get('sources',[]))
                        except Exception as exc:
                            result.setdefault('sources',[]).append({'id':cache_name,'name':cache_name,'status':'error','error':str(exc)[:300]})
                # Preserve only the failed A-earnings intervals from earlier evidence.
                # A partial refresh must not silently erase a previously observed list.
                with self.lock:
                    previous=self.snapshots.get(key) or {}
                a_source=next((x for x in result.get('sources',[]) if str(x.get('id','')).startswith('east-earnings-')),None)
                if a_source and a_source.get('status') in ('error','partial','cached'):
                    failed=[x for x in (a_source.get('intervals') or []) if x.get('status') in ('error','cached')]
                    if a_source.get('status') in ('error','cached') and not failed: failed=[{'start':start,'end':end}]
                    merged={e['id']:e for e in result.get('events',[])}
                    reused=0
                    for old in previous.get('events',[]):
                        if old.get('market')=='A股' and old.get('category')=='earnings' and old['id'] not in merged and any(x['start']<=old['date']<=x['end'] for x in failed):
                            old=copy.deepcopy(old); old['data_stale']=True
                            old.setdefault('details',{})['刷新状态']='该日期区间本次刷新失败，保留原快照；不是最新公告确认'
                            merged[old['id']]=old; reused+=1
                    result['events']=list(merged.values())
                    if reused: a_source['retained_stale_records']=reused
                result=retain_failed_sources(result,previous,start,end)
                clean=[]; rejected=[]
                for item in result.get('events',[]):
                    try:
                        e=safe_event(item)
                        if start<=e['date']<=end: clean.append(e)
                    except (ValueError,KeyError,TypeError) as exc: rejected.append(str(exc))
                if rejected:
                    result.setdefault('sources',[]).append({'id':'validation','name':'数据校验','status':'error','error':f'{len(rejected)}条记录未通过校验，已隔离；'+','.join(sorted(set(rejected)))})
                result['events']=sorted(clean,key=lambda e:(e['date'],str(e.get('time','')),e['id']))
                result['fetched_at']=result.get('fetched_at') or utcnow()
                result['coverage']=self.seed.get('coverage',[])
                result['range']={'start':start,'end':end}
                atomic_json(self.cache/('snapshot_'+key+'.json'),result)
                with self.lock:
                    self.snapshots[key]=result; self.last_error=None; self.interim.pop(key,None)
                self.quotes.request()
            except Exception as exc:
                with self.lock:
                    self.last_error='刷新未完成，保留缓存/官方基线：'+str(exc)[:300]
                    self.interim.pop(key,None)
    def _projection(self,start,end):
        """Memoize expensive normalization; no store lock covers that work.

        Published snapshots/quotes are immutable. Updates replace a snapshot or
        advance the quote/watchlist revision. Keeping the source reference with
        the cache entry also prevents object-id reuse from accepting stale data.
        """
        range_key=month_key(start,end)
        with self.lock:
            self.last_request=time.monotonic()
            raw=self.interim.get(range_key) or self.snapshots.get(range_key)
            if raw is None:
                if range_key not in self._baseline_cache:self._baseline_cache[range_key]=self.baseline(start,end)
                raw=self._baseline_cache[range_key]
                while len(self._baseline_cache)>4:self._baseline_cache.pop(next(iter(self._baseline_cache)))
            watchlist=self.watchlist;watch_revision=self._watchlist_revision
        quote_revision,quotes_snapshot=self.quotes.snapshot()
        try:branding_stamp=(ROOT/'branding'/'manifest.json').stat().st_mtime_ns
        except OSError:branding_stamp=None
        cache_key=(range_key,id(raw),quote_revision,watch_revision,branding_stamp,self.personal.revision_token())
        with self._projection_lock:
            cached=self._projection_cache.get(cache_key)
            if cached is not None:return cached['result']
            # project() replaces its result event/source lists and works on
            # normalized copies; the underlying provider snapshot stays untouched.
            result=dict(raw)
            result['_raw_events_for_count']=raw.get('events',[])
            result=self.project(result,start,end,watchlist,quotes_snapshot)
            result.pop('_raw_events_for_count',None)
            self._projection_cache[cache_key]={'source':raw,'result':result}
            while len(self._projection_cache)>3:self._projection_cache.pop(next(iter(self._projection_cache)))
            return result
    def query(self,start,end,refresh=True,*,shared=False):
        """Read a consistent projection. HTTP uses shared=True for serialization
        only; ordinary callers receive an isolated copy that they may mutate.
        """
        cached=self._projection(start,end)
        result=dict(cached) if shared else copy.deepcopy(cached)
        if refresh:
            with self.lock:self._active_range=(start,end)
            self.request_refresh(start,end)
        with self.lock:
            result.update(refreshing=self.running,last_error=self.last_error,offline=self.offline,version=VERSION)
            if self.last_error:
                result['sources']=list(result.get('sources',[]))+[{'id':'refresh-engine','name':'日程刷新服务','status':'error','error':self.last_error}]
        result['note']='主日历统一北京时间；精确时刻、已知宽时段、日期级安排分开。无法核实时间的条目进入待核。市值由程序自动更新。'
        result['quotes_status']=self.quotes.status()
        return result
    def export_favorites(self):
        """Resolve against existing local source evidence; never queue per-favorite network refreshes."""
        favorites=self.favorites.list()['items'];wanted={x['event_id'] for x in favorites};raw={}
        with self.lock:
            datasets=[self.seed]+sorted(self.snapshots.values(),key=lambda x:x.get('fetched_at')or'')+list(self.interim.values())
            for dataset in datasets:
                for event in dataset.get('events',[]):
                    if event.get('id')in wanted:raw[event['id']]=copy.deepcopy(event)
        timed=normalize_events(add_verified_ir_events(list(raw.values())))
        resolved={e['id']:e for e in apply_policy(timed['events'],self.watchlist)['events']if e.get('id')in wanted}
        for record in self.personal.records():
            if record['id']in wanted:resolved[record['id']]=personal_event(record)
        kept=self.personal.apply(list(resolved.values()),'1970-01-01','2100-12-31',include_personal=False);resolved={e['id']:e for e in kept}
        events=[]
        for item in favorites:
            event=resolved.get(item['event_id'])
            if event is None:
                events.append({'id':item['event_id'],'title':item['title'],'status':'estimated','data_stale':True});continue
            event=copy.deepcopy(event)
            if item.get('reminder'):event['reminder']=item['reminder']
            events.append(event)
        return events

    def status(self):
        with self.lock:
            values=list(self.snapshots.values())
            latest=(self.interim.get(self.progress_range) if self.progress_range else None) or max(values,key=lambda x:x.get('fetched_at') or '',default={})
            return {'refreshing':self.running,'fetched_at':latest.get('fetched_at'),'sources':copy.deepcopy(latest.get('sources',[])), 'last_error':self.last_error,'offline':self.offline,'version':VERSION,'pending':len(self.pending),'quotes_status':self.quotes.status(),'data_refresh':copy.deepcopy(self._network_status)}

def ics_escape(value):
    return str(value).replace('\\','\\\\').replace('\r\n','\n').replace('\r','\n').replace('\n','\\n').replace(';','\\;').replace(',','\\,')

def fold_ics(line):
    out=[]; current=''; size=0
    for ch in line:
        n=len(ch.encode('utf-8'))
        if size+n>75:
            out.append(current); current=' '+ch; size=1+n
        else: current+=ch; size+=n
    out.append(current)
    return '\r\n'.join(out)

def make_ics(events):
    lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Willance//Event Calendar V1//ZH','CALSCALE:GREGORIAN','METHOD:PUBLISH','X-WR-CALNAME:时序投资事件日历','X-WR-TIMEZONE:Asia/Shanghai']
    stamp=dt.datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')
    seen=set()
    for raw in events:
        try: e=safe_event(raw)
        except (ValueError,KeyError,TypeError): continue
        if e['status']!='confirmed' or e.get('data_stale') or e['id'] in seen: continue
        seen.add(e['id'])
        uid=hashlib.sha256(e['id'].encode()).hexdigest()+'@willance-event-calendar'
        day=dt.date.fromisoformat(e['date'])
        event_lines=['BEGIN:VEVENT','UID:'+uid,'DTSTAMP:'+stamp]
        if e.get('start_at'):
            try:
                instant=dt.datetime.fromisoformat(e['start_at'])
                if instant.tzinfo is None:raise ValueError('缺少偏移')
                event_lines+=['DTSTART:'+instant.astimezone(UTC).strftime('%Y%m%dT%H%M%SZ')]
                if e.get('end_at'):
                    finish=dt.datetime.fromisoformat(e['end_at'])
                    event_lines+=['DTEND:'+finish.astimezone(UTC).strftime('%Y%m%dT%H%M%SZ')]
            except (ValueError,TypeError):continue
        elif re.fullmatch(r'\d{2}:\d{2}',str(e.get('time',''))):
            hh,mm=map(int,e['time'].split(':'))
            instant=dt.datetime(day.year,day.month,day.day,hh,mm,tzinfo=BJ)
            event_lines+=['DTSTART:'+instant.astimezone(UTC).strftime('%Y%m%dT%H%M%SZ')]
        else:continue
        detail='\n'.join(str(k)+'：'+(json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v)) for k,v in e.get('details',{}).items())
        desc='来源：'+e.get('source_name','')+'\n核实时间：'+str(e.get('source_checked_at','未提供'))+'\n'+detail+'\n'+e['source_url']
        event_lines+=['SUMMARY:'+ics_escape(e['title']),'DESCRIPTION:'+ics_escape(desc),'URL:'+e['source_url'],'STATUS:CONFIRMED','END:VEVENT']
        lines.extend(event_lines)
    lines+=['END:VCALENDAR']
    return ('\r\n'.join(fold_ics(x) for x in lines)+'\r\n').encode('utf-8')

# BEGIN SLIM API (mirrors slim_api.py)
"""Bounded calendar views over the complete, immutable local data projection.

The browser receives only calendar summaries and the selected page. Company
records and source details stay on the local server until explicitly requested.
No source facts are deleted or inferred to make a response smaller.
"""

from collections import OrderedDict, defaultdict
import copy
import datetime as dt
import hashlib
import json
import math
import threading
import uuid
import unicodedata

from selection_policy import is_st, option_expiry_focus, OPTIONS_FOCUS_NOTE, event_importance

_SLIM_CATEGORIES = frozenset(('ipo', 'season', 'crypto', 'options', 'macro', 'earnings', 'holiday', 'politics', 'unlock', 'astronomy', 'personal'))
_SLIM_MARKETS = ('美股', 'A股', '港股')
_SLIM_BJ = dt.timezone(dt.timedelta(hours=8))
_SLIM_EMPTY = ()
_SLIM_MONTH_ENTRY_LIMIT = 6
_SLIM_MAX_PAGE_SIZE = 30
_SLIM_DETAIL_BYTES_LIMIT = 100_000


class SlimAPIError(ValueError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _slim_one(qs: dict, name: str, default=None):
    value = qs.get(name, default)
    if isinstance(value, (tuple, list)):
        if len(value) != 1:
            raise SlimAPIError('参数不能重复：' + name)
        value = value[0]
    return value


def _slim_date(value, label='日期') -> str:
    if not isinstance(value, str) or len(value) != 10:
        raise SlimAPIError(label + '须为YYYY-MM-DD')
    try:
        parsed = dt.date.fromisoformat(value)
    except (ValueError, TypeError):
        raise SlimAPIError(label + '无效') from None
    if parsed.isoformat() != value:
        raise SlimAPIError(label + '须为YYYY-MM-DD')
    return value


def _slim_period(qs):
    now = dt.datetime.now(_SLIM_BJ).date()
    start = _slim_date(_slim_one(qs, 'start', now.replace(day=1).isoformat()), '起始日期')
    first = dt.date.fromisoformat(start)
    following = (first.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
    end = _slim_date(_slim_one(qs, 'end', (following-dt.timedelta(days=1)).isoformat()), '结束日期')
    distance = (dt.date.fromisoformat(end)-first).days
    if distance < 0 or distance > 62:
        raise SlimAPIError('日期范围须为1至63天')
    return start, end


def _slim_filters(qs):
    market = _slim_one(qs, 'market', 'all')
    if market not in ('all', 'A股', '美股', '港股', '币圈', '个人'):
        raise SlimAPIError('市场筛选无效')
    raw = _slim_one(qs, 'categories')
    if raw is None:
        categories = _SLIM_CATEGORIES
    elif not isinstance(raw, str) or len(raw) > 200:
        raise SlimAPIError('类别筛选无效')
    else:
        categories = frozenset(x.strip() for x in raw.split(',') if x.strip())
        if not categories <= _SLIM_CATEGORIES:
            raise SlimAPIError('类别筛选包含未知类别')
    search = _slim_one(qs, 'q', '')
    if not isinstance(search, str) or len(search) > 200:
        raise SlimAPIError('搜索词最多200字符')
    holding = _slim_one(qs, 'holding', '0')
    if holding not in ('0', '1'):
        raise SlimAPIError('持仓筛选须为0或1')
    options_scope = _slim_one(qs, 'options_scope', 'important')
    if options_scope not in ('important', 'all'):
        raise SlimAPIError('期权筛选须为important或all')
    return market, tuple(sorted(categories)), unicodedata.normalize('NFKC',search).strip().casefold(), holding == '1', options_scope


def _slim_pagination(qs):
    try:
        raw_page = _slim_one(qs, 'page', '0')
        raw_limit = _slim_one(qs, 'limit', '20')
        page, limit = int(raw_page), int(raw_limit)
        if str(page) != str(raw_page) or str(limit) != str(raw_limit):
            raise ValueError()
        if page < 0 or page > 1_000_000 or not 1 <= limit <= _SLIM_MAX_PAGE_SIZE:
            raise ValueError()
    except (ValueError, TypeError):
        raise SlimAPIError('分页参数无效；每页最多30条') from None
    return page, limit


def _slim_page(items, requested: int, limit: int):
    total = len(items)
    pages = max(1, (total+limit-1)//limit)
    number = min(requested, pages-1)
    return items[number*limit:(number+1)*limit], {'page': number, 'pages': pages, 'limit': limit, 'total': total, 'has_more': number+1 < pages}


def _slim_number(value):
    if value is None or value == '':
        return None
    try:
        number = float(value)
        return number if math.isfinite(number) and number > 0 else None
    except (ValueError, TypeError):
        return None


def _slim_priority(event):
    category = event.get('category')
    if category=='personal':return -1
    if category in ('season','astronomy'): return 0
    if category == 'ipo': return 1
    if category in ('crypto', 'options'): return 2
    if category in ('macro', 'politics', 'holiday'): return 3
    if category == 'earnings':
        market = event.get('market')
        return 4 + (_SLIM_MARKETS.index(market) if market in _SLIM_MARKETS else 3)
    return 8


def _slim_event_order(event):
    return (_slim_priority(event), -bool(event.get('is_holding')), -int(event.get('importance')=='high'), str(event.get('start_at') or event.get('time') or '99:99'), str(event.get('id')))


def _slim_market_match(event, market):
    candidate = event.get('market')
    return (market == 'all' or candidate == market
            or market == 'A股' and candidate == '中国'
            or market == '美股' and candidate == '美国'
            or market == '币圈' and candidate in ('加密', '加密资产'))


def _slim_search_text(event):
    company = event.get('company') or {}
    return unicodedata.normalize('NFKC','\n'.join(str(x or '') for x in (event.get('title'), company.get('name'), company.get('ticker')))).casefold()


def _slim_matches(event, filters, search_cache):
    market, categories, search, holding = filters[:4]
    if event.get('category') not in categories or not _slim_market_match(event, market) or holding and not event.get('is_holding'):
        return False
    if search:
        key = id(event)
        if key not in search_cache:
            search_cache[key] = _slim_search_text(event)
        if search not in search_cache[key]:
            return False
    return True


def _slim_limited_text(value, limit):
    return value[:limit] if isinstance(value, str) else value


_SLIM_EVENT_FIELDS = ('id', 'date', 'title', 'category', 'market', 'is_holding', 'status', 'time', 'time_display', 'start_at', 'end_at', 'timezone', 'time_precision', 'source_name', 'data_stale', 'event_type', 'ipo_kind', 'expiry_tier', 'expiry_label', 'expiry_note', 'importance', 'importance_label', 'importance_reason', 'is_personal', 'all_day', 'data_quality')
_SLIM_COMPANY_FIELDS = ('ticker', 'name', 'currency', 'market_cap', 'cap_asof', 'cap_source_checked_at', 'cap_stale', 'logo_url')


def _slim_compact(event, *, logo_only=False):
    keys = ('id', 'date', 'category', 'market', 'is_holding', 'title', 'event_type') if logo_only else _SLIM_EVENT_FIELDS
    result = {key: _slim_limited_text(event[key], 240 if key in ('title', 'time_display') else 400) for key in keys if key in event}
    if isinstance(event.get('title'), str) and len(event['title']) > 240:
        result['title_truncated'] = True
    company = event.get('company')
    if isinstance(company, dict):
        company_fields = ('ticker', 'name', 'logo_url') if logo_only else _SLIM_COMPANY_FIELDS
        result['company'] = {key: _slim_limited_text(company[key], 160) for key in company_fields if key in company}
    return result


def _slim_logos(items, limit):
    found, result = set(), []
    for event in items:
        company = event.get('company') or {}
        key = str(company.get('name') or company.get('ticker') or event.get('id')).strip().casefold()
        if key in found:
            continue
        found.add(key)
        result.append(_slim_compact(event, logo_only=True))
        if len(result) == limit:
            break
    return result


def _slim_company_sort(items):
    currencies = {str((item.get('company') or {}).get('currency') or '') for item in items if _slim_number((item.get('company') or {}).get('market_cap')) is not None}
    mixed = len(currencies) > 1
    def order(event):
        company = event.get('company') or {}
        cap = _slim_number(company.get('market_cap'))
        return (-bool(event.get('is_holding')), cap is None, str(company.get('currency') or '') if mixed else '', -(cap or 0), str(event.get('title') or ''), str(event.get('id')))
    return sorted(items, key=order), mixed


def _slim_grouped_entries(events):
    earnings, unlocks = defaultdict(list), defaultdict(list)
    for event in events:
        if event.get('category') == 'earnings':
            earnings[event.get('market') or '其他市场'].append(event)
        elif event.get('category') == 'unlock':
            unlocks[event.get('market') or 'A股'].append(event)
    result = []
    for event in events:
        category = event.get('category')
        if category == 'earnings' or category == 'unlock' and len(unlocks[event.get('market') or 'A股']) > 1:
            continue
        result.append({'id': str(event['id']), 'title': event['title'], 'category': category, 'is_holding': bool(event.get('is_holding')), 'event': event})
    for market, items in earnings.items():
        ordered, mixed = _slim_company_sort(items)
        result.append({'id': 'group:' + market, 'title': market + '财报 · ' + str(len(items)) + '条', 'category': 'earnings', 'is_holding': any(event.get('is_holding') for event in items), 'group': {'market': market, 'items': ordered, 'mixed': mixed}})
    for market, items in unlocks.items():
        if len(items) > 1:
            result.append({'id': 'unlockgroup:' + market, 'title': market + '重大解禁 · ' + str(len(items)) + '条', 'category': 'unlock', 'is_holding': any(event.get('is_holding') for event in items), 'group': {'market': market, 'items': sorted(items, key=_slim_event_order), 'mixed': False}})
    def order(entry):
        event = entry.get('event') or {'category': entry['category'], 'market': entry['group']['market']}
        return (_slim_priority(event), -entry['is_holding'], str(event.get('start_at') or event.get('time') or '99:99'), entry['title'])
    return sorted(result, key=order)


def _slim_entry(entry, mode):
    result = {key: _slim_limited_text(entry[key], 240) for key in ('id', 'title', 'category', 'is_holding')}
    if 'event' in entry:
        result['event'] = _slim_compact(entry['event'])
        if mode == 'month' and 'company' in result['event']:
            result['event']['company'] = {key: value for key, value in result['event']['company'].items() if key in ('ticker', 'name', 'logo_url')}
    else:
        group = entry['group']
        items = group['items']
        result['group'] = {'market': group['market'], 'count': len(items), 'total': len(items), 'mixed': group['mixed'], 'items': _slim_logos(items, 3) if mode == 'month' else [_slim_compact(event) for event in items[:5]]}
        if mode == 'day':
            result['group']['logos'] = _slim_logos(items, 5)
    return result


class _SlimDataset:
    def __init__(self, events, pending, revision):
        self.source_events = events
        self.source_pending = pending
        annotated = []
        for event in events:
            if is_st(event):
                continue
            focus = option_expiry_focus(event)
            # Preserve the store's immutable projection; only option records
            # need a shallow copy for derived display metadata.
            annotated.append({**event, **event_importance(event), **(focus or {})})
        self.events = tuple(annotated)
        self.pending = tuple(event for event in pending if not is_st(event))
        self.by_id = {str(event['id']): event for event in self.events}
        self.holdings = defaultdict(int)
        for event in self.events:
            if event.get('is_holding'):
                self.holdings[event['date']] += 1
        self.revision = revision
        self.search = {}
        self.selections = OrderedDict()

    def selection(self, filters):
        if filters in self.selections:
            return self.selections[filters]
        candidates = (event for event in self.events if _slim_matches(event, filters, self.search))
        events, seen_expiries, hidden_options = [], set(), 0
        for event in candidates:
            tier = event.get('expiry_tier')
            if filters[4] == 'important' and tier in ('daily', 'weekly', 'unverified'):
                hidden_options += 1
                continue
            if filters[4] == 'important' and tier in ('monthly', 'quarterly'):
                key = (event['expiry_venue'], event['expiry_asset'], event['expiry_at_utc'])
                if key in seen_expiries:
                    hidden_options += 1
                    continue
                seen_expiries.add(key)
            events.append(event)
        events = tuple(events)
        days = defaultdict(list)
        for event in events:
            for date in (event.get('span_dates')if event.get('is_personal')else None)or[event['date']]:days[date].append(event)
        entries = {date: _slim_grouped_entries(sorted(items, key=_slim_event_order)) for date, items in days.items()}
        result = {'events': events, 'days': days, 'entries': entries, 'hidden_options_count': hidden_options}
        self.selections[filters] = result
        while len(self.selections) > 4:
            self.selections.popitem(last=False)
        return result


def _slim_compact_sources(sources):
    result = []
    for source in sources:
        entry = {key: _slim_limited_text(source[key], 1000) for key in ('id', 'name', 'status', 'error', 'source_url', 'url', 'last_success', 'checked_at', 'source_checked_at', 'note') if key in source}
        coverage = source.get('coverage')
        if isinstance(coverage, str):
            entry['coverage'] = coverage[:2000]
            if len(coverage) > 2000: entry['coverage_truncated'] = True
        elif isinstance(coverage, list):
            # Coverage is descriptive metadata; detailed per-source intervals
            # remain accessible from the existing source-status endpoint.
            encoded = json.dumps(coverage, ensure_ascii=False, separators=(',', ':'))
            if len(encoded.encode('utf-8')) <= 5000:
                entry['coverage'] = coverage
            else:
                entry['coverage'] = '完整来源范围请在数据与来源中查看'
                entry['coverage_truncated'] = True
        result.append(entry)
    return result


class SlimCalendarAPI:
    """Query bounded views. The returned objects are safe for caller mutation."""
    paths = frozenset(('/api/calendar', '/api/day', '/api/group', '/api/event', '/api/pending', '/api/search'))

    def __init__(self, store):
        self.store = store
        self._lock = threading.RLock()
        self._datasets = OrderedDict()
        self._session = uuid.uuid4().hex[:12]
        self._serial = 0
        self.stats = {'dataset_builds': 0, 'selection_builds': 0}

    def _load(self, qs):
        start, end = _slim_period(qs)
        payload = self.store.query(start, end, shared=True)
        events = payload.get('events', _SLIM_EMPTY)
        pending = payload.get('pending', _SLIM_EMPTY)
        key = (start, end, id(events), id(pending))
        with self._lock:
            dataset = self._datasets.get(key)
            if dataset is None:
                self._serial += 1
                dataset = _SlimDataset(events, pending, self._session + ':' + str(self._serial))
                self._datasets[key] = dataset
                self.stats['dataset_builds'] += 1
                while len(self._datasets) > 2:
                    self._datasets.popitem(last=False)
        return start, end, dataset, payload

    def _meta(self, payload, dataset, filters, start, end):
        filter_digest = hashlib.sha256(json.dumps(filters, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()[:12]
        result = {key: payload[key] for key in ('fetched_at', 'refreshing', 'version', 'quotes_status', 'watchlist_fact_date', 'watchlist_note', 'coverage', 'last_error', 'offline', 'filtered', 'major_unlock_ratio', 'timezone') if key in payload}
        result.update(range={'start': start, 'end': end}, revision=dataset.revision + ':' + filter_digest, dataset_revision=dataset.revision, main_count=len(dataset.events), pending_count=len(dataset.pending), holdings_by_day=dict(dataset.holdings), sources=_slim_compact_sources(payload.get('sources', [])))
        result.update(options_scope=filters[4], options_filter_note=OPTIONS_FOCUS_NOTE)
        return result

    def query(self, path, qs):
        if path not in self.paths:
            raise SlimAPIError('未找到', 404)
        if not isinstance(qs, dict):
            raise SlimAPIError('参数格式无效')
        filters = _slim_filters(qs)
        start, end, dataset, payload = self._load(qs)
        meta = self._meta(payload, dataset, filters, start, end)
        if path == '/api/event':
            identifier = _slim_one(qs, 'id')
            if not isinstance(identifier, str) or not 1 <= len(identifier) <= 300:
                raise SlimAPIError('事件ID无效')
            event = dataset.by_id.get(identifier)
            if event is None:
                raise SlimAPIError('该事件不在当前已核实主日历中', 404)
            encoded = json.dumps(event, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            if len(encoded.encode()) > _SLIM_DETAIL_BYTES_LIMIT:
                raise SlimAPIError('该事件详情过大，请通过原始来源查看完整正文', 413)
            return {'event': copy.deepcopy(event), 'revision': meta['revision'], 'dataset_revision': dataset.revision}
        if path == '/api/pending':
            requested, limit = _slim_pagination(qs)
            with self._lock:
                items = [event for event in dataset.pending if _slim_matches(event, filters, dataset.search)]
            page, paging = _slim_page(items, requested, limit)
            rows = []
            for event in page:
                row = _slim_compact(event)
                row.update({key: _slim_limited_text(event[key], 1200) for key in ('pending_reason', 'reason', 'source_url', 'source_checked_at', 'original_date') if key in event})
                original = (event.get('details') or {}).get('original_date')
                if original and 'original_date' not in row: row['original_date'] = original
                rows.append(row)
            return {'items': rows, **paging, 'revision': meta['revision'], 'dataset_revision': dataset.revision}
        with self._lock:
            fresh_selection = filters not in dataset.selections
            selected = dataset.selection(filters)
            self.stats['selection_builds'] += int(fresh_selection)
        if path == '/api/search':
            requested,limit=_slim_pagination(qs)
            items=sorted(selected['events'],key=lambda e:(e['date'],_slim_event_order(e)))
            page,paging=_slim_page(items,requested,limit)
            return {'items':[_slim_compact(e) for e in page],**paging,'query':filters[2],'range':{'start':start,'end':end},'revision':meta['revision'],'dataset_revision':dataset.revision}
        if path == '/api/calendar':
            days = []
            date = dt.date.fromisoformat(start)
            while date.isoformat() <= end:
                key = date.isoformat()
                items = selected['days'].get(key, _SLIM_EMPTY)
                entries = selected['entries'].get(key, _SLIM_EMPTY)
                days.append({'date': key, 'count': len(items), 'important_count':sum(e.get('importance')=='high' for e in items), 'holding_count': sum(bool(event.get('is_holding')) for event in items), 'entry_count': len(entries), 'more_entry_count': max(0, len(entries)-_SLIM_MONTH_ENTRY_LIMIT), 'entries': [_slim_entry(entry, 'month') for entry in entries[:_SLIM_MONTH_ENTRY_LIMIT]]})
                date += dt.timedelta(days=1)
            result = {**meta, 'total_count': len(selected['events']), 'hidden_options_count': selected['hidden_options_count'], 'days': days}
            return copy.deepcopy(result)
        date = _slim_date(_slim_one(qs, 'date'))
        if not start <= date <= end:
            raise SlimAPIError('所选日期不在当前范围内')
        requested, limit = _slim_pagination(qs)
        entries = selected['entries'].get(date, _SLIM_EMPTY)
        if path == '/api/day':
            page, paging = _slim_page(entries, requested, limit)
            items = selected['days'].get(date, _SLIM_EMPTY)
            return {'date': date, 'count': len(items), 'holding_count': sum(bool(event.get('is_holding')) for event in items), 'holding_global_count': dataset.holdings.get(date, 0), 'entry_count': len(entries), 'entries': [_slim_entry(entry, 'day') for entry in page], **paging, 'revision': meta['revision'], 'dataset_revision': dataset.revision}
        kind = _slim_one(qs, 'kind', 'earnings')
        market = _slim_one(qs, 'group_market')
        if kind not in ('earnings', 'unlock') or not isinstance(market, str) or not 1 <= len(market) <= 40:
            raise SlimAPIError('分组参数无效')
        # A single unlock is not collapsed into an entry, but the paged endpoint
        # remains valid for it so clients do not need a special-case protocol.
        if kind == 'earnings':
            group = next((entry['group'] for entry in entries if entry['category'] == kind and entry.get('group', {}).get('market') == market), None)
            items = group['items'] if group else _SLIM_EMPTY
        else:
            items = sorted((event for event in selected['days'].get(date, _SLIM_EMPTY) if event.get('category') == 'unlock' and (event.get('market') or 'A股') == market), key=_slim_event_order)
        page, paging = _slim_page(items, requested, limit)
        return {'kind': kind, 'date': date, 'market': market, 'count': len(items), 'items': [_slim_compact(event) for event in page], **paging, 'revision': meta['revision'], 'dataset_revision': dataset.revision}

# END SLIM API

# BEGIN EARNINGS LIVE (mirrors earnings_live.py)
"""On-demand, source-attributed earnings cards. Python stdlib; no global polling.

This module is also inlined into app.py for compatibility with installed updaters.
Public issuer queries go only to EquationNews' documented fixed public endpoints.
"""

import collections as _el_collections
import copy as _el_copy
import datetime as _el_dt
import email.utils as _el_email
import hashlib as _el_hashlib
import html as _el_html
import json as _el_json
from pathlib import Path as _el_Path
import re as _el_re
import threading as _el_threading
import time as _el_time
import urllib.error as _el_urlerror
import urllib.parse as _el_urlparse
import urllib.request as _el_urlrequest
import xml.etree.ElementTree as _el_ET
from concurrent.futures import ThreadPoolExecutor as _el_ThreadPoolExecutor

_EL_UTC = _el_dt.timezone.utc
_EL_BJ = _el_dt.timezone(_el_dt.timedelta(hours=8))
_EL_TTL = 60
_EL_MAX = 100
_EL_BODY_MAX = 1_000_000
_EL_MCP = 'https://api.eqn.news/public/mcp'
_EL_RSS = 'https://api.eqn.news/public/rss?ch=tradfi&lang=zh'
_EL_ALIASES = {
    'MSFT': ['Microsoft', '微软'], 'GOOGL': ['Alphabet', 'Google', '谷歌'],
    'GOOG': ['Alphabet', 'Google', '谷歌'], 'AAPL': ['Apple', '苹果'],
    'AMZN': ['Amazon', '亚马逊'], 'META': ['Meta Platforms', 'Meta', '脸书'],
    'NVDA': ['Nvidia', '英伟达'], 'TSLA': ['Tesla', '特斯拉'],
    'AMD': ['Advanced Micro Devices', 'AMD', '超微半导体'],
    'AVGO': ['Broadcom', '博通'], 'TSM': ['Taiwan Semiconductor', '台积电'],
}
_EL_FOCUS = {
    'MSFT': ['Azure与云业务增长及下一季指引', 'AI投入、资本开支与自由现金流', '调整后EPS与市场预期的同口径比较'],
    'GOOGL': ['搜索广告与YouTube广告增长', 'Google Cloud增长及营业利润', 'AI资本开支与自由现金流'],
    'GOOG': ['搜索广告与YouTube广告增长', 'Google Cloud增长及营业利润', 'AI资本开支与自由现金流'],
    'NVDA': ['数据中心收入及下一季收入指引', '毛利率与产品交付节奏', '资本投入、客户集中度及出口限制披露'],
    'AAPL': ['iPhone收入与地区表现', '服务业务增长和毛利率', '下一季需求、库存及管理层指引'],
    'AMZN': ['AWS收入增长与利润率', '零售业务利润率', '资本开支与自由现金流'],
    'META': ['广告收入、展示量及单价', '资本开支与费用指引', '自由现金流与AI业务变现'],
}


def _el_now():
    return _el_dt.datetime.now(_EL_UTC).isoformat(timespec='seconds')


def _el_url(value):
    if not isinstance(value, str) or len(value) > 2048:
        return None
    try:
        parsed = _el_urlparse.urlsplit(value)
        return value if parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password else None
    except ValueError:
        return None


def _el_date(value):
    if not isinstance(value, str):
        return None
    try:
        parsed = _el_dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed.replace(tzinfo=_EL_UTC) if parsed.tzinfo is None else parsed
    except ValueError:
        try:
            return _el_email.parsedate_to_datetime(value)
        except (TypeError, ValueError):
            return None


def _el_period(event):
    details = event.get('details') or {}
    return str(details.get('报告期') or details.get('period') or event.get('report_period') or '来源未提供报告期')[:100]


def _el_quarter(event):
    """Known fiscal calendars, or an explicit period; never assume calendar Q3=MSFT Q3."""
    company = event.get('company') or {}
    text = str(event.get('title', '')) + ' ' + _el_period(event)
    m = _el_re.search(r'(?:FY\s*(\d{4})\s*)?Q([1-4])(?!\d)', text, _el_re.I)
    if m:
        return int(m.group(2)), int(m.group(1)) if m.group(1) else None
    raw = _el_period(event)
    match = _el_re.search(r'(20\d{2})-(\d{2})', raw)
    if match:
        year, month = map(int, match.groups())
    else:
        match = _el_re.search(r'([A-Za-z]{3})/(20\d{2})', raw)
        if not match:
            return None, None
        try:
            month = _el_dt.datetime.strptime(match.group(1), '%b').month
            year = int(match.group(2))
        except ValueError:
            return None, None
    ticker = str(company.get('ticker', '')).upper()
    fiscal_ends = {'MSFT': 6, 'AAPL': 9, 'NVDA': 1}
    if ticker in fiscal_ends:
        end = fiscal_ends[ticker]
        quarter = ((month - end - 1) % 12) // 3 + 1
        return quarter, year + int(month > end)
    if ticker in {'GOOG', 'GOOGL', 'AMZN', 'META', 'TSLA', 'AMD'} or event.get('market') == 'A股':
        return (month - 1) // 3 + 1, year
    return None, None


def _el_issuer_matches(text, event):
    company = event.get('company') or {}
    ticker = str(company.get('ticker') or '').upper()
    aliases = list(_EL_ALIASES.get(ticker, []))
    name = str(company.get('name') or '').strip()
    name = _el_re.sub(r'\b(?:incorporated|inc|corporation|corp|limited|ltd|plc)\.?$', '', name, flags=_el_re.I).strip(' ,.')
    if len(name) >= 4:
        aliases.append(name)
    for alias in aliases:
        if _el_re.search(r'[\u3400-\u9fff]', alias):
            if len(alias) >= 2 and alias in text:
                return True
        elif _el_re.search(r'(?<![A-Za-z0-9])' + _el_re.escape(alias) + r'(?![A-Za-z0-9])', text, _el_re.I):
            return True
    # Short/common symbols must carry an explicit cashtag or exchange prefix.
    if ticker and _el_re.search(r'(?:\$|NASDAQ:|NYSE:)' + _el_re.escape(ticker) + r'(?![A-Z0-9])', text, _el_re.I):
        return True
    return bool(len(ticker) >= 4 and _el_re.search(r'(?<![A-Za-z0-9])' + _el_re.escape(ticker) + r'(?![A-Za-z0-9])', text))


def _el_story_matches(story, event):
    text = str(story.get('zh') or '') + '\n' + str(story.get('en') or '')
    if not _el_issuer_matches(text, event):
        return False
    published = _el_date(story.get('time'))
    try:
        event_day = _el_dt.date.fromisoformat(event['date'])
    except (ValueError, KeyError, TypeError):
        return False
    if not published or published > _el_date(_el_now()) + _el_dt.timedelta(minutes=5) or not -7 <= (published.astimezone(_EL_BJ).date() - event_day).days <= 3:
        return False
    quarter, fiscal_year = _el_quarter(event)
    explicit_quarters = set()
    for a, b in _el_re.findall(r'(?<![A-Za-z])(?:Q([1-4])(?!\d)|([1-4])Q(?![A-Za-z]))', text, _el_re.I):
        explicit_quarters.add(int(a or b))
    for word in _el_re.findall(r'第([一二三四1234])季度', text):
        explicit_quarters.add({'一': 1, '二': 2, '三': 3, '四': 4}.get(word, int(word) if word.isdigit() else 0))
    if quarter and explicit_quarters and quarter not in explicit_quarters:
        return False
    years = set(map(int, _el_re.findall(r'(?<![A-Za-z0-9])FY\s*(20\d{2})(?!\d)', text, _el_re.I)))
    years.update(map(int,_el_re.findall(r'(20\d{2})财年',text)))
    if fiscal_year and (event.get('company') or {}).get('ticker','').upper() not in ('MSFT','AAPL','NVDA'):
        years.update(map(int,_el_re.findall(r'(20\d{2})年(?:第)?[一二三四1234]季度',text)))
    if fiscal_year and years and fiscal_year not in years:
        return False
    return True


def _el_base(event):
    company = event.get('company') or {}
    details = event.get('details') or {}
    ticker = str(company.get('ticker') or '').upper()[:30]
    forecast = details.get('EPS预测')
    expectations = []
    if isinstance(forecast, (str, int, float)) and _el_re.fullmatch(r'\s*\(?-?\$?\d[\d,]*(?:\.\d+)?\)?\s*', str(forecast)):
        expectations.append({'key': 'eps', 'label': 'EPS预期', 'value': str(forecast), 'unit': company.get('currency') or '', 'basis': '日历源未注明GAAP口径，不与调整后EPS混比', 'source_url': _el_url(event.get('source_url')), 'asof': event.get('source_checked_at'), 'sample_size': details.get('一致预期样本数')})
    label = event.get('time_display') or event.get('time') or details.get('发布时段') or '公司未公布精确时刻'
    result = {'schema': 1, 'status': 'partial', 'issuer': {'ticker': ticker, 'name': str(company.get('name') or event.get('title') or '')[:150]},
              'report_period': _el_period(event), 'schedule': {'label': str(label)[:300], 'start_at': event.get('start_at'), 'end_at': event.get('end_at'), 'precision': event.get('time_precision') or 'date_only', 'status': event.get('status') or 'estimated', 'source_url': _el_url(event.get('source_url'))},
              'expectations': expectations, 'actuals': [], 'focus_points': list(_EL_FOCUS.get(ticker, ['营收、利润与同口径市场预期', '下一期指引与经营变化', '现金流、资本开支与主要风险'])),
              'articles': [], 'released': False, 'checked_at': None, 'last_success_at': None, 'error': None,
              'provenance_note': '预期与实际分开；新闻是快讯来源，未核实字段保持空缺。研究关注点由规则模板整理，不代表公司指引。'}
    return result


def _el_metrics(story, event=None):
    """Explicit quarter actuals; comparisons only for same-sentence estimate pairs."""
    text = str(story.get('zh') or '').replace('\\n', '\n')
    fields = {'调整后每股收益': ('adj_eps', '调整后EPS', '调整后/非GAAP'), '每股收益': ('eps', 'EPS', '未注明GAAP口径'),
              '营收': ('revenue', '营收', '未注明会计调整口径'), '营业收入': ('revenue', '营收', '未注明会计调整口径'),
              '资本支出': ('capex', '资本开支', '未注明租赁等纳入口径'), '资本开支': ('capex', '资本开支', '未注明租赁等纳入口径'),
              '运营利润': ('operating_income', '营业利润', '未注明GAAP口径'), '营业利润': ('operating_income', '营业利润', '未注明GAAP口径')}
    pattern = r'(调整后每股收益|每股收益|营业收入|营收|资本支出|资本开支|运营利润|营业利润)\s*(-?\d[\d,]*(?:\.\d+)?)\s*(亿美元|万美元|美元|亿元|万元|元|%)'
    expectations, actuals = [], []
    seen = set()
    for line in text.splitlines():
        if event is not None and not _el_issuer_matches(line, event):
            continue
        m = _el_re.search(pattern, line)
        if not m or _el_re.search(r'(?:预计|预期|预测|有望|将达|指引)[^，。;；]*$', line[:m.start()]):
            continue
        key, label, basis = fields[m.group(1)]
        if key in seen:
            continue
        # An actual can stand alone, but needs an explicit quarter assertion.
        # A previous-year value is never substituted for a consensus forecast.
        estimate = _el_re.search(r'(?:预期|预估|市场预计)\s*(-?\d[\d,]*(?:\.\d+)?)\s*(亿美元|万美元|美元|亿元|万元|元|%)?', line[m.end():])
        explicit_quarter = _el_re.search(r'第[一二三四1234]季度|\b(?:Q[1-4]|[1-4]Q)\b', line, _el_re.I)
        if not estimate and not explicit_quarter:
            continue
        unit = m.group(3)
        if estimate and estimate.group(2) and estimate.group(2) != unit:
            continue
        common = {'key': key, 'label': label, 'unit': unit, 'basis': basis, 'source_url': _el_url(story.get('url')), 'asof': story.get('time')}
        actual = dict(common, value=m.group(2).replace(',', ''))
        previous = _el_re.search(r'去年同期\s*(-?\d[\d,]*(?:\.\d+)?)\s*(亿美元|万美元|美元|亿元|万元|元|%)?', line[m.end():])
        if previous and (not previous.group(2) or previous.group(2) == unit):
            actual['previous_year'] = previous.group(1).replace(',', '')
        if estimate:
            expected = dict(common, value=estimate.group(1).replace(',', ''))
            old = float(expected['value'])
            if old > 0:
                actual['difference_pct'] = round((float(actual['value']) - old) / old * 100, 2)
            expectations.append(expected)
        actuals.append(actual); seen.add(key)
    return expectations, actuals


class _el_EquationClient:
    def __init__(self):
        self._rss_items = []
        self._rss_at = 0
        self._rss_etag = None
        self._lock = _el_threading.Lock()
        self.retry_at = 0

    def _request(self, url, payload=None, etag=None):
        if _el_time.monotonic() < self.retry_at:
            raise RuntimeError('新闻接口限流退避中，请稍后重试')
        headers = {'User-Agent': 'WillanceEventCalendar/1.4', 'Accept': 'application/json, text/event-stream' if payload else 'application/rss+xml,application/xml'}
        if payload:
            headers['Content-Type'] = 'application/json'
        if etag:
            headers['If-None-Match'] = etag
        request = _el_urlrequest.Request(url, data=_el_json.dumps(payload).encode() if payload else None, headers=headers, method='POST' if payload else 'GET')
        try:
            with _el_urlrequest.urlopen(request, timeout=8) as response:
                raw = response.read(_EL_BODY_MAX + 1)
                if len(raw) > _EL_BODY_MAX:
                    raise ValueError('新闻响应超过大小限制')
                return raw, response.headers.get('ETag')
        except _el_urlerror.HTTPError as error:
            if error.code == 304:
                return None, etag
            if error.code == 429:
                try:
                    delay = min(300, max(10, int(error.headers.get('Retry-After', '60'))))
                except ValueError:
                    delay = 60
                self.retry_at = _el_time.monotonic() + delay
            raise RuntimeError('新闻接口HTTP ' + str(error.code)) from None

    def _mcp(self, name, arguments):
        payload = {'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call', 'params': {'name': name, 'arguments': arguments}}
        raw, _ = self._request(_EL_MCP, payload)
        text = raw.decode('utf-8')
        try:
            envelope = _el_json.loads(text)
        except ValueError:
            frames = [line[5:].strip() for line in text.splitlines() if line.startswith('data:')]
            envelope = next((_el_json.loads(line) for line in reversed(frames) if line and line != '[DONE]'), {})
        if envelope.get('error'):
            raise RuntimeError('新闻检索暂不可用')
        result = envelope.get('result') or {}
        if result.get('isError'):
            raise RuntimeError('新闻检索返回错误')
        value = result.get('structuredContent')
        if isinstance(value, dict):
            return value
        for block in result.get('content') or []:
            if block.get('type') == 'text':
                try:
                    value = _el_json.loads(block.get('text') or '')
                    if isinstance(value, dict):
                        return value
                except ValueError:
                    continue
        raise ValueError('新闻接口结构未识别')

    def rss(self):
        with self._lock:
            if _el_time.monotonic() - self._rss_at < _EL_TTL:
                return _el_copy.deepcopy(self._rss_items)
            raw, etag = self._request(_EL_RSS, etag=self._rss_etag)
            if raw is not None:
                if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
                    raise ValueError('RSS含不支持的实体声明')
                tree = _el_ET.fromstring(raw)
                items = []
                for row in tree.findall('./channel/item')[:50]:
                    published = _el_date(row.findtext('pubDate'))
                    items.append({'zh': row.findtext('description') or row.findtext('title') or '', 'url': row.findtext('link'), 'time': published.isoformat() if published else None, 'source': '方程式财经RSS', 'channels': ['tradfi']})
                self._rss_items, self._rss_etag = items, etag
            self._rss_at = _el_time.monotonic()
            return _el_copy.deepcopy(self._rss_items)

    def search(self, event):
        ticker = str((event.get('company') or {}).get('ticker') or '')[:30]
        warning = None
        try:
            value = self._mcp('list_news', {'channel': 'tradfi', 'query': ticker, 'limit': 20})
            items = value.get('items')
            if not isinstance(items, list):
                raise ValueError('新闻名单结构未识别')
            if items:
                return items[:20], {'transport': 'MCP', 'status': 'ok', 'coverage': '近30天关键词搜索，最多20条；不保证全市场完整覆盖'}
        except Exception as error:
            warning = str(error)[:180]
        items = self.rss()
        return items, {'transport': 'RSS', 'status': 'partial' if warning else 'ok', 'warning': warning, 'coverage': '最近50条TradFi快讯；RSS缓存60秒，不承诺第一时间或完整历史'}


class EarningsService:
    """Bounded cache + two background workers; snapshot never waits for the network."""
    def __init__(self, cache_dir, offline=False):
        self.cache_dir = _el_Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.offline = bool(offline)
        self._lock = _el_threading.RLock()
        self._records = _el_collections.OrderedDict()
        self._inflight = set()
        self._attempts = {}
        self._pool = _el_ThreadPoolExecutor(max_workers=2, thread_name_prefix='earnings-on-demand')
        self._client = _el_EquationClient()
        self._closed = False

    def _key(self, event):
        company = event.get('company') or {}
        raw = [event.get('market'), company.get('ticker'), _el_period(event), event.get('date')]
        return _el_hashlib.sha256(_el_json.dumps(raw, ensure_ascii=False).encode()).hexdigest()

    def _read(self, key):
        if key in self._records:
            self._records.move_to_end(key)
            return self._records[key]
        path = self.cache_dir / (key + '.json')
        try:
            if path.stat().st_size > 100_000:
                return None
            value = _el_json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(value, dict) or value.get('schema') != 1:
                return None
            self._records[key] = value
            self._bound()
            return value
        except (OSError, ValueError, TypeError):
            return None

    def _bound(self):
        while len(self._records) > _EL_MAX:
            old, _ = self._records.popitem(last=False)
            self._attempts.pop(old, None)

    def snapshot(self, event, refresh=False):
        if not isinstance(event, dict) or event.get('category') != 'earnings' or not isinstance(event.get('company'), dict):
            raise ValueError('此事件不是有证券代码的公司财报')
        company = event['company']
        if not _el_re.fullmatch(r'[A-Za-z0-9.\-]{1,30}', str(company.get('ticker') or '')):
            raise ValueError('证券代码格式无效')
        base, key = _el_base(event), self._key(event)
        with self._lock:
            cached = self._read(key)
            if cached:
                for field in ('expectations', 'actuals', 'articles', 'released', 'checked_at', 'last_success_at', 'error', 'provenance_note', 'source_status', 'data_stale'):
                    if field in cached:
                        base[field] = _el_copy.deepcopy(cached[field])
                base['status'] = cached.get('status', 'partial')
            if self.offline or self._closed:
                base['status'] = 'offline'
                base['error'] = '当前为离线模式，展示已有记录；尚未联网核验。'
                return base
            now = _el_time.monotonic()
            age = now - self._attempts.get(key, -1e10)
            # An explicit refresh cannot hammer a source more than once per minute.
            if key not in self._inflight and age >= _EL_TTL:
                if len(self._inflight) < 2:
                    self._inflight.add(key)
                    self._attempts[key] = now
                    self._pool.submit(self._refresh, key, _el_copy.deepcopy(event))
                else:
                    base['error'] = '正在读取其他财报，请稍后重试；日历可继续操作。'
            if key in self._inflight:
                base['status'] = 'refreshing'
            return base

    def _refresh(self, key, event):
        result = _el_base(event)
        result['checked_at'] = _el_now()
        try:
            stories, source_status = self._client.search(event)
            stories = [s for s in stories if isinstance(s, dict) and _el_story_matches(s, event)]
            stories.sort(key=lambda s: str(s.get('time') or ''), reverse=True)
            expectations = {m['key']: m for m in result['expectations']}
            actuals, articles, seen = {}, [], set()
            for story in stories:
                url = _el_url(story.get('url'))
                if not url or _el_urlparse.urlsplit(url).hostname != 'eqn.news' or url in seen:
                    continue
                text = str(story.get('zh') or story.get('en') or '').replace('\\n', '\n')
                title = _el_re.sub('<[^>]+>', '', _el_html.unescape(text)).strip().split('\n')[0][:250]
                if not title:
                    continue
                seen.add(url)
                articles.append({'title': title, 'url': url, 'published_at': story.get('time'), 'source_name': '方程式财经 · ' + str(story.get('source') or '快讯')[:60], 'source_url': _el_url(story.get('source_url'))})
                news_expected, news_actual = _el_metrics(story, event)
                for value in news_expected:
                    expectations.setdefault(value['key'], value)
                    # Same story expectations supersede a calendar estimate only when its accounting key agrees.
                    if value['key'] not in actuals:
                        expectations[value['key']] = value
                for value in news_actual:
                    actuals.setdefault(value['key'], value)
                if len(articles) >= 5:
                    break
            result.update(expectations=list(expectations.values())[:8], actuals=list(actuals.values())[:8], articles=articles, released=bool(actuals), source_status=source_status, last_success_at=_el_now(), status='ready' if actuals else 'partial')
            result['provenance_note'] = '方程式快讯按证券名称/代码、财季和披露日期窗口匹配；快讯未完整标明报告期的，仍待公司公告核验。新闻时间不是财报预定发布时间。调整后EPS与未注明口径EPS分列；研究关注点是规则模板。'
            if not articles:
                result['error'] = '当前检索范围内未找到能确认匹配本次财报的快讯；不代表尚未公布。'
                with self._lock:
                    previous = self._read(key)
                    if previous and (previous.get('actuals') or previous.get('articles')):
                        for field in ('expectations', 'actuals', 'articles', 'released', 'last_success_at'):
                            if field in previous:
                                result[field] = _el_copy.deepcopy(previous[field])
                        result['data_stale'] = True
                        result['error'] = '本次检索未重新覆盖本次财报，保留上次已获取记录及原始时点；不代表尚未公布。'
                        result['provenance_note'] = '展示上次成功获取的财报记录，原始来源和事实时点保留；本次新闻覆盖未重新核实这些字段。'
        except Exception as error:
            with self._lock:
                old = self._read(key)
                if old:
                    result = _el_copy.deepcopy(old)
            result.update(status='error', checked_at=_el_now(), error=str(error)[:250])
        finally:
            with self._lock:
                self._records[key] = result
                self._records.move_to_end(key)
                self._bound()
                self._inflight.discard(key)
                try:
                    temporary = self.cache_dir / (key + '.tmp')
                    temporary.write_text(_el_json.dumps(result, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
                    temporary.replace(self.cache_dir / (key + '.json'))
                    files = sorted(self.cache_dir.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
                    for path in files[_EL_MAX:]:
                        path.unlink(missing_ok=True)
                except OSError:
                    pass

    def close(self):
        with self._lock:
            self._closed = True
        self._pool.shutdown(wait=False, cancel_futures=True)

# END EARNINGS LIVE

# BEGIN MACRO LIVE (mirrors macro_live.py)
"""On-demand FOMC evidence cards; stdlib only, no global poll or market signal.

This source is also inlined in app.py for old installed updater compatibility.
The exact event's scheduled instant controls news matching. Calendar time,
official decision facts, news previews and conditional research stay distinct.
"""

import collections as _ml_collections
import copy as _ml_copy
import datetime as _ml_dt
import email.utils as _ml_email
import hashlib as _ml_hashlib
import html as _ml_html
import json as _ml_json
from pathlib import Path as _ml_Path
import re as _ml_re
import threading as _ml_threading
import time as _ml_time
import urllib.error as _ml_urlerror
import urllib.parse as _ml_urlparse
import urllib.request as _ml_urlrequest
import xml.etree.ElementTree as _ml_ET
from concurrent.futures import ThreadPoolExecutor as _ml_ThreadPoolExecutor

_ML_UTC = _ml_dt.timezone.utc
_ML_BJ = _ml_dt.timezone(_ml_dt.timedelta(hours=8))
_ML_TTL = 60
_ML_MAX = 100
_ML_BODY_MAX = 1_000_000
_ML_MCP = 'https://api.eqn.news/public/mcp'
_ML_RSS = 'https://api.eqn.news/public/rss?ch=tradfi&lang=zh'
_ML_FED_CAL = 'https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm'


def _ml_now():
    return _ml_dt.datetime.now(_ML_UTC).isoformat(timespec='seconds')


def _ml_date(value):
    if not isinstance(value, str) or len(value) > 100:
        return None
    try:
        parsed = _ml_dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
        # The newswire documents UTC, but a calendar instant must be explicit.
        return parsed.replace(tzinfo=_ML_UTC) if parsed.tzinfo is None else parsed
    except ValueError:
        try:
            parsed = _ml_email.parsedate_to_datetime(value)
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=_ML_UTC)
        except (ValueError, TypeError):
            return None


def _ml_url(value, hosts=None):
    if not isinstance(value, str) or len(value) > 2048:
        return None
    try:
        parsed = _ml_urlparse.urlsplit(value)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 443):
            return None
        if hosts and parsed.hostname.lower() not in hosts:
            return None
        return value
    except ValueError:
        return None


def _ml_text(value, limit=500):
    value = str(value or '').replace('\\n', '\n')
    value = _ml_re.sub(r'<(?:script|style)\b[^>]*>.*?</(?:script|style)>', '', value, flags=_ml_re.I | _ml_re.S)
    value = _ml_re.sub(r'<[^>]+>', ' ', value)
    return _ml_re.sub(r'[ \t]+', ' ', _ml_html.unescape(value)).strip()[:limit]


def _ml_instant(event):
    raw = event.get('start_at')
    instant = _ml_date(raw)
    if not raw or not instant or not _ml_re.search(r'(?:Z|[+-]\d\d:\d\d)$', str(raw)):
        return None
    if event.get('time_precision') not in ('exact', 'minute', 'second'):
        return None
    if event.get('date') != instant.astimezone(_ML_BJ).date().isoformat():
        return None
    return instant.astimezone(_ML_UTC)


def _ml_kind(event):
    if not isinstance(event, dict) or event.get('category') != 'macro':
        return None
    title = str(event.get('title') or '')
    if not _ml_re.search(r'FOMC|联邦公开市场委员会', title, _ml_re.I):
        return None
    if _ml_re.search(r'纪要|minutes', title, _ml_re.I):
        return 'minutes'
    if _ml_re.search(r'新闻发布会|记者会|press conference', title, _ml_re.I):
        return 'press'
    if _ml_re.search(r'决议|利率决定|rate decision', title, _ml_re.I):
        return 'decision'
    return None


def macro_supported(event):
    if not _ml_kind(event) or not _ml_instant(event):
        return False
    try:
        _ml_eastern_day(event)
        return True
    except ValueError:
        return False


def _ml_eastern_day(event):
    instant = _ml_instant(event)
    if instant is None:
        raise ValueError('FOMC事件缺少一致的精确发布时刻')
    # Avoid a tzdata dependency on the installed stdlib-only Windows runtime.
    # Since 2007 US DST changes at 07:00 UTC in March and 06:00 UTC in November.
    year = instant.year
    if year < 2007:
        raise ValueError('历史美东时区规则未支持')
    march = _ml_dt.date(year, 3, 1)
    november = _ml_dt.date(year, 11, 1)
    start_day = march + _ml_dt.timedelta(days=(6-march.weekday()) % 7 + 7)
    end_day = november + _ml_dt.timedelta(days=(6-november.weekday()) % 7)
    start = _ml_dt.datetime.combine(start_day, _ml_dt.time(7), _ML_UTC)
    end = _ml_dt.datetime.combine(end_day, _ml_dt.time(6), _ML_UTC)
    local = instant.astimezone(_ml_dt.timezone(_ml_dt.timedelta(hours=-4 if start <= instant < end else -5)))
    expected_minute = 30 if _ml_kind(event) == 'press' else 0
    if local.time().replace(tzinfo=None) != _ml_dt.time(14, expected_minute):
        raise ValueError('FOMC发布时刻与标准美东公开时刻不一致')
    day = local.date()
    original = (event.get('details') or {}).get('官方美东日期')
    if original and str(original) != day.isoformat():
        raise ValueError('FOMC原始日期与公开发布时刻不一致')
    return day


def _ml_base(event):
    kind = _ml_kind(event)
    instant = _ml_instant(event)
    if not kind or not instant:
        raise ValueError('当前仅支持有精确时刻的FOMC决议、发布会和纪要')
    _ml_eastern_day(event)
    extra = '（会议决议背景）' if kind == 'press' else ''
    metrics = [] if kind == 'minutes' else [
        {'key': 'target_range', 'label': '联邦基金目标区间' + extra, 'expected': None, 'actual': None, 'previous': None, 'unit': '%'},
        {'key': 'rate_change', 'label': '本次利率调整' + extra, 'expected': None, 'actual': None, 'previous': None, 'unit': 'bp'},
        {'key': 'vote', 'label': '决议赞成 / 反对票' + extra, 'expected': None, 'actual': None, 'previous': None, 'unit': '票'},
    ]
    for metric in metrics:
        metric.update(asof=None, source_url=None, source_name='来源未提供', verification='来源未提供')
    return {'schema': 1, 'status': 'partial', 'event_kind': kind,
            'meeting_date_beijing': event.get('date') if kind != 'minutes' else None,
            'event_date': event.get('date'), 'release_date_eastern': _ml_eastern_day(event).isoformat(),
            'schedule': {'date': event.get('date'), 'time_display': event.get('time_display') or event.get('time'),
                         'start_at': event.get('start_at'), 'precision': 'exact', 'timezone': 'Asia/Shanghai'},
            'metrics': metrics, 'preview': [], 'summary': None,
            'stance': {'label': '待判断', 'basis': '规则解读；仅根据明确文本信号，不等于相对市场预期的鹰鸽评价。',
                       'evidence': [], 'asof': None, 'source_url': None},
            'impact_scenarios': [
                {'condition': '若政策路径比市场预期更紧', 'assets': ['美债收益率', '美元', '黄金', '成长股 / BTC'],
                 'text': '通常先观察短端收益率与美元是否上行，再核对黄金、成长股和BTC是否承压；实际反应也受增长、仓位和已定价程度影响。', 'basis': '研究情景模板，不是已发生行情'},
                {'condition': '若政策路径比市场预期更松', 'assets': ['美债收益率', '美元', '黄金', '成长股 / BTC'],
                 'text': '通常先观察收益率与美元是否回落，再核对黄金和风险资产是否受支持；衰退担忧也可能压制风险资产。', 'basis': '研究情景模板，不是已发生行情'},
            ],
            'focus_points': ['实际决议与会前预期是否一致', '通胀、就业和下一步政策措辞', '异议票方向及发布会补充说明'] if kind != 'minutes' else ['纪要对应哪次会议，避免当作新决议', '多数与会者对通胀、就业和政策路径的判断', '会后新数据是否已改变背景'],
            'articles': [], 'official_sources': [{'title': '美联储FOMC官方日历与文件', 'url': _ML_FED_CAL}],
            'checked_at': None, 'last_success_at': None, 'error': None, 'data_stale': False,
            'source_status': {}, 'provenance_note': '官方结果、新闻预期与规则解读分别标注；未取得字段不以0填充。'}


def _ml_number(value):
    """Parse Fed fractional rate words, not arbitrary numbers from a document."""
    value = value.strip().lower().replace('−', '-').replace('–', '-')
    replacements = {'three-quarters': '.75', 'one-quarter': '.25', 'three quarters': '.75',
                    'one quarter': '.25', 'one-half': '.5', 'one half': '.5', '¾': '.75', '¼': '.25', '½': '.5'}
    for token, replacement in replacements.items():
        value = value.replace(token, replacement)
    if value in ('1/4', '1/2', '3/4'):
        return {'1/4': .25, '1/2': .5, '3/4': .75}[value]
    value = _ml_re.sub(r'(\d)\s*[- ]?\s*(3/4|1/4|1/2)', lambda m: str(float(m.group(1)) + {'3/4': .75, '1/4': .25, '1/2': .5}[m.group(2)]), value)
    value = _ml_re.sub(r'(\d)\s*(?:and\s*)?(\.\d+)', r'\1\2', value)
    try:
        number = float(value)
        return number if 0 <= number <= 30 else None
    except ValueError:
        return None


def _ml_range(text, official=False):
    if official:
        match = _ml_re.search(r'target range for the federal funds rate (?:by\s+[0-9¼½¾ /.-]+\s+percentage points?\s+)?(?:at|to)\s+([0-9¼½¾ /.-]+)\s+(?:to|through)\s+([0-9¼½¾ /.-]+)\s+percent', text, _ml_re.I)
    else:
        match = _ml_re.search(r'(?:基准利率|联邦基金(?:目标)?利率|BENCHMARK RATE|FEDERAL FUNDS RATE)[^。;；\n]{0,65}?(\d+(?:\.\d+)?)\s*%?\s*[-–~至到]\s*(\d+(?:\.\d+)?)\s*%', text, _ml_re.I)
    if not match:
        return None
    low, high = _ml_number(match.group(1)), _ml_number(match.group(2))
    if low is None or high is None or high < low or high - low > 1:
        return None
    return f'{low:g}–{high:g}'


def _ml_metric(result, key, value, source, field='actual'):
    metric = next((row for row in result['metrics'] if row['key'] == key), None)
    if metric is None or value is None:
        return
    metric[field] = str(value)[:180]
    if field == 'expected':
        metric.update(expected_source_url=source.get('url'), expected_source_name=source.get('source_name'), expected_asof=source.get('asof'))
    else:
        metric.update(asof=source.get('asof'), source_url=source.get('url'), source_name=source.get('source_name'), verification=source.get('verification'))


def _ml_discover(calendar_html, event):
    """Only return published HTML links actually found on the official calendar."""
    clean = _ml_re.sub(r'<!--.*?-->', '', calendar_html, flags=_ml_re.S)
    day = _ml_eastern_day(event)
    stamp = day.strftime('%Y%m%d')
    kind = _ml_kind(event)
    if kind != 'minutes':
        path = '/newsevents/pressreleases/monetary' + stamp + 'a.htm'
        if _ml_re.search(r'href=[\"\']' + _ml_re.escape(path) + r'[\"\']', clean):
            return _ml_urlparse.urljoin(_ML_FED_CAL, path)
        return None
    for section in _ml_re.split(r'<div\s+class=[\"\'][^\"\']*\bfomc-meeting\b[^\"\']*[\"\'][^>]*>', clean, flags=_ml_re.I)[1:]:
        released = _ml_re.search(r'\(Released\s+([A-Za-z]+\s+\d{1,2},\s+20\d{2})\)', _ml_text(section, 20000))
        if not released:
            continue
        try:
            release_day = _ml_dt.datetime.strptime(released.group(1), '%B %d, %Y').date()
        except ValueError:
            continue
        if release_day != day:
            continue
        match = _ml_re.search(r'href=[\"\'](/monetarypolicy/fomcminutes(20\d{6})\.htm)[\"\']', section)
        if match:
            return _ml_urlparse.urljoin(_ML_FED_CAL, match.group(1))
    return None


def _ml_official_apply(result, event, url, body):
    if not _ml_url(url, {'www.federalreserve.gov'}):
        return False
    publication = _ml_instant(event) - (_ml_dt.timedelta(minutes=30) if _ml_kind(event) == 'press' else _ml_dt.timedelta())
    if publication > _ml_date(_ml_now()):
        return False
    clean = _ml_text(body, 250000)
    if _ml_kind(event) == 'minutes':
        match = _ml_re.search(r'/fomcminutes(20\d{6})\.htm$', url)
        if not match or not _ml_re.search(r'Minutes of the Federal Open Market Committee', clean, _ml_re.I):
            return False
        result['official_sources'].append({'title': '本次发布的会议纪要（不是新决议）', 'url': url})
        result['summary'] = '会议纪要已发布；对应会议结束日（美东）' + _ml_dt.datetime.strptime(match.group(1), '%Y%m%d').date().isoformat() + '。'
        result['meeting_date_beijing'] = None
        return True
    stamp = _ml_eastern_day(event).strftime('%Y%m%d')
    if not url.endswith('/monetary' + stamp + 'a.htm'):
        return False
    release_date = _ml_re.search(r'<p[^>]+class=[\"\'][^\"\']*\barticle__time\b[^\"\']*[\"\'][^>]*>(.*?)</p>', body, _ml_re.I | _ml_re.S)
    try:
        body_day = _ml_dt.datetime.strptime(_ml_text(release_date.group(1), 100), '%B %d, %Y').date() if release_date else None
    except ValueError:
        body_day = None
    if body_day != _ml_eastern_day(event):
        return False
    # Require a matching date in the article body, not just a URL or cached nav.
    section = _ml_re.search(r'<h3[^>]*>\s*Federal Reserve issues FOMC statement\s*</h3>(.*?)(?:<div[^>]+id=[\"\']social|<footer|</article>)', body, _ml_re.I | _ml_re.S)
    text = _ml_text(section.group(1), 70000) if section else clean
    if not _ml_re.search(r'Federal Reserve issues FOMC statement', clean, _ml_re.I) or not _ml_re.search(r'The Committee decided', text, _ml_re.I):
        return False
    range_value = _ml_range(text, official=True)
    if not range_value:
        return False
    source = {'url': url, 'asof': _ml_instant(event).isoformat(), 'source_name': '美联储官方声明', 'verification': '官方已核验'}
    if _ml_kind(event) == 'press':
        # Statement facts are meeting background, not a new press-conference vote.
        source['asof'] = (_ml_instant(event) - _ml_dt.timedelta(minutes=30)).isoformat()
    _ml_metric(result, 'target_range', range_value, source)
    decision = _ml_re.search(r'The Committee decided to (maintain|raise|lower|increase|decrease)[^\n]{0,280}', text, _ml_re.I)
    if decision:
        action = decision.group(1).lower()
        if action == 'maintain':
            _ml_metric(result, 'rate_change', '0', source)
            _ml_metric(result, 'target_range', range_value, source, field='previous')
            result['summary'] = '官方决议：维持目标区间 ' + range_value + '%。'
        else:
            # Parse only an explicit adjustment in that decision sentence.
            change = _ml_re.search(r'by\s+([0-9¼½¾ /.-]+)\s+percentage point', decision.group(0), _ml_re.I)
            amount = _ml_number(change.group(1)) if change else None
            if amount is not None:
                _ml_metric(result, 'rate_change', f'{amount * 100 * (1 if action in ("raise", "increase") else -1):+g}', source)
            result['summary'] = '官方决议：目标区间 ' + range_value + '%；调整方向以声明原文为准。'
    vote = _ml_re.search(r'(?:by a\s+)?(\d{1,2})\s*[–—-]\s*(\d{1,2})\s+vote', text, _ml_re.I)
    if vote:
        _ml_metric(result, 'vote', vote.group(1) + ' / ' + vote.group(2), source)
    result['official_sources'].append({'title': '本次会议官方声明', 'url': url})
    result['_official_text'] = text
    result['_official_url'] = url
    return True


def _ml_story_kind(story, event):
    instant = _ml_instant(event)
    published = _ml_date(story.get('time'))
    if not published or not instant:
        return None
    if published > _ml_date(_ml_now()) + _ml_dt.timedelta(minutes=5):
        return None
    text = str(story.get('zh') or '') + '\n' + str(story.get('en') or '')
    if not _ml_re.search(r'美联储|FOMC|FED(?:ERAL RESERVE|\b|\x27S)', text, _ml_re.I):
        return None
    if not _ml_re.search(r'利率|加息|降息|政策|通胀|就业|经济|新闻发布会|记者会|纪要|RATE|POLICY|INFLATION|ECONOM|PRESS CONFERENCE|MINUTES|HAWKISH|DOVISH', text, _ml_re.I):
        return None
    delta = (published - instant).total_seconds()
    kind = _ml_kind(event)
    if delta < -90:
        if kind == 'minutes' or delta < -7 * 86400:
            return None
        # A named FOMC/rate announcement is needed; generic Fed speeches are not a forecast.
        if _ml_re.search(r'预期|预计|预估|前瞻|expected|forecast|consensus', text, _ml_re.I) and _ml_re.search(r'利率公告|利率决议|FOMC|FED[^\n]{0,35}(?:announcement|meeting|rate)', text, _ml_re.I):
            return 'preview'
        return None
    if delta > 8 * 3600:
        return None
    # A newly reposted recap is not the current meeting's result. Recognize
    # explicit dates only for post-release facts; multi-event weekly previews
    # are handled above and remain source-attributed qualitative commentary.
    explicit_days = []
    for year, month, day in _ml_re.findall(r'(?<!\d)(20\d{2})[-/年](\d{1,2})[-/月](\d{1,2})日?', text):
        try:
            explicit_days.append(_ml_dt.date(int(year), int(month), int(day)))
        except ValueError:
            return None
    for month, day in _ml_re.findall(r'(?<![\d年])(\d{1,2})月(\d{1,2})日', text):
        try:
            explicit_days.append(_ml_dt.date(_ml_eastern_day(event).year, int(month), int(day)))
        except ValueError:
            return None
    allowed_days = {_ml_eastern_day(event), instant.astimezone(_ML_BJ).date()}
    if explicit_days and any(day not in allowed_days for day in explicit_days):
        return None
    if kind == 'minutes':
        if _ml_re.search(r'新闻发布会|记者会|PRESS CONFERENCE|投票决定|VOTES? \d', text, _ml_re.I):
            return None
        return 'minutes' if _ml_re.search(r'纪要|MINUTES', text, _ml_re.I) else None
    if _ml_re.search(r'纪要|MINUTES', text, _ml_re.I):
        return None
    if kind == 'press':
        return 'press' if delta >= -60 else None
    # A decision card may show later press context, but does not turn it into a decision figure.
    return 'press' if delta >= 25 * 60 else 'decision'


def _ml_article(story, kind):
    url = _ml_url(story.get('url'), {'eqn.news'})
    title = _ml_text(story.get('zh') or story.get('en'), 240).split('\n')[0]
    if not url or not title:
        return None
    return {'title': title, 'url': url, 'published_at': story.get('time'),
            'source_name': '方程式财经 · ' + str(story.get('source') or '快讯')[:60],
            'source_url': _ml_url(story.get('source_url')), 'kind': kind}


def _ml_apply_news(result, event, stories):
    seen, articles, previews = set(), [], []
    for story in sorted(stories, key=lambda row: str(row.get('time') or ''), reverse=True):
        if not isinstance(story, dict):
            continue
        kind = _ml_story_kind(story, event)
        article = _ml_article(story, kind) if kind else None
        if not article or article['url'] in seen:
            continue
        seen.add(article['url'])
        text = _ml_text(story.get('zh') or story.get('en'), 10000)
        source = {'url': article['url'], 'asof': story.get('time'), 'source_name': article['source_name'], 'verification': '快讯待官方核验'}
        if kind == 'preview':
            # Keep a source's qualitative preview as a view, not market consensus.
            fed_lines = [line for line in text.splitlines() if _ml_re.search(r'美联储|FOMC|FED\b', line, _ml_re.I) and _ml_re.search(r'预期|预计|预估|expected|forecast', line, _ml_re.I)]
            for line in fed_lines[:2]:
                if len(previews) < 3:
                    previews.append({'text': line[:260], 'source_url': article['url'], 'source_name': article['source_name'], 'asof': story.get('time'), 'basis': '来源前瞻观点，不等于市场一致预期'})
                if _ml_re.search(r'预期|预计|预估|expected', line, _ml_re.I):
                    value = _ml_range(line)
                    metric = next((x for x in result['metrics'] if x['key'] == 'target_range'), {})
                    if value and metric.get('expected') is None:
                        _ml_metric(result, 'target_range', value, source, field='expected')
            if len(articles) < 12:
                articles.append(article)
            continue
        if kind == 'decision' and _ml_kind(event) == 'decision':
            value = _ml_range(text)
            if value and _ml_re.search(r'决定|维持|上调|下调|VOTES?|DECIDES?|HOLDS?|RAISES?|CUTS?', text, _ml_re.I) and not _ml_re.search(r'预计|预期|expected', text, _ml_re.I):
                metric = next((x for x in result['metrics'] if x['key'] == 'target_range'), {})
                if metric.get('actual') is None:
                    _ml_metric(result, 'target_range', value, source)
                    if _ml_re.search(r'维持|\bHOLD', text, _ml_re.I):
                        _ml_metric(result, 'rate_change', '0', source)
                        result['summary'] = '快讯报道维持目标区间 ' + value + '%；待官方核验。'
                vote = _ml_re.search(r'(\d{1,2})\s*票赞成[、,， ]*(\d{1,2})\s*票反对|VOTES?\s+(\d{1,2})\s*[-–]\s*(\d{1,2})', text, _ml_re.I)
                current = next((x for x in result['metrics'] if x['key'] == 'vote'), {})
                if vote and current.get('actual') is None:
                    _ml_metric(result, 'vote', (vote.group(1) or vote.group(3)) + ' / ' + (vote.group(2) or vote.group(4)), source)
        if len(articles) < 12:
            articles.append(article)
    # Decision facts first, then press context, then sourced previews. All retain real times.
    priority = {'decision': 0, 'minutes': 0, 'press': 1, 'preview': 2}
    articles.sort(key=lambda row: priority[row['kind']])
    result['articles'], result['preview'] = articles[:8], previews


def _ml_stance(result, event, stories):
    evidence = []
    texts = []
    if result.get('_official_text'):
        texts.append((result['_official_text'], result.get('_official_url'), '美联储官方声明', _ml_instant(event).isoformat()))
    for story in stories:
        kind = _ml_story_kind(story, event) if isinstance(story, dict) else None
        if kind and kind != 'preview':
            texts.append((_ml_text(story.get('zh') or story.get('en'), 10000), _ml_url(story.get('url'), {'eqn.news'}), '方程式财经快讯', story.get('time')))
    for text, url, source, asof in texts:
        if not url:
            continue
        for line in _ml_re.split(r'(?<=[。;；])|\n|(?<=[a-z]\.)\s+(?=[A-Z])', text):
            hawk = _ml_re.search(r'(?:主张|支持|倾向|认为[^，。]{0,15}合适)[^，。]{0,25}加息|(?:preferred|dissent|favor)[^.]{0,100}(?:raise|hike)|通胀[^，。]{0,10}(?:过高|上行风险)|INFLATION IS TOO HIGH', line, _ml_re.I)
            dove = _ml_re.search(r'(?:主张|支持|倾向)[^，。]{0,25}降息|(?:preferred|dissent|favor)[^.]{0,100}(?:lower|cut)|(?:不认为|并未|没有)[^，。]{0,20}(?:过热)|DON.T THINK[^.]{0,45}(?:TOO HOT|OVERHEAT)', line, _ml_re.I)
            if _ml_re.search(r'不(?:支持|主张|倾向)[^，。]{0,25}加息|\bnot\b[^.;]{0,25}(?:favor|support|prefer)[^.;]{0,50}(?:raise|hike|raising|hiking)', line, _ml_re.I):
                hawk = None
            if _ml_re.search(r'不(?:支持|主张|倾向)[^，。]{0,25}降息|\bnot\b[^.;]{0,25}(?:favor|support|prefer)[^.;]{0,50}(?:lower|cut)', line, _ml_re.I):
                dove = None
            if not hawk and not dove:
                continue
            signal = '偏鹰线索' if hawk and not dove else '缓和线索' if dove and not hawk else '分歧线索'
            record = {'text': line.strip(' *')[:220], 'url': url, 'asof': asof, 'source_name': source, 'signal': signal}
            if record['text'] and not any(record['text'] == old['text'] for old in evidence):
                evidence.append(record)
    evidence = evidence[:6]
    hawk = any(row['signal'] in ('偏鹰线索', '分歧线索') for row in evidence)
    dove = any(row['signal'] in ('缓和线索', '分歧线索') for row in evidence)
    label = '信号分歧' if hawk and dove else '偏鹰信号' if hawk else '偏鸽 / 缓和信号' if dove else '待判断'
    result['stance'].update(label=label, evidence=evidence, asof=max((str(row['asof']) for row in evidence), default=None), source_url=evidence[0]['url'] if evidence else None)
    result.pop('_official_text', None)
    result.pop('_official_url', None)


class _ml_RedirectHandler(_ml_urlrequest.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _ml_url(newurl, {'api.eqn.news', 'www.federalreserve.gov'}):
            raise ValueError('来源跳转到未允许域名')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class _ml_Client:
    def __init__(self):
        self.retry_at = 0
        self._lock = _ml_threading.Lock()
        self._rss_at = 0
        self._rss_items = []

    def _request(self, url, payload=None):
        if not _ml_url(url, {'api.eqn.news', 'www.federalreserve.gov'}):
            raise ValueError('不支持的宏观数据来源')
        if _ml_time.monotonic() < self.retry_at:
            raise RuntimeError('来源限流，稍后自动重试')
        headers = {'User-Agent': 'ShixuCalendar/1.7', 'Accept': 'application/json, text/event-stream, text/html, application/rss+xml'}
        if payload is not None:
            headers['Content-Type'] = 'application/json'
        request = _ml_urlrequest.Request(url, data=_ml_json.dumps(payload).encode() if payload is not None else None, headers=headers)
        try:
            with _ml_urlrequest.build_opener(_ml_RedirectHandler()).open(request, timeout=8) as response:
                if not _ml_url(response.geturl(), {'api.eqn.news', 'www.federalreserve.gov'}):
                    raise ValueError('来源跳转到未允许域名')
                raw = response.read(_ML_BODY_MAX + 1)
                if len(raw) > _ML_BODY_MAX:
                    raise ValueError('宏观数据响应过大')
                return raw
        except _ml_urlerror.HTTPError as error:
            if error.code == 429:
                try:
                    delay = min(300, max(10, int(error.headers.get('Retry-After', '60'))))
                except ValueError:
                    delay = 60
                self.retry_at = _ml_time.monotonic() + delay
            raise RuntimeError('来源HTTP ' + str(error.code)) from None

    def news(self):
        warning = None
        try:
            raw = self._request(_ML_MCP, {'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call', 'params': {'name': 'list_news', 'arguments': {'channel': 'tradfi', 'query': '美联储', 'limit': 50}}})
            text = raw.decode('utf-8')
            try:
                envelope = _ml_json.loads(text)
            except ValueError:
                frames = [line[5:].strip() for line in text.splitlines() if line.startswith('data:')]
                envelope = next((_ml_json.loads(row) for row in reversed(frames) if row and row != '[DONE]'), {})
            result = envelope.get('result') or {}
            if envelope.get('error') or result.get('isError'):
                raise ValueError('宏观新闻检索返回错误')
            value = result.get('structuredContent')
            if not isinstance(value, dict):
                value = next((_ml_json.loads(block['text']) for block in result.get('content', []) if block.get('type') == 'text'), {})
            if not isinstance(value.get('items'), list):
                raise ValueError('宏观新闻结构未识别')
            return value['items'][:50], {'status': 'ok', 'transport': 'MCP', 'coverage': '近30天关键词搜索，最多50条；不保证覆盖每场会议全部预期或讲话'}
        except Exception as error:
            warning = str(error)[:160]
        with self._lock:
            if _ml_time.monotonic() - self._rss_at >= _ML_TTL:
                raw = self._request(_ML_RSS)
                if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
                    raise ValueError('RSS含不支持的实体声明')
                tree = _ml_ET.fromstring(raw)
                items = []
                for row in tree.findall('./channel/item')[:50]:
                    published = _ml_date(row.findtext('pubDate'))
                    items.append({'zh': row.findtext('description') or row.findtext('title'), 'url': row.findtext('link'), 'time': published.isoformat() if published else None, 'source': 'RSS'})
                self._rss_items, self._rss_at = items, _ml_time.monotonic()
            return _ml_copy.deepcopy(self._rss_items), {'status': 'partial', 'transport': 'RSS', 'warning': warning, 'coverage': '最近50条快讯，缓存60秒，可能不含本场会议'}

    def official(self, event):
        calendar = self._request(_ML_FED_CAL).decode('utf-8', 'replace')
        url = _ml_discover(calendar, event)
        if not url:
            return None, None, {'status': 'not_found', 'message': '官方日历暂未列出该次公开文件，保留已知安排'}
        return url, self._request(url).decode('utf-8', 'replace'), {'status': 'ok', 'url': url}


class MacroService:
    """At most two requests, 100 cached events, minute rate limit; no main-thread I/O."""
    def __init__(self, cache_dir, offline=False):
        self.cache_dir = _ml_Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.offline = bool(offline)
        self._lock = _ml_threading.RLock()
        self._records = _ml_collections.OrderedDict()
        self._inflight, self._attempts = set(), {}
        self._pool = _ml_ThreadPoolExecutor(max_workers=2, thread_name_prefix='macro-on-demand')
        self._client = _ml_Client()
        self._closed = False

    def _key(self, event):
        raw = [event.get('id'), _ml_kind(event), event.get('start_at')]
        return _ml_hashlib.sha256(_ml_json.dumps(raw, ensure_ascii=False).encode()).hexdigest()

    def _bound(self):
        while len(self._records) > _ML_MAX:
            key, _ = self._records.popitem(last=False)
            self._attempts.pop(key, None)

    def _read(self, key):
        if key in self._records:
            self._records.move_to_end(key)
            return self._records[key]
        try:
            path = self.cache_dir / (key + '.json')
            if path.stat().st_size > 100_000:
                return None
            value = _ml_json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(value, dict) or value.get('schema') != 1 or value.get('event_kind') not in ('decision', 'press', 'minutes'):
                return None
            self._records[key] = value
            self._bound()
            return value
        except (OSError, ValueError, TypeError):
            return None

    def snapshot(self, event, refresh=False):
        base, key = _ml_base(event), self._key(event)
        with self._lock:
            cached = self._read(key)
            if cached:
                base = _ml_copy.deepcopy(cached)
            if self.offline or self._closed:
                base.update(status='offline', error='当前未联网，展示已有记录及原始时点。')
                return base
            age = _ml_time.monotonic() - self._attempts.get(key, -1e10)
            if key not in self._inflight and age >= (10 if refresh else _ML_TTL):
                if len(self._inflight) < 2:
                    self._inflight.add(key)
                    self._attempts[key] = _ml_time.monotonic()
                    self._pool.submit(self._refresh, key, _ml_copy.deepcopy(event))
                else:
                    base['error'] = '正在读取其他宏观事件，请稍后重试；日历可继续操作。'
            if key in self._inflight:
                base['status'] = 'refreshing'
            return base

    def request(self, event, force=False):
        return self.snapshot(event, refresh=force)

    def _refresh(self, key, event):
        result = _ml_base(event)
        result['checked_at'] = _ml_now()
        problems, stories = [], []
        official_ok = False
        try:
            try:
                url, body, source_status = self._client.official(event)
                result['source_status']['official'] = source_status
                if url and body:
                    official_ok = _ml_official_apply(result, event, url, body)
                    if not official_ok:
                        result['source_status']['official'] = {'status': 'unmatched', 'message': '官方文件未通过本次事件匹配'}
            except Exception as error:
                problems.append('官方来源：' + str(error)[:120])
                result['source_status']['official'] = {'status': 'error', 'message': str(error)[:160]}
            try:
                stories, news_status = self._client.news()
                stories = [row for row in stories if isinstance(row, dict)]
                result['source_status']['news'] = news_status
                _ml_apply_news(result, event, stories)
            except Exception as error:
                problems.append('新闻来源：' + str(error)[:120])
                result['source_status']['news'] = {'status': 'error', 'message': str(error)[:160]}
            _ml_stance(result, event, stories)
            useful = official_ok or bool(result['articles']) or any(row.get('actual') for row in result['metrics'])
            if useful:
                result['last_success_at'] = _ml_now()
                result['status'] = 'ready' if official_ok or any(row.get('actual') for row in result['metrics']) else 'partial'
            else:
                problems.append('本次检索尚未覆盖这场事件，不代表事件尚未公布。')
                result['status'] = 'error' if problems[:-1] else 'partial'
            with self._lock:
                old = self._read(key)
                if old:
                    # Source failure/rolling-window loss cannot erase already sourced facts.
                    old_metrics = {row['key']: row for row in old.get('metrics', [])}
                    for row in result['metrics']:
                        prior = old_metrics.get(row['key']) or {}
                        official_prior = prior.get('verification') == '官方已核验'
                        official_current = row.get('verification') == '官方已核验'
                        if prior.get('actual') is not None and (row.get('actual') is None or official_prior and not official_current):
                            for field in ('actual', 'previous', 'asof', 'source_url', 'source_name', 'verification'):
                                if field in prior:
                                    row[field] = _ml_copy.deepcopy(prior[field])
                            result['data_stale'] = True
                        if row.get('expected') is None and prior.get('expected') is not None:
                            for field in ('expected', 'expected_source_url', 'expected_source_name', 'expected_asof'):
                                if field in prior:
                                    row[field] = prior[field]
                    if not result['articles'] and old.get('articles'):
                        for field in ('articles', 'preview', 'stance', 'summary', 'official_sources'):
                            result[field] = _ml_copy.deepcopy(old.get(field, result.get(field)))
                        result['data_stale'] = True
                    if not useful:
                        for field in ('stance', 'summary', 'preview'):
                            result[field] = _ml_copy.deepcopy(old.get(field, result.get(field)))
                    elif not official_ok:
                        # An unavailable official endpoint does not retract its
                        # earlier dissent evidence when later headlines arrive.
                        prior_official = [row for row in (old.get('stance') or {}).get('evidence', []) if _ml_url(row.get('url'), {'www.federalreserve.gov'})]
                        if prior_official:
                            evidence = _ml_copy.deepcopy(prior_official)
                            evidence.extend(row for row in result['stance']['evidence'] if not any(row.get('text') == prior.get('text') for prior in evidence))
                            evidence = evidence[:6]
                            hawk = any(row.get('signal') in ('偏鹰线索', '分歧线索') for row in evidence)
                            dove = any(row.get('signal') in ('缓和线索', '分歧线索') for row in evidence)
                            label = '信号分歧' if hawk and dove else '偏鹰信号' if hawk else '偏鸽 / 缓和信号' if dove else '待判断'
                            result['stance'].update(label=label, evidence=evidence, asof=max((str(row.get('asof') or '') for row in evidence), default=None), source_url=evidence[0].get('url'))
                            result['data_stale'] = True
                    known_urls = {row.get('url') for row in result['official_sources']}
                    for row in old.get('official_sources', []):
                        if row.get('url') not in known_urls:
                            result['official_sources'].append(_ml_copy.deepcopy(row))
                            known_urls.add(row.get('url'))
                    if result['data_stale'] or not useful:
                        result['last_success_at'] = old.get('last_success_at')
            result['error'] = '；'.join(problems)[:350] or None
        except Exception as error:
            with self._lock:
                old = self._read(key)
                if old:
                    result = _ml_copy.deepcopy(old)
            result.update(status='error', data_stale=True, checked_at=_ml_now(), error=str(error)[:250])
        finally:
            result.pop('_official_text', None)
            result.pop('_official_url', None)
            with self._lock:
                self._records[key] = result
                self._records.move_to_end(key)
                self._bound()
                self._inflight.discard(key)
                try:
                    temp = self.cache_dir / (key + '.tmp')
                    temp.write_text(_ml_json.dumps(result, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
                    temp.replace(self.cache_dir / (key + '.json'))
                    files = sorted(self.cache_dir.glob('*.json'), key=lambda path: path.stat().st_mtime, reverse=True)
                    for path in files[_ML_MAX:]:
                        path.unlink(missing_ok=True)
                except OSError:
                    pass

    def close(self):
        with self._lock:
            self._closed = True
        self._pool.shutdown(wait=False, cancel_futures=True)

# END MACRO LIVE

# BEGIN OPTIONS LIVE (mirrors options_live.py)
"""Bounded on-demand Deribit expiry analytics; also inlined into app.py."""

import collections as _op_collections
import copy as _op_copy
import datetime as _op_dt
import hashlib as _op_hashlib
import json as _op_json
import math as _op_math
from pathlib import Path as _op_Path
import re as _op_re
import threading as _op_threading
import time as _op_time
import urllib.error as _op_urlerror
import urllib.parse as _op_urlparse
import urllib.request as _op_urlrequest
from concurrent.futures import ThreadPoolExecutor as _op_ThreadPoolExecutor

_OP_UTC = _op_dt.timezone.utc
_OP_TTL = 60
_OP_MAX = 100
_OP_BODY_LIMIT = 3_000_000
_OP_API = 'https://www.deribit.com/api/v2/public/'
_OP_DOCS = 'https://docs.deribit.com/api-reference/market-data/'
_OP_FIELDS = ('schema', 'status', 'asset', 'expiry_at', 'venue', 'settlement_currency', 'underlying', 'call_oi', 'put_oi', 'total_oi', 'oi_unit', 'notional_usd', 'notional_basis', 'put_call_ratio', 'max_pain', 'max_pain_range', 'max_pain_currency', 'index_price', 'index_asof', 'asof', 'checked_at', 'source_urls', 'coverage', 'methodology', 'error', 'last_success_at', 'instrument_count', 'observed_instruments', 'missing_instruments', 'data_stale', 'expired', 'time_basis')


def _op_now():
    return _op_dt.datetime.now(_OP_UTC)


def _op_number(value, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not _op_math.isfinite(value):
        return None
    if value < 0 or positive and value <= 0:
        return None
    return float(value)


def _op_iso(timestamp_ms):
    value = _op_number(timestamp_ms, positive=True)
    if value is None:
        return None
    try:
        return _op_dt.datetime.fromtimestamp(value / 1000, _OP_UTC).isoformat(timespec='seconds')
    except (ValueError, OverflowError, OSError):
        return None


def _op_identity(event):
    if not isinstance(event, dict) or event.get('category') != 'options':
        raise ValueError('请选择Deribit期权到期事项')
    identifier = str(event.get('id') or '')
    m = _op_re.fullmatch(r'deribit-(BTC|ETH)-(\d{10})', identifier)
    if not m:
        raise ValueError('暂仅支持Deribit BTC/ETH币本位到期组')
    asset, seconds = m.group(1), int(m.group(2))
    timestamp = event.get('timestamp_utc')
    if timestamp:
        try:
            parsed = _op_dt.datetime.fromisoformat(str(timestamp).replace('Z', '+00:00'))
            if parsed.tzinfo is None or abs(parsed.timestamp() - seconds) > 1:
                raise ValueError()
        except (ValueError, TypeError):
            raise ValueError('到期ID与来源时间不一致') from None
    return asset, seconds * 1000


def _op_base(event):
    asset, expiry = _op_identity(event)
    return {'schema': 1, 'status': 'partial', 'asset': asset, 'expiry_at': _op_iso(expiry), 'venue': 'Deribit',
            'settlement_currency': asset, 'underlying': asset, 'call_oi': None, 'put_oi': None, 'total_oi': None,
            'oi_unit': asset, 'notional_usd': None, 'notional_basis': '本次到期未平仓币数 × 本次快照现货指数（USD），不是权利金或实际交割金额',
            'put_call_ratio': None, 'max_pain': None, 'max_pain_range': None, 'max_pain_currency': 'USD',
            'index_price': None, 'index_asof': None, 'asof': None, 'checked_at': None, 'source_urls': [
                _OP_DOCS + 'public-get_instruments', _OP_DOCS + 'public-get_book_summary_by_currency', _OP_DOCS + 'public-get_index_price'],
            'coverage': '仅Deribit的BTC/ETH币本位期权、本次精确到期组；不含USDC结算及其他交易所。',
            'methodology': '最大痛点在本次已列执行价候选点，按当前OI的美元内在价值总支出最小值计算；这是USD名义口径，不是BTC/ETH结算币支出最小值，也不是价格预测。',
            'error': None, 'last_success_at': None, 'instrument_count': 0, 'observed_instruments': 0,
            'missing_instruments': 0, 'data_stale': False, 'expired': False, 'time_basis': '来源快照时点；检查时间另列'}


def _op_analyze(event, instruments, summaries, index, checked_at, asof=None, index_asof=None):
    """Join exact names/expiry/currency. API option OI is already underlying coins."""
    result = _op_base(event)
    asset, expiry = _op_identity(event)
    names, ambiguous = {}, set()
    for item in instruments:
        if not isinstance(item, dict) or item.get('kind') != 'option' or item.get('base_currency') != asset or item.get('settlement_currency') != asset:
            continue
        if item.get('quote_currency') != asset or item.get('instrument_type') != 'reversed' or item.get('price_index') != asset.lower() + '_usd':
            continue
        if item.get('expiration_timestamp') != expiry:
            continue
        name = item.get('instrument_name')
        if not isinstance(name, str) or not name.startswith(asset + '-') or len(name) > 100:
            continue
        if name in names and names[name] != item:
            ambiguous.add(name)
        else:
            names[name] = item
    summary_map, duplicate = {}, set()
    for row in summaries:
        if not isinstance(row, dict):
            continue
        name = row.get('instrument_name')
        if name not in names:
            continue
        if name in summary_map:
            duplicate.add(name)
        else:
            summary_map[name] = row
    calls, puts, rows, stamps = 0.0, 0.0, [], []
    missing = 0
    for name, item in names.items():
        summary = summary_map.get(name)
        oi = _op_number(summary.get('open_interest')) if summary else None
        strike = _op_number(item.get('strike'), positive=True)
        side = item.get('option_type')
        if name in ambiguous or name in duplicate or not summary or summary.get('base_currency') != asset or summary.get('quote_currency') != asset or oi is None or strike is None or side not in ('call', 'put'):
            missing += 1
            continue
        # contract_size is NOT multiplied: open_interest is amount in BTC/ETH.
        rows.append((strike, side, oi))
        if side == 'call':
            calls += oi
        else:
            puts += oi
        timestamp = _op_number(summary.get('creation_timestamp'), positive=True)
        if timestamp is not None:
            stamps.append(timestamp)
    result.update(checked_at=checked_at, instrument_count=len(names), observed_instruments=len(rows), missing_instruments=missing,
                  index_price=_op_number(index, positive=True), index_asof=index_asof, asof=_op_iso(min(stamps)) if stamps else asof)
    if not names:
        result.update(status='unavailable', error='当前未列示该精确到期组；不能据此补出历史或零持仓数据。')
        return result
    if missing or not rows:
        result.update(status='partial', error='本次到期组有缺失、重复或单位不一致记录，未展示不完整的规模与最大痛点。')
        return result
    calls = _op_math.fsum(oi for _, side, oi in rows if side == 'call')
    puts = _op_math.fsum(oi for _, side, oi in rows if side == 'put')
    total = _op_math.fsum((calls, puts))
    result.update(call_oi=calls, put_oi=puts, total_oi=total, put_call_ratio=puts / calls if calls > 0 else None,
                  notional_usd=total * result['index_price'] if result['index_price'] is not None else None)
    if total > 0:
        candidates = sorted({strike for strike, _, _ in rows})
        payouts = [(settle, _op_math.fsum(oi * (max(settle - strike, 0) if side == 'call' else max(strike - settle, 0)) for strike, side, oi in rows)) for settle in candidates]
        minimum = min(value for _, value in payouts)
        tolerance = max(1e-7, abs(minimum) * 1e-12)
        tied = [settle for settle, value in payouts if abs(value - minimum) <= tolerance]
        result['max_pain_range'] = [min(tied), max(tied)]
        result['max_pain'] = tied[0] if len(tied) == 1 else None
    else:
        result['error'] = '该到期组当前未平仓量为零，最大痛点与Put/Call不适用。'
    if result['index_price'] is None:
        result['error'] = '指数价格不可用；币数有效，美元名义规模暂缺。'
    result.update(status='ready' if result['index_price'] is not None else 'partial', last_success_at=checked_at)
    return result


class _op_DeribitClient:
    def __init__(self):
        self._cache = {}
        self._locks = {asset: _op_threading.Lock() for asset in ('BTC', 'ETH')}
        self.retry_at = 0

    def _request(self, method, params):
        if method not in ('get_instruments', 'get_book_summary_by_currency', 'get_index_price'):
            raise ValueError('未授权的数据接口')
        if _op_time.monotonic() < self.retry_at:
            raise RuntimeError('Deribit接口限流退避中，请稍后重试')
        url = _OP_API + method + '?' + _op_urlparse.urlencode(params)
        request = _op_urlrequest.Request(url, headers={'User-Agent': 'WillanceCalendar/1.5', 'Accept': 'application/json'})
        try:
            with _op_urlrequest.urlopen(request, timeout=7) as response:
                raw = response.read(_OP_BODY_LIMIT + 1)
                if len(raw) > _OP_BODY_LIMIT:
                    raise ValueError('期权接口响应超过大小限制')
            value = _op_json.loads(raw)
            if not isinstance(value, dict) or value.get('error') or value.get('testnet') is True:
                raise ValueError('Deribit主网接口返回错误或未识别结构')
            return value
        except _op_urlerror.HTTPError as error:
            if error.code == 429:
                try:
                    delay = min(300, max(60, int(error.headers.get('Retry-After', '60'))))
                except ValueError:
                    delay = 60
                self.retry_at = _op_time.monotonic() + delay
            raise RuntimeError('Deribit接口HTTP ' + str(error.code)) from None

    def currency(self, asset):
        if asset not in self._locks:
            raise ValueError('不支持的期权标的')
        with self._locks[asset]:
            old = self._cache.get(asset)
            if old and _op_time.monotonic() - old[0] < _OP_TTL:
                return old[1]
            instruments = self._request('get_instruments', {'currency': asset, 'kind': 'option', 'expired': 'false'})
            summaries = self._request('get_book_summary_by_currency', {'currency': asset, 'kind': 'option'})
            price = self._request('get_index_price', {'index_name': asset.lower() + '_usd'})
            if not isinstance(instruments.get('result'), list) or not isinstance(summaries.get('result'), list) or not isinstance(price.get('result'), dict):
                raise ValueError('Deribit接口结构变化，已停止计算')
            microseconds = _op_number(summaries.get('usOut'), positive=True)
            price_microseconds = _op_number(price.get('usOut'), positive=True)
            data = {'instruments': instruments['result'], 'summaries': summaries['result'], 'index': price['result'].get('index_price'), 'asof': _op_iso(microseconds / 1000) if microseconds else None,
                    'index_asof': _op_iso(price_microseconds / 1000) if price_microseconds else None}
            self._cache[asset] = (_op_time.monotonic(), data)
            return data


class OptionsService:
    def __init__(self, cache_dir, offline=False, *, client=None, clock=None):
        self.cache_dir = _op_Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.offline = bool(offline)
        self._client = client or _op_DeribitClient()
        self._clock = clock or _op_now
        self._records = _op_collections.OrderedDict()
        self._attempts = {}
        self._inflight = set()
        self._lock = _op_threading.RLock()
        self._pool = _op_ThreadPoolExecutor(max_workers=2, thread_name_prefix='calendar-options')
        self._closed = False

    def _key(self, event):
        asset, expiry = _op_identity(event)
        return asset + '-' + str(expiry)

    def _read(self, key):
        if key in self._records:
            self._records.move_to_end(key)
            return self._records[key]
        path = self.cache_dir / (key + '.json')
        try:
            if path.stat().st_size > 32_000:
                return None
            value = _op_json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(value, dict) or value.get('schema') != 1:
                return None
            expiry = _op_dt.datetime.fromisoformat(str(value.get('expiry_at', '')).replace('Z', '+00:00'))
            if expiry.tzinfo is None or value.get('asset') + '-' + str(int(expiry.timestamp() * 1000)) != key:
                return None
            self._records[key] = {k: v for k, v in value.items() if k in _OP_FIELDS}
            self._bound()
            return self._records.get(key)
        except (OSError, ValueError, TypeError):
            return None

    def _bound(self):
        while len(self._records) > _OP_MAX:
            key, _ = self._records.popitem(last=False)
            self._attempts.pop(key, None)

    def snapshot(self, event, refresh=False):
        base, key = _op_base(event), self._key(event)
        asset, expiry = _op_identity(event)
        now = self._clock()
        expired = now.timestamp() * 1000 >= expiry
        with self._lock:
            cached = self._read(key)
            if cached:
                base.update(_op_copy.deepcopy(cached))
            if expired:
                base.update(expired=True, data_stale=True, status='archived' if cached and cached.get('last_success_at') else 'unavailable',
                            error='已到期：展示原始快照，不用当前持仓反推历史。' if cached else '已到期且本机没有到期前快照；未提供历史规模和最大痛点。')
                return base
            if self.offline or self._closed:
                base.update(status='offline', data_stale=bool(cached), error='当前离线，保留已有快照；尚未重新联网核验。')
                return base
            age = _op_time.monotonic() - self._attempts.get(key, -1e10)
            if key not in self._inflight and age >= _OP_TTL:
                if len(self._inflight) < 2:
                    self._inflight.add(key)
                    self._attempts[key] = _op_time.monotonic()
                    self._pool.submit(self._refresh, key, _op_copy.deepcopy(event))
                else:
                    base['error'] = '正在读取其他到期组，请稍后重试；日历可继续操作。'
            if key in self._inflight:
                base['status'] = 'refreshing'
            return base

    def _refresh(self, key, event):
        checked_at = self._clock().isoformat(timespec='seconds')
        try:
            asset, expiry = _op_identity(event)
            payload = self._client.currency(asset)
            if self._clock().timestamp() * 1000 >= expiry:
                raise RuntimeError('取数期间已经到期，未把到期后数据作为到期前快照。')
            result = _op_analyze(event, payload['instruments'], payload['summaries'], payload.get('index'), checked_at, payload.get('asof'), payload.get('index_asof'))
            if result['status'] in ('partial', 'unavailable'):
                with self._lock:
                    old = self._read(key)
                    if old and old.get('last_success_at'):
                        error = result.get('error')
                        result = _op_copy.deepcopy(old)
                        result.update(status='partial', data_stale=True, error=error, checked_at=checked_at)
        except Exception as error:
            with self._lock:
                old = self._read(key)
            result = _op_copy.deepcopy(old) if old else _op_base(event)
            result.update(status='error', data_stale=bool(old), checked_at=checked_at, error=str(error)[:250])
        with self._lock:
            self._records[key] = result
            self._records.move_to_end(key)
            self._bound()
            self._inflight.discard(key)
            try:
                path = self.cache_dir / (key + '.json')
                temporary = path.with_suffix('.tmp')
                temporary.write_text(_op_json.dumps(result, ensure_ascii=False, allow_nan=False, separators=(',', ':')), encoding='utf-8')
                temporary.replace(path)
                files = sorted(self.cache_dir.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
                for old_path in files[_OP_MAX:]:
                    old_path.unlink(missing_ok=True)
            except OSError:
                pass

    def close(self):
        with self._lock:
            self._closed = True
        self._pool.shutdown(wait=False, cancel_futures=True)

# END OPTIONS LIVE

# BEGIN FAVORITES (mirrors favorites.py)
"""Local favorites and opt-in Windows reminders; no cloud writes or polling.

All non-exported globals are prefixed because this source is bundled into app.py.
Task Scheduler registration occurs only after the user saves a reminder. It uses
an interactive, limited current-user token and never changes other app tasks.
"""

import base64 as _fv_base64
import contextlib as _fv_contextlib
import copy as _fv_copy
import datetime as _fv_dt
import hashlib as _fv_hashlib
import json as _fv_json
import os as _fv_os
from pathlib import Path as _fv_Path
import re as _fv_re
import shutil as _fv_shutil
import subprocess as _fv_subprocess
import sys as _fv_sys
import threading as _fv_threading
import time as _fv_time
import urllib.parse as _fv_urlparse
import uuid as _fv_uuid

_FV_BJ = _fv_dt.timezone(_fv_dt.timedelta(hours=8))
_FV_UTC = _fv_dt.timezone.utc
_FV_MAX = 500
_FV_MAX_BYTES = 1_000_000
_FV_TASK = 'WillanceEventCalendarRemindersV1'
_FV_NOTE = '提醒使用北京时间；Windows已登录且电脑清醒时，计划任务每分钟核对。关机、睡眠或退出登录期间不能保证响铃；恢复后48小时内补提醒，较早的标记为错过。'


def _fv_now():
    return _fv_dt.datetime.now(_FV_UTC)


def _fv_stamp(value):
    return value.astimezone(_FV_BJ).isoformat(timespec='seconds')


def _fv_parse(value):
    if isinstance(value, _fv_dt.datetime):
        parsed = value
    elif isinstance(value, str) and len(value) <= 50:
        try:
            parsed = _fv_dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError:
            raise ValueError('提醒时间格式无效，请选择北京时间日期和时刻') from None
    else:
        raise ValueError('提醒时间格式无效，请选择北京时间日期和时刻')
    if parsed.tzinfo is None or parsed.utcoffset() != _fv_dt.timedelta(hours=8):
        raise ValueError('提醒时间必须明确使用北京时间UTC+8')
    return parsed.astimezone(_FV_BJ)


def _fv_url(value):
    if not isinstance(value, str) or len(value) > 2048:
        return None
    try:
        parsed = _fv_urlparse.urlsplit(value)
        return value if parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password else None
    except ValueError:
        return None


def _fv_public(item):
    result = _fv_copy.deepcopy(item)
    result['event'] = {k: result.get(k) for k in ('title', 'date', 'category', 'market', 'time_display', 'time_precision', 'start_at', 'source_url', 'source_name', 'company')}
    result['event']['id'] = result.get('event_id')
    if result.get('reminder'):
        result['reminder']['status'] = result['reminder'].get('state')
    return result


def _fv_clean_event(event):
    if not isinstance(event, dict):
        raise ValueError('收藏事件格式无效')
    event_id = str(event.get('id') or '')
    if not 1 <= len(event_id) <= 300:
        raise ValueError('收藏事件标识无效')
    try:
        date = _fv_dt.date.fromisoformat(str(event['date'])).isoformat()
    except (ValueError, KeyError, TypeError):
        raise ValueError('收藏事件日期无效') from None
    title = str(event.get('title') or '').strip()[:220]
    if not title:
        raise ValueError('收藏事件名称不能为空')
    company = event.get('company') or {}
    mark = company.get('logo_url')
    mark = mark if isinstance(mark, str) and _fv_re.fullmatch(r'/branding/[A-Za-z0-9_.-]+', mark) else None
    result = {'event_id': event_id, 'title': title, 'date': date,
              'category': str(event.get('category') or '')[:30], 'market': str(event.get('market') or '')[:30],
              'time_display': str(event.get('time_display') or event.get('time') or '日期级安排')[:300],
              'time_precision': str(event.get('time_precision') or 'date_only')[:30],
              'start_at': event.get('start_at') if isinstance(event.get('start_at'), str) else None,
              'source_url': _fv_url(event.get('source_url')), 'source_name': str(event.get('source_name') or '')[:120],
              'company': {'ticker': str(company.get('ticker') or '')[:30], 'name': str(company.get('name') or '')[:150], 'logo_url': mark}}
    result['id'] = _fv_hashlib.sha256(_fv_json.dumps([event_id, date], ensure_ascii=False).encode()).hexdigest()[:24]
    return result


def _fv_atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + _fv_uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('w', encoding='utf-8') as out:
            _fv_json.dump(value, out, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            out.flush()
            _fv_os.fsync(out.fileno())
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


class FavoritesStore:
    def __init__(self, cache_dir, app_root=None, platform=None, runner=None, clock=None):
        self.cache = _fv_Path(cache_dir)
        self.cache.mkdir(parents=True, exist_ok=True)
        self.path = self.cache / 'favorites.json'
        self.lock_path = self.cache / 'favorites.lock'
        self.app_root = _fv_Path(app_root or _fv_Path(__file__).resolve().parent).resolve()
        self.platform = _fv_os.name if platform is None else platform
        self.runner = runner or _fv_subprocess.run
        self.clock = clock or _fv_now
        self._thread_lock = _fv_threading.RLock()

    @_fv_contextlib.contextmanager
    def _locked(self):
        with self._thread_lock:
            deadline = _fv_time.monotonic() + 3
            while True:
                try:
                    self.lock_path.mkdir()
                    break
                except FileExistsError:
                    try:
                        if _fv_time.time() - self.lock_path.stat().st_mtime > 30:
                            self.lock_path.rmdir()
                            continue
                    except (FileNotFoundError, OSError):
                        pass
                    if _fv_time.monotonic() >= deadline:
                        raise RuntimeError('收藏数据正在写入，请稍后重试')
                    _fv_time.sleep(.02)
            try:
                yield
            finally:
                try:
                    self.lock_path.rmdir()
                except OSError:
                    pass

    def _read(self):
        try:
            if self.path.stat().st_size > _FV_MAX_BYTES:
                raise RuntimeError('收藏数据超过大小限制，已保留原文件')
            value = _fv_json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(value, dict) or value.get('schema') != 1 or not isinstance(value.get('items'), list) or len(value['items']) > _FV_MAX:
                raise RuntimeError('收藏数据格式异常，已保留原文件')
            return value
        except FileNotFoundError:
            return {'schema': 1, 'items': [], 'scheduler': {'status': 'not_configured', 'last_error': None}}
        except (ValueError, TypeError):
            raise RuntimeError('收藏数据无法读取，已保留原文件') from None

    def _write(self, value):
        if len(_fv_json.dumps(value, ensure_ascii=False).encode()) > _FV_MAX_BYTES:
            raise ValueError('收藏内容过多，已保留原记录')
        _fv_atomic(self.path, value)

    def _find(self, value, identifier):
        if not isinstance(identifier, str) or not _fv_re.fullmatch('[0-9a-f]{24}', identifier):
            raise ValueError('收藏标识无效')
        for item in value['items']:
            if item.get('id') == identifier:
                return item
        raise KeyError('该收藏已不存在')

    def list(self):
        with self._locked():
            value = self._read()
        items = sorted(value['items'], key=lambda x: (x.get('date', ''), x.get('created_at', '')))
        reminders = [x['reminder'] for x in items if x.get('reminder', {}).get('state') == 'scheduled']
        return {'schema': 1, 'items': [_fv_public(item) for item in items], 'count': len(items),
                'next_due': min((r['at'] for r in reminders), default=None),
                'scheduler': value.get('scheduler') or {},
                'capabilities': {'platform': self.platform, 'supported': self.platform == 'nt', 'popup': self.platform == 'nt', 'scheduler_available': self.platform == 'nt' and value.get('scheduler', {}).get('status') == 'ready', 'error': value.get('scheduler', {}).get('last_error'), 'native_popup': self.platform == 'nt',
                                 'sound': self.platform == 'nt', 'closed_window_reminder': self.platform == 'nt' and value.get('scheduler', {}).get('status') == 'ready',
                                 'timezone': 'Asia/Shanghai', 'note': _FV_NOTE}}

    def save(self, event):
        item = _fv_clean_event(event)
        now = _fv_stamp(self.clock())
        with self._locked():
            value = self._read()
            previous = next((x for x in value['items'] if x.get('id') == item['id']), None)
            if previous:
                item['created_at'] = previous.get('created_at', now)
                if 'reminder' in previous:
                    item['reminder'] = previous['reminder']
                value['items'] = [item if x.get('id') == item['id'] else x for x in value['items']]
            else:
                if len(value['items']) >= _FV_MAX:
                    raise ValueError('最多收藏500项，请先移除不需要的记录')
                item['created_at'] = now
                value['items'].append(item)
            item['updated_at'] = now
            self._write(value)
        return _fv_public(item)

    def remove(self, identifier):
        with self._locked():
            value = self._read()
            self._find(value, identifier)
            value['items'] = [x for x in value['items'] if x.get('id') != identifier]
            self._write(value)
        return {'removed': True, 'id': identifier}

    def remove_event_favorites(self,event_id):
        with self._locked():
            value=self._read();before=len(value['items'])
            value['items']=[item for item in value['items'] if item.get('event_id')!=event_id]
            removed=before-len(value['items'])
            if removed:self._write(value)
        return removed

    def remove_group_favorites(self,rule):
        with self._locked():
            value=self._read();before=len(value['items']);value['items']=[x for x in value['items']if not all(x.get(k)==v for k,v in rule.items())]
            if before!=len(value['items']):self._write(value)
        return before-len(value['items'])

    def set_reminder(self, identifier, beijing_datetime, channels=None):
        at = _fv_parse(beijing_datetime)
        now = self.clock().astimezone(_FV_BJ)
        if at <= now:
            raise ValueError('提醒时间必须晚于当前北京时间')
        if at > now + _fv_dt.timedelta(days=366 * 3):
            raise ValueError('提醒时间最多设置到三年内')
        channels = ['popup', 'sound'] if channels is None else channels
        if not isinstance(channels, list) or not channels or len(channels) > 2 or any(x not in ('popup', 'sound') for x in channels):
            raise ValueError('提醒方式只能选择弹窗或响铃')
        with self._locked():
            value = self._read()
            item = self._find(value, identifier)
            item['reminder'] = {'id': _fv_uuid.uuid4().hex, 'at': _fv_stamp(at), 'channels': sorted(set(channels)),
                                'state': 'scheduled', 'attempts': 0, 'created_at': _fv_stamp(now), 'last_error': None}
            item['updated_at'] = _fv_stamp(now)
            reminder_id = item['reminder']['id']
            self._write(value)
        # A reminder persists even when registration fails. Never claim closed-window
        # delivery unless Task Scheduler registration actually succeeded.
        status = self._ensure_scheduler()
        with self._locked():
            value = self._read()
            value['scheduler'] = status
            item = self._find(value, identifier)
            self._write(value)
            result = _fv_public(item)
        result['scheduler'] = status
        result['reminder_id'] = reminder_id
        return result

    def dismiss(self, identifier):
        with self._locked():
            value = self._read()
            item = self._find(value, identifier)
            if item.get('reminder'):
                item['reminder']['state'] = 'dismissed'
                item['reminder']['dismissed_at'] = _fv_stamp(self.clock())
            self._write(value)
        return _fv_public(item)

    def cancel_reminder(self, identifier):
        with self._locked():
            value = self._read()
            item = self._find(value, identifier)
            if item.get('reminder'):
                item['reminder']['state'] = 'cancelled'
                item['reminder']['cancelled_at'] = _fv_stamp(self.clock())
            self._write(value)
        return _fv_public(item)

    cancel = cancel_reminder

    def due(self, now=None):
        value_now = now or self.clock()
        now = value_now.astimezone(_FV_BJ) if isinstance(value_now, _fv_dt.datetime) else _fv_parse(value_now)
        claimed = []
        with self._locked():
            value = self._read()
            changed = False
            for item in value['items']:
                reminder = item.get('reminder') or {}
                state = reminder.get('state')
                if state == 'delivering':
                    leased = _fv_parse(reminder.get('claimed_at'))
                    if (now - leased).total_seconds() < 300:
                        continue
                    state = 'scheduled'
                if state != 'scheduled':
                    continue
                at = _fv_parse(reminder['at'])
                if at > now:
                    continue
                if now - at > _fv_dt.timedelta(hours=48):
                    reminder.update(state='missed', last_error='电脑恢复时已超过48小时补提醒窗口')
                    changed = True
                    continue
                if reminder.get('attempts', 0) >= 3:
                    reminder.update(state='failed', last_error='提醒进程未完成，已停止自动重试')
                    changed = True
                    continue
                reminder.update(state='delivering', claimed_at=_fv_stamp(now), attempts=reminder.get('attempts', 0) + 1)
                claimed.append(_fv_copy.deepcopy(item))
                changed = True
            if changed:
                self._write(value)
        return claimed

    def delivered(self, identifier, reminder_id, error=None):
        with self._locked():
            value = self._read()
            try:
                item = self._find(value, identifier)
            except KeyError:
                return False
            reminder = item.get('reminder') or {}
            if reminder.get('id') != reminder_id or reminder.get('state') not in (('delivering', 'fired') if error else ('delivering',)):
                return False
            reminder.update(state='failed' if error else 'fired', fired_at=_fv_stamp(self.clock()), last_error=str(error)[:200] if error else None)
            self._write(value)
        return True

    def _ensure_scheduler(self):
        if self.platform != 'nt':
            return {'status': 'unsupported', 'last_error': '当前不是Windows，未创建系统计划任务；收藏与提醒时间仍保留', 'note': _FV_NOTE}
        root = self.app_root
        executable = root / 'runtime' / 'pythonw.exe'
        if not executable.is_file():
            executable = _fv_Path(_fv_sys.executable)
        app = root / 'app.py'
        if not app.is_file() or not executable.is_file():
            return {'status': 'error', 'last_error': '未找到本日历的运行时，未创建计划任务', 'note': _FV_NOTE}
        arguments = _fv_subprocess.list2cmdline([str(app), '--reminder-worker', '--cache-dir', str(self.cache.resolve())])
        quote = lambda s: "'" + str(s).replace("'", "''") + "'"
        script = "\n".join([
            "$ErrorActionPreference='Stop'", "$s=New-Object -ComObject 'Schedule.Service'", "$s.Connect()", "$f=$s.GetFolder('\\')", "$t=$s.NewTask(0)",
            "$t.RegistrationInfo.Description='时序投资事件日历：个人日程与收藏提醒（仅本机）'", "$t.Principal.LogonType=3", "$t.Principal.RunLevel=0",
            "$t.Settings.Enabled=$true", "$t.Settings.StartWhenAvailable=$true", "$t.Settings.DisallowStartIfOnBatteries=$false", "$t.Settings.StopIfGoingOnBatteries=$false",
            "$t.Settings.WakeToRun=$false", "$t.Settings.MultipleInstances=0", "$t.Settings.ExecutionTimeLimit='PT30M'",
            "$g=$t.Triggers.Create(2)", "$g.StartBoundary=[DateTimeOffset]::Now.AddMinutes(1).ToString('yyyy-MM-ddTHH:mm:00zzz')", "$g.DaysInterval=1", "$g.Repetition.Interval='PT1M'", "$g.Repetition.Duration='P1D'",
            "$a=$t.Actions.Create(0)", "$a.Path="+quote(executable), "$a.Arguments="+quote(arguments), "$a.WorkingDirectory="+quote(root),
            "$null=$f.RegisterTaskDefinition("+quote(_FV_TASK)+",$t,6,$null,$null,3,$null)", "Write-Output 'WILLANCE_REMINDERS_REGISTERED'",
        ])
        try:
            result = self.runner(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script], text=True, capture_output=True, timeout=20, creationflags=getattr(_fv_subprocess, 'CREATE_NO_WINDOW', 0))
            if result.returncode != 0 or 'WILLANCE_REMINDERS_REGISTERED' not in (result.stdout or ''):
                raise RuntimeError('Windows未完成计划任务注册')
            return {'status': 'ready', 'task_name': _FV_TASK, 'registered_at': _fv_stamp(self.clock()), 'last_error': None, 'note': _FV_NOTE}
        except Exception as error:
            return {'status': 'error', 'last_error': str(error)[:200], 'note': _FV_NOTE}


def _fv_native_notify(items):
    import ctypes as _fv_ctypes
    import winsound as _fv_winsound
    sound = any('sound' in x['reminder'].get('channels', []) for x in items)
    popup = [x for x in items if 'popup' in x['reminder'].get('channels', [])]
    errors, completed = [], []
    # Each selected channel is attempted independently. A broken audio device
    # must not suppress the visual alert, and a failed popup is never success.
    if sound:
        try:
            _fv_winsound.MessageBeep(_fv_winsound.MB_ICONEXCLAMATION)
            completed.append('响铃已调用')
        except Exception:
            errors.append('响铃调用失败')
    if popup:
        try:
            lines = ['时序 · 日程提醒（北京时间）', '']
            for item in popup[:20]:
                lines += [item['title'], '提醒：' + item['reminder']['at'].replace('T', ' '), '事件：' + item['date'] + ' ' + item.get('time_display', ''), '']
            if len(popup) > 20:
                lines.append('另有' + str(len(popup)-20) + '项，请打开收藏栏查看。')
            result = _fv_ctypes.windll.user32.MessageBoxW(None, '\n'.join(lines), '时序 · 日程提醒', 0x00000040 | 0x00010000)
            if result == 0:
                code = _fv_ctypes.windll.kernel32.GetLastError()
                raise OSError(code, 'Windows未显示提醒弹窗')
            completed.append('弹窗已显示')
        except Exception:
            errors.append('弹窗显示失败')
    if errors:
        raise RuntimeError('；'.join(completed + errors))


def run_reminder_worker(cache_dir, app_root=None, *, notifier=None, platform=None, clock=None, personal_store=None):
    store = FavoritesStore(cache_dir, app_root=app_root, platform=platform, clock=clock)
    if store.platform != 'nt' and notifier is None:
        return {'claimed': 0, 'delivered': 0, 'status': 'unsupported'}
    stores=[store]+([personal_store] if personal_store is not None else [])
    claimed=[];attempted=False;failed_stores=0
    for owner in stores:
        try:due=owner.due()
        except (RuntimeError,OSError,ValueError):failed_stores+=1;continue
        attempted=attempted or bool(due)
        for item in due:
            removed=False
            if owner is store and personal_store is not None:
                try:removed=personal_store.source_is_removed(item.get('event_id'),item)
                except (RuntimeError,OSError,ValueError):pass
            if removed:
                store.dismiss(item['id']);continue
            if owner.delivered(item['id'],item['reminder']['id']):claimed.append((owner,item))
    if not claimed:
        return {'claimed': 0, 'delivered': 0, 'status': 'error' if failed_stores else 'cancelled' if attempted else 'idle'}
    try:
        (notifier or _fv_native_notify)([item for owner,item in claimed])
        return {'claimed': len(claimed), 'delivered': len(claimed), 'status': 'partial' if failed_stores else 'notified','unreadable_stores':failed_stores}
    except Exception as error:
        for owner,item in claimed:owner.delivered(item['id'],item['reminder']['id'],error)
        return {'claimed': len(claimed), 'delivered': 0, 'status': 'error'}

# END FAVORITES

# BEGIN ALMANAC (mirrors almanac.py)
"""Chinese seasonal/time culture with separately sourced astronomical windows."""
import datetime as _ac_dt
import json as _ac_json
from pathlib import Path as _ac_Path
_AC_BJ=_ac_dt.timezone(_ac_dt.timedelta(hours=8))
_AC_TERMS={
'立春':('春季开始的节气，太阳黄经315°；不等同于当地气温立刻回暖。','整理年度目标、记录季节变化','不宜把季节交替当作行情必然转折'),
'雨水':('太阳黄经330°，传统反映中原降水增多、冰雪渐融。','检查出行安排、整理雨具','不宜忽略当地实际天气'),
'惊蛰':('太阳黄经345°，传统以春雷和昆虫活动象征生机。','启动春季整理、复核计划','不宜把民俗象征视作因果预测'),
'春分':('太阳黄经0°，北半球昼夜长度接近相等。','盘点季度进度、安排户外观察','不宜把昼夜平分理解为所有地点完全相同'),
'清明':('太阳黄经15°，兼具节气与传统节日意义。','文明祭扫、安排踏青','不宜忽略山林防火规定'),
'谷雨':('太阳黄经30°，传统强调春季降雨与谷物生长。','整理春季事项、关注降雨预报','不宜照搬古代农事到所有地区'),
'立夏':('太阳黄经45°，传统夏季的起点。','整理夏季出行与工作安排','不宜仅凭节气判断当地已经入夏'),
'小满':('太阳黄经60°，传统指夏熟作物籽粒渐满。','检查上半年目标、留出调整余地','不宜因为临近年中而仓促追赶计划'),
'芒种':('太阳黄经75°，名称与有芒作物的收种有关。','分清轻重缓急、整理待办','不宜让过多并行事项挤占关键任务'),
'夏至':('太阳黄经90°，北半球白昼在一年中接近最长。','记录半年进度、安排季节观察','不宜把天文白昼时长当作市场规律'),
'小暑':('太阳黄经105°，传统表示暑热渐盛。','检查夏季设备与出行计划','不宜忽略当地高温预警'),
'大暑':('太阳黄经120°，传统反映一年中炎热时段。','把室外活动安排与天气预报结合','不宜机械套用古代地域气候'),
'立秋':('太阳黄经135°，传统秋季开始，实际仍可能炎热。','整理下半年目标','不宜把立秋当作当地必然降温日'),
'处暑':('太阳黄经150°，“处”含结束、停止之意，传统表示暑热渐退。','复盘夏季安排、准备秋季事项','不宜忽略持续高温的实际情况'),
'白露':('太阳黄经165°，传统反映气温变化与露水增多。','关注昼夜温差、检查秋季出行安排','不宜将物候描述视为全国统一天气'),
'秋分':('太阳黄经180°，北半球昼夜时长接近相等。','盘点第三季度、整理四季度计划','不宜把节气与投资涨跌机械关联'),
'寒露':('太阳黄经195°，传统描述露水转寒、秋意渐深。','整理秋冬用品、核对出行天气','不宜仅凭节气代替当地预报'),
'霜降':('太阳黄经210°，秋季最后一个节气；名字反映中原传统物候。','收尾秋季事项、准备年末复盘','不宜认为全国都会在当天出现初霜'),
'立冬':('太阳黄经225°，传统冬季开始；天文节气与气象入冬标准不同。','整理年末计划、检查冬季出行准备','不宜仅凭节气判断各地实际温度'),
'小雪':('太阳黄经240°，传统描述冷空气增强、降雪可能增加。','检查冬季设备、关注交通天气','不宜把名称理解为当天必定下雪'),
'大雪':('太阳黄经255°，传统表示降雪可能性进一步增加。','提前安排冬季出行、整理年度资料','不宜忽略交通与天气预警'),
'冬至':('太阳黄经270°，北半球白昼接近全年最短。','年末复盘、安排家庭团聚','不宜将“阴极阳生”的文化说法当作收益保证'),
'小寒':('太阳黄经285°，传统反映寒冷时段。','核对新年安排、留意天气预报','不宜照搬某一地区的气候到所有城市'),
'大寒':('太阳黄经300°，传统二十四节气的最后一节。','整理旧账、准备新一轮年度计划','不宜把文化周期视作确定交易时点')}
_AC_HOURS=[('子','夜半',23,1),('丑','鸡鸣',1,3),('寅','平旦',3,5),('卯','日出',5,7),('辰','食时',7,9),('巳','隅中',9,11),('午','日中',11,13),('未','日昳',13,15),('申','晡时',15,17),('酉','日入',17,19),('戌','黄昏',19,21),('亥','人定',21,23)]
def almanac_bundle(root):
 try:
  p=_ac_Path(root)/'branding/almanac-v18.json'
  if p.stat().st_size>250000: return {}
  d=_ac_json.loads(p.read_text(encoding='utf-8'));return d if d.get('schema')==1 else {}
 except (OSError,ValueError,TypeError):return {}
def cultural_enrich(events):
 for e in events:
  term=next((x for x in _AC_TERMS if e.get('category')=='season' and x in e.get('title','')),None)
  if term:
   meaning,yes,no=_AC_TERMS[term]
   e['culture']={'term':term,'meaning':meaning,'suitable':yes,'avoid':no,'basis':'节气文化与现代生活提示；不是每日黄历吉凶或金融预测。','source_url':'https://www.hko.gov.hk/sc/gts/time/24solarterms.htm'}
 return events
def cultural_events(root):
 data=almanac_bundle(root);out=list(data.get('astronomy_events',[]))
 for t in data.get('solar_terms',[]):
  out.append({'id':'jpl-season-'+t['date']+'-'+t['name'],'category':'season','market':'历法','title':t['name'],'date':t['date'],'time':t['start_at'][11:16],'start_at':t['start_at'],'end_at':t['end_at'],'time_precision':'window','time_display':t['start_at'][11:16]+'–'+t['end_at'][11:16]+' · 星历计算时段','timezone':'Asia/Shanghai','source_url':t['source_url'],'source_name':'NASA/JPL太阳黄经计算','status':'confirmed','details':{'口径':'地心视黄经小时采样；显示覆盖交点的一小时时段，不冒充官方分秒预报。'}})
 return out
def current_almanac(root,day=None,now=None):
 now=now or _ac_dt.datetime.now(_AC_BJ)
 if now.tzinfo is None:raise ValueError('需要带时区的时间')
 now=now.astimezone(_AC_BJ);day=day or now.date().isoformat();_ac_dt.date.fromisoformat(day)
 idx=((now.hour+1)//2)%12;h=_AC_HOURS[idx];data=almanac_bundle(root);terms=data.get('solar_terms',[])
 terms=terms if data.get('range',[day,day])[0]<=day<=data.get('range',[day,day])[1] else []
 prev=[x for x in terms if x['date']<=day];nxt=next((x for x in terms if x['date']>day),None);term=prev[-1] if prev else None
 return {'date':day,'now_beijing':now.isoformat(timespec='seconds'),'hour':{'name':h[0]+'时','traditional_name':h[1],'range':f'{h[2]:02}:00–{h[3]:02}:00','index':idx},'hours':[{'name':x[0]+'时','traditional_name':x[1],'range':f'{x[2]:02}:00–{x[3]:02}:00'} for x in _AC_HOURS],'season':({'name':term['name'],**dict(zip(('meaning','suitable','avoid'),_AC_TERMS[term['name']]))} if term else None),'next_term':nxt,'astronomy':[e for e in data.get('astronomy_events',[]) if e['date']==day],'range':data.get('range'),'note':'时辰按北京时间划分，子时跨日但本应用民用日期仍在00:00切换；文化解读与经济数据分析分开展示。'}

# END ALMANAC

# BEGIN ECONOMIC LIVE (mirrors economic_live.py)
"""On-demand official macro releases, separately attributed corroboration and analysis."""
import collections as _ec_collections
import copy as _ec_copy
import datetime as _ec_dt
import hashlib as _ec_hash
import html as _ec_html
import json as _ec_json
import math as _ec_math
import re as _ec_re
import threading as _ec_thread
import time as _ec_time
import urllib.parse as _ec_parse
import urllib.request as _ec_request
import xml.etree.ElementTree as _ec_et
from html.parser import HTMLParser as _ec_HTMLParser
from email.utils import parsedate_to_datetime as _ec_feeddate
from pathlib import Path as _ec_Path
from concurrent.futures import ThreadPoolExecutor as _ec_Pool
_EC_UTC=_ec_dt.timezone.utc;_EC_BJ=_ec_dt.timezone(_ec_dt.timedelta(hours=8))
_EC_HOSTS={'www.stats.gov.cn','www.bls.gov','www.bea.gov','bea.gov','apps.bea.gov','api.eqn.news'}
_EC_NBS='https://www.stats.gov.cn/sj/zxfb/'
_EC_SPEC={
 'cn_cpi':('居民消费价格',r'居民消费价格|CPI','需求与通胀','CPI'),
 'cn_ppi':('工业生产者价格',r'工业生产者|PPI','工业价格与利润','PPI'),
 'cn_pmi':('采购经理指数',r'采购经理|PMI','景气与需求','中国PMI'),
 'cn_industry':('工业增加值',r'工业增加值|规模以上工业生产','生产与盈利','工业增加值'),
 'cn_retail':('社会消费品零售',r'零售|社会消费','消费与盈利','零售'),
 'cn_gdp':('国内生产总值',r'国内生产总值|GDP|经济运行|季度主要行业增加值','增长与政策','中国GDP'),
 'cn_profit':('工业企业利润',r'工业企业利润|工业经济效益','企业盈利','工业企业利润'),
 'cn_investment':('固定资产投资',r'固定资产投资','投资与需求','固定资产投资'),
 'us_cpi':('Consumer Price Index',r'CPI|消费者价格|Consumer Price Index','通胀与利率','美国CPI'),
 'us_payroll':('Employment Situation',r'非农|就业形势|Employment Situation','就业与利率','非农'),
 'us_pce':('Personal Income and Outlays',r'PCE|个人收入与支出|Personal Income and Outlays','通胀与消费','PCE'),
 'us_gdp':('Gross Domestic Product',r'GDP|国内生产总值|Gross Domestic Product','增长与利率','美国GDP'),
 'us_ppi':('Producer Price Index',r'PPI|生产者价格|Producer Price Index','上游通胀与利率','美国PPI'),
 'us_jolts':('Job Openings',r'JOLTS|职位空缺|Job Openings','劳动力需求','美国职位空缺'),
 'us_eci':('Employment Cost Index',r'就业成本|Employment Cost Index','薪资与通胀','就业成本')}
_EC_BLS={'us_cpi':'cpi','us_payroll':'empsit','us_ppi':'ppi','us_jolts':'jolts','us_eci':'eci'}
_EC_MONTHS={name:i for i,name in enumerate(('January','February','March','April','May','June','July','August','September','October','November','December'),1)}
def economic_kind(event):
 if not isinstance(event,dict) or event.get('category')!='macro':return None
 title=str(event.get('title')or'')
 if _ec_re.search('FOMC|美联储',title,_ec_re.I):return None
 country='cn' if event.get('market') in ('中国','A股') or title.startswith('中国') else 'us' if event.get('market') in ('美国','美股') or title.startswith('美国') else None
 for key,(_,pattern,_,_) in _EC_SPEC.items():
  if key.startswith(str(country)+'_') and _ec_re.search(pattern,title,_ec_re.I):return key
 return None
def _ec_now():return _ec_dt.datetime.now(_EC_UTC).isoformat(timespec='seconds')
def _ec_date(value):
 try:
  d=_ec_dt.datetime.fromisoformat(str(value).replace('Z','+00:00'));return d if d.tzinfo else None
 except (ValueError,TypeError):return None
def _ec_text(raw):
 raw=_ec_re.sub(r'<(?:script|style)\b.*?</(?:script|style)>','',raw,flags=_ec_re.I|_ec_re.S)
 return _ec_html.unescape(_ec_re.sub('<[^>]*>',' ',raw)).replace('\xa0',' ')
class _ec_Redirect(_ec_request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  p=_ec_parse.urlsplit(newurl)
  if p.scheme!='https' or p.hostname not in _EC_HOSTS or p.username or p.password or p.port not in(None,443):raise ValueError('来源跳转不在官方白名单')
  return super().redirect_request(req,fp,code,msg,headers,newurl)
def _ec_fetch(url):
 p=_ec_parse.urlsplit(url)
 if p.scheme!='https' or p.hostname not in _EC_HOSTS or p.username or p.password or p.port not in(None,443):raise ValueError('来源地址不在内置白名单')
 req=_ec_request.Request(url,headers={'User-Agent':'ShixuCalendar/1.10 (+https://github.com/cf377695951/shixu-releases)','Accept':'application/json,text/html,application/xml'})
 with _ec_request.build_opener(_ec_Redirect()).open(req,timeout=18) as response:
  if _ec_parse.urlsplit(response.url).hostname not in _EC_HOSTS:raise ValueError('来源跳转未授权')
  raw=response.read(1800001)
  if len(raw)>1800000:raise ValueError('来源正文过大')
  return raw.decode('utf-8-sig','replace')
def _ec_base(event):
 kind=economic_kind(event)
 if not kind:raise ValueError('当前指标尚未接入数值源')
 return {'schema':1,'status':'partial','event_kind':kind,'schedule':{'date':event['date'],'label':event.get('time_display')or event.get('time'),'start_at':event.get('start_at')},'metrics':[],'summary':None,'stance':{'label':'等待数据','basis':'公布值与预期/前值按同期间、同单位比较；不把增长信号直接等同于资产必涨跌。','evidence':[]},'impact_scenarios':[],'focus_points':[],'articles':[],'official_sources':[],'source_status':{},'verification':'尚未取得匹配结果','checked_at':None,'last_success_at':None,'error':None,'data_stale':False,'analysis':[],'preview':[]}
def economic_source_plan(event,result=None):
 kind=economic_kind(event);status=(result or {}).get('source_status',{});rows=(result or {}).get('metrics',[])
 if not kind:return []
 primary=('国家统计局','https://www.stats.gov.cn/sj/zxfb/')if kind.startswith('cn_')else('美国劳工统计局 BLS','https://www.bls.gov/news.release/')if kind in _EC_BLS else('美国经济分析局 BEA','https://www.bea.gov/news/current-releases')
 primary_status='cached'if(result or{}).get('status')=='offline'or(result or{}).get('distribution_snapshot')else status.get('official',{}).get('status','cached'if rows else'waiting')
 return [{'name':primary[0],'url':primary[1],'role':'实际公布值 · 第一来源','access':'公开网页 / RSS，无需Token','status':primary_status},{'name':'方程式公开快讯 / RSS','url':'https://eqn.news/','role':'市场预期与报道核对 · 辅助来源','access':'免费公开入口','status':status.get('news',{}).get('status','waiting')}]
def _ec_num(text):
 try:
  n=float(str(text).replace(',',''));return n if _ec_math.isfinite(n) else None
 except (ValueError,TypeError):return None
def _ec_metric(key,label,value,unit,url,published,period):
 return {'key':key,'label':label,'actual':value,'expected':None,'previous':None,'unit':unit,'period':period,'source_url':url,'source_name':'国家统计局' if 'stats.gov.cn' in url else '美国官方统计','asof':published,'verification':'官方已核验','corroboration':[]}
class _ec_Tables(_ec_HTMLParser):
 """Retain cell boundaries so a quarterly GDP value cannot become a cumulative one."""
 def __init__(self):super().__init__(convert_charrefs=True);self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,tag,attrs):
  if tag=='tr':self.row=[]
  elif tag in('th','td')and self.row is not None:self.cell=[]
 def handle_data(self,text):
  if self.cell is not None:self.cell.append(text)
 def handle_endtag(self,tag):
  if tag in('th','td')and self.cell is not None:
   self.row.append(_ec_re.sub(r'\s+',' ',''.join(self.cell)).strip());self.cell=None
  elif tag=='tr'and self.row is not None:self.rows.append(self.row);self.row=None;self.cell=None
def _ec_localday(event):
 instant=_ec_date(event.get('start_at'))
 day=_ec_dt.date.fromisoformat(event['date'])
 if not instant:return day
 utc=instant.astimezone(_EC_UTC);year=utc.year
 if year<2007:raise ValueError('美东历史日期规则未支持')
 march=_ec_dt.date(year,3,1);nov=_ec_dt.date(year,11,1)
 start=_ec_dt.datetime.combine(march+_ec_dt.timedelta(days=(6-march.weekday())%7+7),_ec_dt.time(7),_EC_UTC)
 end=_ec_dt.datetime.combine(nov+_ec_dt.timedelta(days=(6-nov.weekday())%7),_ec_dt.time(6),_EC_UTC)
 return utc.astimezone(_ec_dt.timezone(_ec_dt.timedelta(hours=-4 if start<=utc<end else-5))).date()
def _ec_release_day(raw):
 # A date in a next-release sentence or footer must never validate old figures.
 for pattern in (r'<time\b[^>]*datetime=["\']([^"\']+)',r'<meta\b[^>]*(?:property|name)=["\'](?:article:published_time|dcterms.issued|datePublished)["\'][^>]*content=["\']([^"\']+)'):
  m=_ec_re.search(pattern,raw,_ec_re.I)
  if m:
   try:return _ec_dt.date.fromisoformat(m[1][:10])
   except ValueError:pass
 text=_ec_re.sub(r'\s+',' ',_ec_text(raw))
 embargo=_ec_re.search(r'Transmission of material.{0,140}?(?:embargoed until|release until)(.{0,220})',text,_ec_re.I)
 bea_date=_ec_re.search(r'<[^>]+class=["\'][^"\']*field--name-field-release-date[^"\']*["\'][^>]*>(.*?)</[^>]+>',raw,_ec_re.I|_ec_re.S)
 header=_ec_text(bea_date[1])if bea_date else embargo[1]if embargo else text[:200]
 m=_ec_re.search(r'\b('+'|'.join(_EC_MONTHS)+r')\s+(\d{1,2}),?\s+(20\d{2})\b',header,_ec_re.I)
 if not m:return None
 if not embargo and not bea_date and _ec_re.search(r'next\s+release|scheduled|last\s+modified',header[:m.start()],_ec_re.I):return None
 try:return _ec_dt.date(int(m[3]),_EC_MONTHS[m[1].title()],int(m[2]))
 except(ValueError,KeyError):return None
def _ec_title_match(kind,title,event=None):
 if not _ec_re.search(_EC_SPEC[kind][1],title,_ec_re.I):return False
 if kind=='us_gdp'and _ec_re.search(r'county|puerto rico|by state|by industry|GDP and Personal Income',title,_ec_re.I):return False
 if kind=='us_gdp'and event:
  estimate=_ec_re.search(r'(Advance|Second|Third)\s+Estimate',str(event.get('title','')),_ec_re.I)
  if estimate and not _ec_re.search(estimate[1]+r'\s+Estimate',title,_ec_re.I):return False
 return True
def _ec_us_parse(event,url,raw,title=''):
 kind=economic_kind(event);day=_ec_localday(event);instant=_ec_date(event.get('start_at'));now=_ec_date(_ec_now())
 if day>now.astimezone(_EC_BJ).date()or instant and instant>now:return []
 if _ec_release_day(raw)!=day:return []
 page_title=_ec_re.search(r'<title[^>]*>(.*?)</title>',raw,_ec_re.I|_ec_re.S)
 heading=_ec_re.search(r'<h1[^>]*>(.*?)</h1>',raw,_ec_re.I|_ec_re.S)
 headline=_ec_text(page_title[1]if page_title else heading[1]if heading else title)
 if headline and not _ec_title_match(kind,headline,event):return []
 main=_ec_re.search(r'<pre\b[^>]*>(.*?)</pre>',raw,_ec_re.I|_ec_re.S)
 text=_ec_re.sub(r'\s+',' ',_ec_text(main[1]if main else raw))
 number=r'(-?\d+(?:\.\d+)?)';verb=r'(increased|rose|grew|advanced|climbed|moved up|decreased|declined|fell|dropped|contracted)'
 specs={
  'us_cpi':[
   ('cpi_yoy','CPI同比',[r'(?:Over|For) the (?:last|past) 12 months,? (?:the )?all.items index '+verb+r' '+number+r' percent',r'(?:the )?all.items index '+verb+r' '+number+r' percent (?:over|for) the (?:last )?12 months'],'%'),
   ('cpi_mom','CPI环比（季调）',[r'Consumer Price Index for All Urban Consumers \(CPI-U\) '+verb+r' '+number+r' percent on a seasonally adjusted basis'],'%'),
   ('core_cpi_yoy','核心CPI同比',[r'all items less food and energy index '+verb+r' '+number+r' percent over the (?:past 12 months|year)'],'%'),
   ('core_cpi_mom','核心CPI环比（季调）',[r'index for all items less food and energy '+verb+r' '+number+r' percent in [A-Z][a-z]+'],'%')],
  'us_payroll':[
   ('payroll_change','非农就业变动',[r'(?:Total )?nonfarm payroll employment '+verb+r' (?:by )?(-?\d[\d,]*)'],'人'),
   ('unemployment','失业率',[r'unemployment rate (?:was |held |remained |changed little )?(?:unchanged |steady )?(?:at )?()'+number+r' percent'],'%')],
  'us_ppi':[
   ('ppi_mom','PPI最终需求环比（季调）',[r'Producer Price Index for final demand '+verb+r' '+number+r' percent'],'%'),
   ('ppi_yoy','PPI最终需求同比',[r'index for final demand '+verb+r' '+number+r' percent for the 12 months'],'%')],
  'us_jolts':[('job_openings','职位空缺',[r'number of job openings.{0,100}?(?:at |to |was )()'+number+r' million'],'百万人')],
  'us_eci':[
   ('eci_qoq','就业成本环比（季调）',[r'Compensation costs for civilian workers '+verb+r' '+number+r' percent.{0,65}?3.month'],'%'),
   ('eci_yoy','就业成本同比',[r'Compensation costs for civilian workers '+verb+r' '+number+r' percent.{0,65}?12.month'],'%')],
  'us_gdp':[('gdp_annualized','实际GDP环比年化',[r'(?:Real gross domestic product(?: \(GDP\))?|Real GDP) '+verb+r' at an annual rate of '+number+r' percent'],'%')],
  'us_pce':[
   ('pce_mom','PCE物价环比',[r'(?:From the preceding month|From the previous month).{0,100}?PCE price index(?: for [A-Z][a-z]+)? '+verb+r' '+number+r' percent'],'%'),
   ('core_pce_mom','核心PCE物价环比',[r'(?:From the preceding month|From the previous month).{0,200}?Excluding food and energy,? the PCE price index '+verb+r' '+number+r' percent'],'%'),
   ('pce_yoy','PCE物价同比',[r'(?:From|Compared with) (?:the )?(?:same )?(?:month )?one year ago.{0,100}?PCE price index(?: for [A-Z][a-z]+)? '+verb+r' '+number+r' percent'],'%'),
   ('core_pce_yoy','核心PCE物价同比',[r'(?:From|Compared with) (?:the )?(?:same )?(?:month )?one year ago.{0,240}?Excluding food and energy,? the PCE price index '+verb+r' '+number+r' percent'],'%')]}
 rows=[];period=headline or title or day.isoformat()
 quarter=_ec_re.search(r'([1-4])(?:st|nd|rd|th)?\s+Quarter\s+(20\d{2})',period,_ec_re.I)
 month=_ec_re.search(r'\b('+'|'.join(_EC_MONTHS)+r')\s+(20\d{2})\b',period,_ec_re.I)
 numeric_month=_ec_re.search(r'(20\d{2})\s+M(0[1-9]|1[0-2])',period,_ec_re.I)
 if quarter:period=quarter[2]+'年第'+quarter[1]+'季度'
 elif month:period=month[2]+'年'+str(_EC_MONTHS[month[1].title()])+'月'
 elif numeric_month:period=numeric_month[1]+'年'+str(int(numeric_month[2]))+'月'
 for code,label,patterns,unit in specs.get(kind,[]):
  for pattern in patterns:
   match=_ec_re.search(pattern,text,_ec_re.I)
   if not match:continue
   value=_ec_num(match[2])
   if value is None:continue
   if match[1].lower()in('decreased','declined','fell','dropped','contracted'):value=-abs(value)
   row=_ec_metric(code,label,value,unit,url,instant.isoformat()if instant else day.isoformat(),period)
   row['source_name']='美国劳工统计局 BLS'if kind in _EC_BLS else'美国经济分析局 BEA';rows.append(row);break
 return rows
def _ec_nbs_parse(event,url,raw):
 """Exact release-day + indicator matching; cumulative/monthly labels stay distinct."""
 kind=economic_kind(event);key=url.split('/')[-1]
 match=_ec_re.search(r't(20\d{6})_',key)
 if not match or match[1]!=event['date'].replace('-',''):return []
 titlematch=_ec_re.search(r'<title>(.*?)</title>',raw,_ec_re.I|_ec_re.S)
 title=_ec_text(titlematch[1]) if titlematch else ''
 if not _ec_re.search(_EC_SPEC[kind][1],title,_ec_re.I):return []
 body=_ec_re.search(r'<div[^>]+class=["\'][^"\']*TRS_Editor[^"\']*["\'][^>]*>(.*?)</div>',raw,_ec_re.S|_ec_re.I)
 text=_ec_text(body[1] if body else raw);text=_ec_re.sub(r'\s+',' ',text)
 date=_ec_re.search(r'(20\d{2})[/-](\d{2})[/-](\d{2})\s+(\d{2}):(\d{2})',_ec_text(raw))
 published='-'.join(date.group(i) for i in (1,2,3))+'T'+date[4]+':'+date[5]+':00+08:00' if date else event['date']
 instant=_ec_date(published);scheduled=_ec_date(event.get('start_at'))
 now=_ec_date(_ec_now())
 if instant and instant>now or scheduled and scheduled>now:return []
 period=_ec_re.search(r'202\d年[^。]{0,12}(?:月份|季度)',title);period=period[0] if period else title[:60]
 specs={
 'cn_cpi':[('cpi_yoy','CPI同比',r'(?:全国)?居民消费价格同比(上涨|下降|增长|回落)?\s*(-?\d+(?:\.\d+)?)%','%'),('core_cpi_yoy','核心CPI同比',r'核心CPI同比(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')],
 'cn_ppi':[('ppi_yoy','PPI同比',r'工业生产者出厂价格同比(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')],
 'cn_industry':[('industry_yoy','规上工业增加值同比',r'规模以上工业增加值同比(?:实际)?(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')],
 'cn_retail':[('retail_ytd','社会消费品零售额累计同比',r'社会消费品零售总额[^。]{0,55}?同比(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')],
 'cn_profit':[('profit_ytd','规上工业企业利润累计同比',r'利润总额[^。]{0,65}?同比(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')],
 'cn_investment':[('investment_ytd','固定资产投资累计同比',r'固定资产投资[^。]{0,75}?(?:同比|比上年同期)(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')],
 'cn_pmi':[('manufacturing_pmi','制造业PMI',r'(?<!非)制造业采购经理指数[（(]PMI[)）]为()\s*(\d+(?:\.\d+)?)%','点'),('non_manufacturing_pmi','非制造业商务活动指数',r'非制造业商务活动指数为()\s*(\d+(?:\.\d+)?)%','点')],
 'cn_gdp':[('gdp_yoy','GDP同比（按原文期间）',r'(?:国内生产总值|GDP)[^。]{0,110}?(?:同比|比上年同期)(上涨|下降|增长)?\s*(-?\d+(?:\.\d+)?)%','%')]}
 rows=[]
 for code,label,pattern,unit in specs.get(kind,[]):
  m=_ec_re.search(pattern,text,_ec_re.I)
  if not m:continue
  value=_ec_num(m[2]);value=-abs(value) if m[1] in ('下降','回落') else value
  if '累计同比' in label and not _ec_re.search(r'\d+[—–-]\d+月',period):label=label.replace('累计同比','当月同比')
  rows.append(_ec_metric(code,label,value,unit,url,published,period))
 if kind=='cn_gdp'and not rows and 'GDP初步核算数据'in text.replace(' ','')and '比上年同期增长'in text:
  table=_ec_Tables();table.feed(raw)
  for cells in table.rows:
   if len(cells)!=5 or cells[0].strip()!='GDP':continue
   values=[_ec_num(x)for x in cells[1:]]
   if any(x is None for x in values):continue
   quarter=_ec_re.search(r'(20\d{2})年([一二三四])季度',title)
   if not quarter:continue
   prefix=quarter[1]+'年';q=quarter[2]
   rows=[_ec_metric('gdp_quarter_yoy','GDP当季同比',values[2],'%',url,published,prefix+q+'季度'),_ec_metric('gdp_ytd','GDP累计同比',values[3],'%',url,published,prefix+('一季度'if q=='一'else'上半年'if q=='二'else'前三季度'if q=='三'else'全年'))];break
 return rows
class _ec_Client:
 def __init__(self,news_client=None):self.news_client=news_client;self._lock=_ec_thread.Lock();self._indexes={}
 def _index(self,url,ttl=300):
  with self._lock:cached=self._indexes.get(url)
  if cached and _ec_time.monotonic()-cached[0]<ttl:return cached[1]
  raw=_ec_fetch(url)
  with self._lock:self._indexes[url]=(_ec_time.monotonic(),raw)
  return raw
 def official(self,event):
  kind=economic_kind(event);instant=_ec_date(event.get('start_at'));now=_ec_date(_ec_now())
  if instant and instant>now:return [],[],{'status':'awaiting_release','coverage':'尚未到官方安排的公布时间，不提前填公布值','url':_EC_NBS if kind.startswith('cn_')else'https://www.bls.gov/news.release/'if kind in _EC_BLS else'https://www.bea.gov/news/current-releases'}
  if kind.startswith('cn_'):
   candidates=[];errors=[]
   for page in range(3):
    index=_EC_NBS if page==0 else _EC_NBS+'index_'+str(page)+'.html'
    try:raw=self._index(index)
    except Exception as error:errors.append(str(error)[:120]);continue
    for href,inner in _ec_re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',raw,_ec_re.S|_ec_re.I):
     title=_ec_text(inner).strip();url=_ec_parse.urljoin(_EC_NBS,_ec_html.unescape(href))
     if _ec_parse.urlsplit(url).hostname=='www.stats.gov.cn'and event['date'].replace('-','')in url and _ec_title_match(kind,title,event)and url not in candidates:candidates.append(url)
    if candidates:break
   rows=[];articles=[]
   for url in candidates[:2]:
    try:
     text=_ec_fetch(url);found=_ec_nbs_parse(event,url,text)
     if found:
      rows.extend(x for x in found if not any(x['key']==r['key']for r in rows));articles.append({'title':_ec_text((_ec_re.search(r'<title>(.*?)</title>',text,_ec_re.S|_ec_re.I)or['','官方发布'])[1]),'url':url,'source_name':'国家统计局','published_at':found[0]['asof'],'kind':'official'})
    except Exception as error:errors.append(str(error)[:120])
   return rows,articles,{'status':'ok'if rows else'error'if errors else'unmatched','coverage':'国家统计局发布列表及前两页历史记录；只认本次发布日期、指标与报告期','url':_EC_NBS,'message':'；'.join(errors[:2])or None}
  return self.us_official(event)
 def us_official(self,event):
  kind=economic_kind(event);day=_ec_localday(event);urls=[];titles={};errors=[];articles=[]
  if kind in _EC_BLS:
   code=_EC_BLS[kind]
   urls=['https://www.bls.gov/news.release/'+code+'.nr0.htm','https://www.bls.gov/news.release/archives/'+code+'_'+day.strftime('%m%d%Y')+'.htm']
   feed='https://www.bls.gov/feed/'+code+'.rss'
  else:
   feed='https://apps.bea.gov/rss/rss.xml'
   try:
    raw=self._index('https://www.bea.gov/news/current-releases')
    for href,inner in _ec_re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',raw,_ec_re.S|_ec_re.I):
     title=_ec_text(inner).strip();url=_ec_parse.urljoin('https://www.bea.gov',_ec_html.unescape(href))
     if _ec_parse.urlsplit(url).hostname in('www.bea.gov','bea.gov')and '/news/'+str(day.year)+'/'in url and _ec_title_match(kind,title,event)and url not in urls:urls.append(url);titles[url]=title
   except Exception as error:errors.append(str(error)[:120])
  def read_candidates(candidates):
   for url in candidates[:3]:
    try:
     raw=_ec_fetch(url);rows=_ec_us_parse(event,url,raw,titles.get(url,''))
     if rows:
      title=_ec_text((_ec_re.search(r'<title[^>]*>(.*?)</title>',raw,_ec_re.S|_ec_re.I)or['',titles.get(url,_EC_SPEC[kind][0])])[1]);articles.append({'title':title[:200],'url':url,'source_name':rows[0]['source_name'],'published_at':rows[0]['asof'],'kind':'official'});return rows
    except Exception as error:errors.append(str(error)[:120])
   return []
  rows=read_candidates(urls)
  if not rows:
   feed_urls=[]
   try:
    raw=self._index(feed,120)
    if '<!ENTITY'in raw.upper()or'<!DOCTYPE'in raw.upper():raise ValueError('RSS实体声明不受支持')
    root=_ec_et.fromstring(raw)
    for item in root.findall('.//item')[:30]:
     title=item.findtext('title')or'';link=item.findtext('link')or''
     if not _ec_title_match(kind,title,event)or _ec_parse.urlsplit(link).hostname not in _EC_HOSTS or link in urls:continue
     try:published=_ec_feeddate(item.findtext('pubDate')or'').date()
     except(ValueError,TypeError):published=None
     if published and abs((published-day).days)>1:continue
     titles[link]=title
     if link not in feed_urls:feed_urls.append(link)
    rows=read_candidates(feed_urls)
   except Exception as error:errors.append(str(error)[:120])
  status={'status':'ok'if rows else'error'if errors else'unmatched','url':'https://www.bls.gov/news.release/'if kind in _EC_BLS else'https://www.bea.gov/news/current-releases','coverage':'官网正式正文 + 日期归档/RSS备用入口；只匹配本次发布，不拿下次发布日期或历史修订值冒充','message':'；'.join(errors[:2])or None}
  return rows,articles,status
 def news(self,event):
  warning=None
  if self.news_client is not None:
   try:
    value=self.news_client._mcp('list_news',{'channel':'tradfi','query':_EC_SPEC[economic_kind(event)][3],'limit':30})
    return value.get('items',[]),{'status':'ok','coverage':'免费财经快讯：预期与辅助核对，公布值优先官网','transport':'MCP'}
   except Exception as error:warning=str(error)[:120]
  try:
   raw=self._index('https://api.eqn.news/public/rss?ch=tradfi&lang=zh',60)
   if '<!ENTITY'in raw.upper()or'<!DOCTYPE'in raw.upper():raise ValueError('RSS实体声明不受支持')
   root=_ec_et.fromstring(raw);items=[]
   for item in root.findall('.//item')[:60]:
    text=_ec_text(item.findtext('description')or item.findtext('title')or'')
    if not _ec_re.search(_EC_SPEC[economic_kind(event)][1],text,_ec_re.I):continue
    try:at=_ec_feeddate(item.findtext('pubDate')or'').isoformat()
    except(ValueError,TypeError):continue
    items.append({'zh':text,'time':at,'url':item.findtext('link'),'source':'免费财经RSS'})
   return items,{'status':'partial','coverage':'免费RSS最近60条；辅助报道不当作独立统计','transport':'RSS','warning':warning}
  except Exception as error:return [],{'status':'error','coverage':'辅助快讯暂不可用，官网取数可独立运行','message':str(error)[:120]}
def _ec_apply_news(result,event,items):
 """Second-source comparisons require same date, month, basis and headline/core."""
 day=_ec_dt.date.fromisoformat(event['date']);now=_ec_date(_ec_now());kind=economic_kind(event)
 for story in items[:30]:
  if not isinstance(story,dict):continue
  at=_ec_date(story.get('time'));text=str(story.get('zh')or'');url=str(story.get('url')or'')
  if not at or at>now or at.astimezone(_EC_BJ).date()!=day or _ec_parse.urlsplit(url).hostname!='eqn.news':continue
  if not _ec_re.search(_EC_SPEC[kind][1],text,_ec_re.I):continue
  if kind.startswith('cn_')and not _ec_re.search('中国|国家统计局',text):continue
  if kind.startswith('us_')and not _ec_re.search('美国|美國|U.S.',text,_ec_re.I):continue
  result['articles'].append({'title':text.splitlines()[0][:230],'url':url,'source_url':story.get('source_url'),'published_at':story['time'],'source_name':'方程式财经 · '+str(story.get('source')or''),'kind':'news'})
  for row in result['metrics']:
   term=r'(?:同比|年率)'if '同比'in row['label']else r'(?:环比|月率)'if '环比'in row['label']else None
   month=_ec_re.search(r'(\d{1,2})月',row.get('period',''))
   if not term or not month or not _ec_re.search(r'(?<!\d)0?'+str(int(month[1]))+r'月',text):continue
   # Cumulative periods must match start and end; do not compare September with Jan–Sep.
   cumulative=_ec_re.search(r'(\d{1,2})[—–-](\d{1,2})月',row.get('period',''))
   if cumulative and not _ec_re.search(r'(?<!\d)'+cumulative[1]+r'[—–-]'+cumulative[2]+r'月',text):continue
   if not cumulative and _ec_re.search(r'\d{1,2}[—–-]\d{1,2}月',text):continue
   if row['key'].startswith('core_'):keypattern=r'核心CPI'
   else:keypattern={'cn_cpi':r'(?<!核心)CPI|居民消费价格','cn_ppi':r'PPI|工业生产者','cn_industry':r'工业增加值','cn_retail':r'零售','cn_profit':r'工业企业利润','cn_investment':r'固定资产投资','cn_gdp':r'GDP|国内生产总值'}.get(kind,_EC_SPEC[kind][1])
   m=_ec_re.search('(?:'+keypattern+r')[^\n。]{0,25}?'+term+r'[^\d-]{0,8}(-?\d+(?:\.\d+)?)\s*%',text,_ec_re.I)
   if not m:continue
   phrase=m[0]
   if not row['key'].startswith('core_')and ('核心'in phrase or '核心'in text[max(0,m.start()-5):m.start()]):continue
   value=_ec_num(m[1]);value=-abs(value)if any(x in phrase for x in('下降','下跌','减少'))else value
   agree=abs(value-float(row['actual']))<.011
   row['corroboration'].append({'value':value,'status':'agree'if agree else'conflict','source_url':url,'source_name':'方程式财经 · '+str(story.get('source')or''),'asof':story['time']})
   tail=text[m.end():].split('。')[0].split('；')[0]
   exp=_ec_re.search(r'(?:预期|预测|预估)\s*(-?\d+(?:\.\d+)?)\s*%',tail)
   if exp:row.update(expected=_ec_num(exp[1]),expected_source_url=url,expected_asof=story['time'],expected_source_name='方程式财经（原文报道的预期）')
 result['articles']=result['articles'][:8]
def _ec_analyze(result,event):
 kind=economic_kind(event);facts=[];comparisons=[]
 for row in result['metrics']:
  if row.get('actual')is None:continue
  n=float(row['actual']);unit=row.get('unit','');facts.append(row['label']+' '+str(row['actual'])+unit)
  if row.get('expected')is not None:
   delta=n-float(row['expected']);comparisons.append(row['label']+('高于预期'if delta>0 else'低于预期'if delta<0 else'符合预期')+' '+str(round(abs(delta),3))+('个百分点'if unit=='%'else unit))
  if 'pmi' in row['key']:comparisons.append(row['label']+('高于50，处于扩张区间'if n>50 else'低于50，仍处于收缩区间'if n<50 else'位于50荣枯分界'))
 result['summary']='；'.join(facts)or'尚未取得与本次发布日期及指标匹配的公布值'
 if facts and not comparisons:
  primary=result['metrics'][0];n=float(primary['actual']);growth=kind in('cn_pmi','cn_industry','cn_retail','cn_gdp','cn_profit','cn_investment','us_gdp','us_payroll')
  if kind=='us_jolts':comparisons.append('职位空缺是水平值，需要与前值、预期比较才能判断需求转强或转弱，不能仅因大于0就判为利多。')
  elif growth:comparisons.append(('本期指标增长，对相关盈利或需求预期提供背景支撑。'if n>0 else'本期指标收缩，对相关盈利或需求预期形成背景压力。'if n<0 else'本期指标持平，需观察需求边际变化。')+'比较口径以指标名称为准；尚缺同口径市场预期，不能据此判定超预期。')
  else:comparisons.append('本期'+primary['label']+('为正'if n>0 else'为负'if n<0 else'持平')+'；需结合核心指标和需求变化分析，缺少预期时不直接给出交易利多/利空结论。')
 result['analysis']=comparisons or (['已取得官方公布值，但缺少同口径市场预期，暂不判定超预期或低于预期。']if facts else['等待官方对应期次数据；没有记录不等于尚未公布。'])
 verified=[x for row in result['metrics']for x in row.get('corroboration',[])]
 conflicts=any(x['status']=='conflict'for x in verified)
 result['verification']='来源数值有分歧，优先保留官方口径'if conflicts else'官方原文与快讯转述一致'if verified else'官方已核验 · 尚无第二来源数值核对'if facts else'尚待核验'
 result['cross_check']={'status':'conflict' if conflicts else 'same_reported_value' if verified else 'single_source','independent_measurement':False,'note':'财经快讯可能转引同一官方发布；同值不代表独立统计验证。'}
 result['stance']={'label':'来源分歧'if conflicts else'关注需求与政策反应'if facts else'等待数据','basis':'数据影响因资产、估值和预期不同而异；以下为规则分析，不是已发生行情。','evidence':[{'text':x,'signal':'数据观察'}for x in result['analysis']]}
 growth=kind in('cn_pmi','cn_industry','cn_retail','cn_gdp','cn_profit','cn_investment','us_gdp','us_payroll','us_jolts')
 if kind.startswith('cn_'):
  if growth:
   result['impact_scenarios']=[{'condition':'增长高于预期 · 盈利支撑','assets':['A股周期/制造/消费','人民币'],'text':'需求或企业利润强于预期，通常有利于对应行业盈利与人民币信心；若因此削弱宽松预期，债券可能承压。','basis':'中国增长数据情景'},{'condition':'增长低于预期 · 需求压力','assets':['相关行业盈利','国债','人民币'],'text':'需求走弱通常压低盈利预期，并可能增强宽松预期、支撑债券。政策托底能否抵消盈利压力，需要后续政策和订单验证。','basis':'中国增长数据情景'}]
  else:
   result['impact_scenarios']=[{'condition':'温和回升且需求改善时','assets':['消费/周期股','工业企业利润','国债'],'text':'需求驱动的价格回升可能缓解通缩压力，对收入和利润预期有利；但价格或利率预期上行可能给债券估值带来压力。需区分食品、能源与核心价格。','basis':'中国价格数据情景'},{'condition':'价格走弱或需求不足时','assets':['盈利预期','成本敏感行业','国债'],'text':'需求不足引起的低通胀可能压制收入和盈利，同时增加宽松预期、支撑国债。原材料降价也可能降低下游成本，不能对所有行业统一判为利空。','basis':'中国价格数据情景'}]
 elif growth:
  result['impact_scenarios']=[{'condition':'增长/就业高于预期时','assets':['美元/美债收益率','周期股','黄金/BTC'],'text':'增长强于预期通常支持盈利与美元，但若推迟降息，也可能推高美债收益率、给黄金和高久期资产带来压力。','basis':'美国增长数据情景'},{'condition':'增长/就业低于预期时','assets':['美债','美元','成长股/BTC'],'text':'温和降温可能支持降息预期与债券；若构成衰退风险，则盈利和风险偏好承压。需判断市场更关注利率还是增长。','basis':'美国增长数据情景'}]
 else:
  result['impact_scenarios']=[{'condition':'通胀高于预期时','assets':['美元/美债收益率','黄金','成长股/BTC'],'text':'可能强化美联储维持高利率的预期，通常支撑美元和收益率，对黄金与高久期资产形成估值压力。','basis':'美国通胀数据情景'},{'condition':'通胀低于预期时','assets':['美债','黄金','成长股/BTC'],'text':'可能增强降息预期、支持债券和利率敏感资产；若同时伴随需求急剧走弱，风险资产仍可能承压。','basis':'美国通胀数据情景'}]

class EconomicService:
 def __init__(self,cache_dir,offline=False,news_client=None):
  self.cache_dir=_ec_Path(cache_dir);self.cache_dir.mkdir(parents=True,exist_ok=True);self.offline=offline;self._lock=_ec_thread.RLock();self._records=_ec_collections.OrderedDict();self._attempts={};self._inflight=set();self._closed=False;self._pool=_ec_Pool(max_workers=2,thread_name_prefix='official-macro');self._client=_ec_Client(news_client);self._packaged={}
  try:
   for name in('economic-snapshot-v18.json','economic-snapshot-v110.json'):
    p=_ec_Path(__file__).resolve().parent/'branding'/name
    if p.exists()and p.stat().st_size<=100000:self._packaged.update({x['event_id']:x['result']for x in _ec_json.loads(p.read_text(encoding='utf-8')).get('items',[])if isinstance(x.get('result'),dict)})
  except(OSError,ValueError,TypeError,KeyError):pass
 def _key(self,event):return _ec_hash.sha256(_ec_json.dumps([event['id'],event['date'],economic_kind(event)],ensure_ascii=False).encode()).hexdigest()
 def _read(self,key):
  if key in self._records:return self._records[key]
  try:
   p=self.cache_dir/(key+'.json')
   if p.stat().st_size>100000:return None
   v=_ec_json.loads(p.read_text());return v if v.get('schema')==1 else None
  except(OSError,ValueError,TypeError):return None
 def snapshot(self,event,refresh=False):
  base=_ec_base(event);key=self._key(event)
  with self._lock:
   cached=self._read(key);old=cached or self._packaged.get(event['id'])
   if old:base=_ec_copy.deepcopy(old)
   if old and not cached:base['distribution_snapshot']=True
   base.setdefault('source_status',{}).pop('jin10',None);base['source_plan']=economic_source_plan(event,base)
   if self.offline or self._closed:base.update(status='offline',error=None);base['source_plan']=economic_source_plan(event,base);return base
   age=_ec_time.monotonic()-self._attempts.get(key,-1e9)
   if key not in self._inflight and len(self._inflight)<2 and age>=(10 if refresh else 60):
    self._inflight.add(key);self._attempts[key]=_ec_time.monotonic();self._pool.submit(self._refresh,key,_ec_copy.deepcopy(event))
   if key in self._inflight:base['status']='refreshing'
   return base
 def _refresh(self,key,event):
  result=_ec_base(event);result['checked_at']=_ec_now();errors=[]
  try:
   try:
    result['metrics'],articles,status=self._client.official(event);result['articles']=articles;result['source_status']['official']=status;result['official_sources']=[{'url':x['url'],'name':x['source_name']}for x in articles]
   except Exception as e:errors.append('官方来源暂未完成');result['source_status']['official']={'status':'error','message':str(e)[:120]}
   try:
    stories,status=self._client.news(event);result['source_status']['news']=status;_ec_apply_news(result,event,stories)
   except Exception as e:result['source_status']['news']={'status':'error','message':str(e)[:120]}
   result['source_plan']=economic_source_plan(event,result)
   with self._lock:old=self._read(key)or self._packaged.get(event['id'])
   if not result['metrics']and old and old.get('metrics'):
    for k in('metrics','articles','official_sources'):result[k]=_ec_copy.deepcopy(old[k])
    result['data_stale']=True;result['last_success_at']=old.get('last_success_at')
   elif result['metrics']:result['last_success_at']=_ec_now()
   _ec_analyze(result,event);result['status']='ready'if result['metrics']else'partial';result['error']='；'.join(errors)or None
  except Exception as e:
   with self._lock:old=self._read(key)or self._packaged.get(event['id'])
   if old and old.get('metrics'):result=_ec_copy.deepcopy(old);result['data_stale']=True;result['checked_at']=_ec_now()
   result.update(status='error',error=str(e)[:200])
  finally:
   with self._lock:
    self._records[key]=result;self._records.move_to_end(key)
    while len(self._records)>100:
     old,_=self._records.popitem(last=False);self._attempts.pop(old,None)
    self._inflight.discard(key)
    try:
     p=self.cache_dir/(key+'.tmp');p.write_text(_ec_json.dumps(result,ensure_ascii=False));p.replace(self.cache_dir/(key+'.json'))
     for p in sorted(self.cache_dir.glob('*.json'),key=lambda x:x.stat().st_mtime,reverse=True)[100:]:p.unlink(missing_ok=True)
    except OSError:pass
 def close(self):
  self._closed=True;self._pool.shutdown(wait=False,cancel_futures=True)

# END ECONOMIC LIVE

# BEGIN PERSONAL CALENDAR (mirrors personal_calendar.py)
"""User-owned events, reversible removals, bounded iCalendar I/O and Windows handoff.

Private notes never enter provider refresh or analytics. No attendee messages are
sent. Desktop handoff opens only an app-generated .ics file in a fixed local folder.
"""
import calendar as _pc_calendar
import copy as _pc_copy
import datetime as _pc_dt
import hashlib as _pc_hash
import json as _pc_json
import os as _pc_os
from pathlib import Path as _pc_Path
import re as _pc_re
import threading as _pc_thread
import uuid as _pc_uuid
_pc_Base = FavoritesStore
_PC_BJ=_pc_dt.timezone(_pc_dt.timedelta(hours=8));_PC_UTC=_pc_dt.timezone.utc
_PC_MAX_EVENTS=2000;_PC_MAX_REMOVED=10000;_PC_MAX_BYTES=6_000_000;_PC_MAX_ICS=2_000_000
_PC_CALENDAR_HELP='https://support.microsoft.com/en-us/outlook/export-emails-and-contacts-from-windows-mail-or-people-and-import-to-new-outlook'
def _pc_stamp():return _pc_dt.datetime.now(_PC_UTC).isoformat(timespec='microseconds')
def _pc_text(value,limit,label,required=False):
 if not isinstance(value,str):raise ValueError(label+'格式无效')
 value=value.replace('\r\n','\n').replace('\r','\n').strip()
 if len(value)>limit or any(ord(c)<32 and c not in '\n\t'for c in value):raise ValueError(label+'过长或含控制字符')
 if required and not value:raise ValueError(label+'不能为空')
 return value

def _pc_day(value):
 if not isinstance(value,str)or not _pc_re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):raise ValueError('日期须为YYYY-MM-DD')
 day=_pc_dt.date.fromisoformat(value)
 if not 1970<=day.year<=2100:raise ValueError('日期超出1970—2100年支持范围')
 return day

def _pc_at(day,clock):
 day=_pc_day(day)
 if not isinstance(clock,str)or not _pc_re.fullmatch(r'\d{2}:\d{2}',clock):raise ValueError('时刻须为HH:mm')
 return _pc_dt.datetime.combine(day,_pc_dt.time.fromisoformat(clock),_PC_BJ)

def _pc_parse_at(value):
 if not isinstance(value,str)or len(value)>50:raise ValueError('时间格式无效')
 at=_pc_dt.datetime.fromisoformat(value.replace('Z','+00:00'))
 if at.tzinfo is None:raise ValueError('时间戳缺少时区')
 return at.astimezone(_PC_BJ)

def personal_event(record):
 start=_pc_parse_at(record['start_at']);end=_pc_parse_at(record['end_at']);all_day=record.get('all_day')is True
 label=('全天'if (end-start).days<=1 else '全天 · '+start.strftime('%m/%d')+'–'+(end-_pc_dt.timedelta(microseconds=1)).strftime('%m/%d'))if all_day else (start.strftime('%H:%M')+'–'+end.strftime('%H:%M')if end.date()==start.date()else start.strftime('%m/%d %H:%M')+'–'+end.strftime('%m/%d %H:%M'))
 return {'id':record['id'],'category':'personal','market':'个人','title':record['title'],'date':start.date().isoformat(),'time':None if all_day else start.strftime('%H:%M'),'start_at':record['start_at'],'end_at':record['end_at'],'timezone':'Asia/Shanghai','time_precision':'date_only'if all_day else'window','time_display':label,'status':'confirmed','source_name':'导入的个人日程'if record.get('import_uid')else'本人创建','source_url':None,'source_checked_at':record.get('updated_at'),'is_personal':True,'import_uid':record.get('import_uid'),'calendar_uid':record.get('calendar_uid'),'all_day':all_day,'importance':'high'if record.get('important')else'normal','description':record.get('description',''),'location':record.get('location',''),'reminder':_pc_copy.deepcopy(record.get('reminder')),'updated_at':record.get('updated_at'),'details':{'说明':record.get('description',''),'地点':record.get('location','')},'data_quality':{'label':'个人日程','basis':'用户自行创建或导入；不作为已核验金融事实。','level':'personal'}}

class PersonalCalendarStore(_pc_Base):
 def __init__(self,cache_dir,app_root=None,platform=None,runner=None,clock=None):
  super().__init__(cache_dir,app_root,platform,runner,clock);self.path=self.cache/'personal-calendar.json';self.lock_path=self.cache/'personal-calendar.lock';self._cached_stamp=None;self._cached_value=None;self._scheduler_thread=None;self._scheduler_lock=_pc_thread.Lock()
 def revision_token(self):
  try:s=self.path.stat();return s.st_mtime_ns,s.st_size
  except FileNotFoundError:return None
 def _read(self):
  try:
   stamp=self.revision_token()
   if stamp is None:return {'schema':1,'revision':0,'events':[],'removed':[],'scheduler':{'status':'not_configured','last_error':None}}
   if stamp[1]>_PC_MAX_BYTES:raise RuntimeError('个人日历文件超过安全大小，原数据已保留')
   if self._cached_stamp==stamp and self._cached_value is not None:return _pc_copy.deepcopy(self._cached_value)
   value=_pc_json.loads(self.path.read_text(encoding='utf-8'))
   if not isinstance(value,dict)or value.get('schema')!=1 or not isinstance(value.get('events'),list)or not isinstance(value.get('removed'),list)or len(value['events'])>_PC_MAX_EVENTS or len(value['removed'])>_PC_MAX_REMOVED:raise RuntimeError('个人日历格式异常，原数据已保留')
   self._cached_value=value;self._cached_stamp=stamp;return _pc_copy.deepcopy(value)
  except (ValueError,TypeError):raise RuntimeError('个人日历无法读取，原数据已保留')from None
 def _write(self,value):
  if len(value['events'])>_PC_MAX_EVENTS or len(value['removed'])>_PC_MAX_REMOVED:raise ValueError('个人日历条目已达上限，请先恢复或整理已移除记录')
  value['revision']=int(value.get('revision',0))+1
  if len(_pc_json.dumps(value,ensure_ascii=False).encode())>_PC_MAX_BYTES:raise ValueError('个人日历内容过多，原数据未覆盖')
  # Reuse the fsync + atomic replacement primitive used by existing reminders.
  from tempfile import NamedTemporaryFile
  with NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.cache,prefix='.personal-',suffix='.tmp',delete=False)as out:
   temp=_pc_Path(out.name)
   try:_pc_json.dump(value,out,ensure_ascii=False,separators=(',',':'),allow_nan=False);out.flush();_pc_os.fsync(out.fileno())
   except Exception:temp.unlink(missing_ok=True);raise
  try:temp.replace(self.path)
  finally:temp.unlink(missing_ok=True)
  self._cached_stamp=None;self._cached_value=None
 def state(self):
  with self._locked():value=self._read()
  return {'schema':1,'revision':value['revision'],'count':len(value['events']),'removed_count':len(value['removed']),'scheduler':value.get('scheduler',{}),'supported':self.platform=='nt'}
 def records(self,start=None,end=None):
  if start:_pc_day(start)
  if end:_pc_day(end)
  with self._locked():value=self._read()
  return sorted([r for r in value['events']if (not start or r['start_at'][:10]>=start)and(not end or r['start_at'][:10]<=end)],key=lambda x:(x['start_at'],x['id']))
 def apply(self,events,start,end,include_personal=True):
  with self._locked():value=self._read()
  hidden={r['event_id']for r in value['removed']if r.get('kind')=='source'};groups=[r['rule']for r in value['removed']if r.get('kind')=='source_group']
  result=[e for e in events if e.get('id')not in hidden and not any(all(e.get(k)==v for k,v in rule.items())for rule in groups)]
  if include_personal:
   first=_pc_day(start);last=_pc_day(end)
   for r in value['events']:
    a=max(_pc_parse_at(r['start_at']).date(),first);b=min((_pc_parse_at(r['end_at'])-_pc_dt.timedelta(microseconds=1)).date(),last)
    if a>b:continue
    event=personal_event(r);event['span_dates']=[(a+_pc_dt.timedelta(days=i)).isoformat()for i in range((b-a).days+1)];result.append(event)
  return result

 def _record(self,payload,identifier=None):
  if not isinstance(payload,dict):raise ValueError('个人日程格式无效')
  title=_pc_text(payload.get('title'),180,'标题',True);description=_pc_text(payload.get('description',''),2000,'说明');location=_pc_text(payload.get('location',''),300,'地点')
  if not isinstance(payload.get('all_day',False),bool)or not isinstance(payload.get('important',False),bool):raise ValueError('全天/重要标志无效')
  all_day=payload.get('all_day')is True
  day=_pc_day(payload.get('date'))
  if all_day:
   start=_pc_dt.datetime.combine(day,_pc_dt.time(),_PC_BJ);last=_pc_day(payload.get('end_date')or payload['date']);end=_pc_dt.datetime.combine(last+_pc_dt.timedelta(days=1),_pc_dt.time(),_PC_BJ)
  else:
   start=_pc_at(payload['date'],payload.get('time'));end=_pc_at(payload.get('end_date')or payload['date'],payload['end_time'])if payload.get('end_time')else start+_pc_dt.timedelta(hours=1)
  if end<=start or end-start>_pc_dt.timedelta(days=366):raise ValueError('结束时间须晚于开始，跨度最多366天')
  result={'id':identifier or'personal-'+_pc_uuid.uuid4().hex[:24],'title':title,'description':description,'location':location,'all_day':all_day,'important':payload.get('important',False),'start_at':start.isoformat(),'end_at':end.isoformat(),'updated_at':_pc_stamp()}
  at=payload.get('reminder_at')
  if at:
   instant=_pc_parse_at(at)
   # User-facing controls explicitly supply UTC+8. Refuse accidental UTC inputs.
   if _pc_dt.datetime.fromisoformat(at.replace('Z','+00:00')).utcoffset()!=_pc_dt.timedelta(hours=8):raise ValueError('提醒时间必须明确使用北京时间UTC+8')
   now=self.clock().astimezone(_PC_BJ)
   if not now<instant<=now+_pc_dt.timedelta(days=366*3):raise ValueError('提醒必须在未来三年以内')
   channels=payload.get('channels',['popup','sound'])
   if not isinstance(channels,list)or not channels or any(x not in('popup','sound')for x in channels):raise ValueError('提醒方式只能选择弹窗或响铃')
   result['reminder']={'id':_pc_uuid.uuid4().hex,'at':instant.isoformat(timespec='seconds'),'channels':sorted(set(channels)),'state':'scheduled','attempts':0,'created_at':result['updated_at'],'last_error':None}
  return result
 def save(self,payload,identifier=None):
  if identifier and not _pc_re.fullmatch(r'personal-[a-f0-9]{24}',identifier):raise ValueError('个人日程编号无效')
  record=self._record(payload,identifier)
  with self._locked():
   value=self._read();old=next((r for r in value['events']if r['id']==record['id']),None)
   if identifier and old is None:raise KeyError('日程已被删除，请刷新后重试')
   if old and payload.get('expected_updated_at')!=old.get('updated_at'):raise ValueError('日程已被另一窗口修改，请刷新后编辑')
   record['created_at']=old.get('created_at')if old else record['updated_at']
   if old and old.get('import_uid'):record['import_uid']=old['import_uid'];record['import_key']=old.get('import_key');record['calendar_uid']=old.get('calendar_uid')
   if old and old.get('reminder')and record.get('reminder')and old['reminder']['at']==record['reminder']['at']and old['reminder']['channels']==record['reminder']['channels']:record['reminder']=old['reminder']
   value['events']=[r for r in value['events']if r['id']!=record['id']]+[record];self._write(value)
  scheduler=self._register_if_needed(bool(record.get('reminder')))
  return {'event':personal_event(record),'scheduler':scheduler,'saved':True}
 def _register_if_needed(self,needed):
  if not needed:return self.state()['scheduler']
  if self.platform!='nt':
   status=self._ensure_scheduler()
   with self._locked():value=self._read();value['scheduler']=status;self._write(value)
   return status
  with self._scheduler_lock:
   if self._scheduler_thread and self._scheduler_thread.is_alive():return {'status':'registering','last_error':None}
   status={'status':'registering','last_error':None,'note':'后台配置中，不阻塞日历操作'}
   with self._locked():value=self._read();value['scheduler']=status;self._write(value)
   def configure():
    try:
     result=self._ensure_scheduler()
     with self._locked():value=self._read();value['scheduler']=result;self._write(value)
    except (RuntimeError,OSError):pass
   self._scheduler_thread=_pc_thread.Thread(target=configure,name='personal-reminder-setup',daemon=True);self._scheduler_thread.start()
   return status

 def resume_reminders(self):
  if self.platform!='nt':return False
  try:
   now=self.clock().astimezone(_PC_BJ)
   with self._locked():value=self._read()
   armed=any(x.get('reminder',{}).get('state')=='scheduled'and _pc_parse_at(x['reminder']['at'])>now for x in value['events'])
   if armed:self._register_if_needed(True)
   return armed
  except (RuntimeError,OSError,ValueError):return False
 def remove_event(self,event):
  if not isinstance(event,dict)or not isinstance(event.get('id'),str)or not 1<=len(event['id'])<=300:raise ValueError('日程标识无效')
  with self._locked():
   value=self._read();identifier=event['id'];old=next((r for r in value['events']if r['id']==identifier),None)
   if identifier.startswith('personal-')and old is None:raise KeyError('个人日程已经删除')
   if any(r.get('event_id')==identifier for r in value['removed']):return {'removed':True,'already_removed':True}
   summary={k:_pc_copy.deepcopy(event.get(k))for k in('title','date','category','market')}
   record={'id':_pc_uuid.uuid4().hex,'event_id':identifier,'kind':'personal'if old else'source','summary':summary,'removed_at':_pc_stamp()}
   if old:record['record']=old;value['events']=[r for r in value['events']if r['id']!=identifier]
   value['removed'].append(record);self._write(value)
  return {'removed':True,'undo_id':record['id'],'message':'已从我的日历移除；可在已移除中恢复，联网刷新不会把它加回来。'}
 def remove_group(self,date,market,category,count):
  _pc_day(date)
  if market not in('A股','美股','港股')or category not in('earnings','unlock')or not isinstance(count,int)or count<1:raise ValueError('分组信息无效')
  identifier='group:'+category+':'+market+':'+date
  with self._locked():
   value=self._read()
   if any(r['event_id']==identifier for r in value['removed']):return {'removed':True,'already_removed':True}
   item={'id':_pc_uuid.uuid4().hex,'kind':'source_group','event_id':identifier,'rule':{'date':date,'market':market,'category':category},'summary':{'title':market+('财报'if category=='earnings'else'重大解禁')+' · '+str(count)+'项','date':date,'market':market,'category':category},'removed_at':_pc_stamp()};value['removed'].append(item);self._write(value)
  return {'removed':True,'undo_id':item['id'],'message':'该日分组已移除，可在已移除中整组恢复。'}
 def removed(self,page=0,limit=20):
  if not isinstance(page,int)or not 0<=page<=100000:raise ValueError('页码无效')
  with self._locked():value=self._read()
  items=sorted(value['removed'],key=lambda x:x['removed_at'],reverse=True);pages=max(1,(len(items)+limit-1)//limit);page=min(page,pages-1)
  return {'items':[{k:x[k]for k in('id','event_id','kind','summary','removed_at')}for x in items[page*limit:(page+1)*limit]],'total':len(items),'page':page,'pages':pages,'limit':limit,'has_more':page+1<pages}
 def restore(self,identifier):
  if not isinstance(identifier,str)or not _pc_re.fullmatch(r'[a-f0-9]{32}',identifier):raise ValueError('恢复编号无效')
  with self._locked():
   value=self._read();item=next((r for r in value['removed']if r['id']==identifier),None)
   if not item:raise KeyError('该移除记录已恢复')
   if item['kind']=='personal':
    record=item['record'];record['updated_at']=_pc_stamp()
    if record.get('reminder')and _pc_parse_at(record['reminder']['at'])<=self.clock().astimezone(_PC_BJ):record['reminder']['state']='missed'
    value['events'].append(record)
   value['removed']=[r for r in value['removed']if r['id']!=identifier];self._write(value)
  return {'restored':True,'event_id':item['event_id']}
 def source_is_removed(self,event_id,event=None):
  with self._locked():value=self._read()
  return any(r['event_id']==event_id or r.get('kind')=='source_group'and event and all(event.get(k)==v for k,v in r['rule'].items())for r in value['removed'])
 def due(self,now=None):
  now=now or self.clock()
  if now.tzinfo is None:raise ValueError('提醒核对时间必须带时区')
  now=now.astimezone(_PC_BJ);claimed=[]
  with self._locked():
   value=self._read();changed=False
   for record in value['events']:
    reminder=record.get('reminder')or{};state=reminder.get('state')
    if state=='delivering':
     if now-_pc_parse_at(reminder['claimed_at'])<_pc_dt.timedelta(minutes=5):continue
     state='scheduled'
    if state!='scheduled' or _pc_parse_at(reminder['at'])>now:continue
    if now-_pc_parse_at(reminder['at'])>_pc_dt.timedelta(hours=48):reminder.update(state='missed',last_error='超过48小时补提醒窗口');changed=True;continue
    if reminder.get('attempts',0)>=3:reminder.update(state='failed',last_error='已停止重复尝试');changed=True;continue
    reminder.update(state='delivering',claimed_at=now.isoformat(),attempts=reminder.get('attempts',0)+1);claimed.append(personal_event(record));changed=True
   if changed:self._write(value)
  return claimed
 def delivered(self,identifier,reminder_id,error=None):
  with self._locked():
   value=self._read();record=next((r for r in value['events']if r['id']==identifier),None)
   if not record:return False
   reminder=record.get('reminder')or{}
   if reminder.get('id')!=reminder_id or reminder.get('state')not in(('delivering','fired')if error else('delivering',)):return False
   reminder.update(state='failed'if error else'fired',fired_at=_pc_stamp(),last_error=str(error)[:200]if error else None);self._write(value)
  return True
 def import_records(self,candidates,enable_reminders=False):
  if not isinstance(enable_reminders,bool):raise ValueError('提醒选项无效')
  now=self.clock().astimezone(_PC_BJ);created=duplicates=0;needs_alarm=False;first_date=None
  with self._locked():
   value=self._read();known={r.get('import_key')for r in value['events']if r.get('import_key')};origin_ids={r['id']for r in value['events']}|{r['event_id']for r in value['removed']};removed_keys={r.get('record',{}).get('import_key')for r in value['removed']if r.get('record')}
   for row in candidates:
    key=row['import_key']
    if key in known or key in removed_keys or row.get('origin_id')in origin_ids:duplicates+=1;continue
    record=_pc_copy.deepcopy(row);record.update(id='personal-'+_pc_uuid.uuid4().hex[:24],created_at=_pc_stamp(),updated_at=_pc_stamp())
    if record.get('reminder'):
     if enable_reminders and now<_pc_parse_at(record['reminder']['at'])<=now+_pc_dt.timedelta(days=366*3):record['reminder'].update(id=_pc_uuid.uuid4().hex,state='scheduled',attempts=0,created_at=_pc_stamp(),last_error=None);needs_alarm=True
     else:record.pop('reminder',None)
    value['events'].append(record);known.add(key);created+=1;first_date=min(first_date or record['start_at'][:10],record['start_at'][:10])
   if created:self._write(value)
  scheduler=self._register_if_needed(needs_alarm)
  return {'created':created,'duplicates':duplicates,'scheduler':scheduler,'saved':True,'first_date':first_date}

def _pc_escape(value):return str(value).replace('\\','\\\\').replace('\r\n','\n').replace('\r','\n').replace('\n','\\n').replace(';','\\;').replace(',','\\,')
def _pc_unescape(value):return _pc_re.sub(r'\\([nN,;\\])',lambda m:'\n'if m[1].lower()=='n'else m[1],value)
def _pc_fold(line):
 parts=[];current='';size=0
 for ch in line:
  n=len(ch.encode())
  if size+n>75:parts.append(current);current=' '+ch;size=1+n
  else:current+=ch;size+=n
 return '\r\n'.join(parts+[current])
def export_calendar_ics(events,include_estimated=False):
 if len(events)>15000:raise ValueError('一次最多导出15000项，请缩小日期范围')
 lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Shixu//Personal Calendar//ZH','CALSCALE:GREGORIAN','METHOD:PUBLISH','X-WR-CALNAME:时序','X-WR-TIMEZONE:Asia/Shanghai'];count=excluded=0;seen=set();seen_uids=set();now=_pc_dt.datetime.now(_PC_UTC).strftime('%Y%m%dT%H%M%SZ')
 for e in events:
  if not isinstance(e,dict)or e.get('data_stale')and not e.get('is_personal')or e.get('status')!='confirmed'and not include_estimated:excluded+=1;continue
  identifier=e.get('id')
  if not isinstance(identifier,str)or identifier in seen:continue
  try:start=_pc_parse_at(e['start_at']);end=_pc_parse_at(e['end_at'])if e.get('end_at')else None
  except(ValueError,KeyError,TypeError):excluded+=1;continue
  if end and end<=start:excluded+=1;continue
  seen.add(identifier);uid=e.get('calendar_uid')or e.get('import_uid')or _pc_hash.sha256(identifier.encode()).hexdigest()+'@willance-event-calendar'
  # Imported UID is never allowed to insert arbitrary iCalendar properties.
  uid=str(uid).replace('\r','').replace('\n','')[:300]
  if uid in seen_uids:excluded+=1;continue
  seen_uids.add(uid);title=str(e.get('title')or'日程')[:240];estimated=e.get('status')!='confirmed'
  lines+=['BEGIN:VEVENT','UID:'+uid,'DTSTAMP:'+now,'SEQUENCE:'+str(max(0,int(e.get('sequence',0))))]
  if (e.get('is_personal')and e.get('all_day'))or(e.get('time_precision')in('date_only','date_range')and start.time()==_pc_dt.time()and end and end.time()==_pc_dt.time()):
   lines+=['DTSTART;VALUE=DATE:'+start.strftime('%Y%m%d'),'DTEND;VALUE=DATE:'+(end or start+_pc_dt.timedelta(days=1)).strftime('%Y%m%d')]
  else:
   lines+=['DTSTART:'+start.astimezone(_PC_UTC).strftime('%Y%m%dT%H%M%SZ')]
   if end:lines+=['DTEND:'+end.astimezone(_PC_UTC).strftime('%Y%m%dT%H%M%SZ')]
  desc=e.get('description')if e.get('is_personal')else '来源：'+str(e.get('source_name')or'未给出')+'\n'+str(e.get('source_url')or'')+'\n北京时间：'+str(e.get('date'))+' '+str(e.get('time_display')or'')
  lines+=['SUMMARY:'+_pc_escape(('[预计] 'if estimated else'')+title),'DESCRIPTION:'+_pc_escape(desc or''),'STATUS:'+('TENTATIVE'if estimated else'CONFIRMED'),'TRANSP:TRANSPARENT','X-SHIXU-EVENT-ID:'+_pc_escape(identifier)]
  if e.get('location'):lines+=['LOCATION:'+_pc_escape(e['location'])]
  url=e.get('source_url')
  if isinstance(url,str)and url.startswith('https://')and not any(x in url for x in'\r\n'):lines+=['URL:'+url]
  reminder=e.get('reminder')or{}
  if reminder.get('at')and reminder.get('state')=='scheduled':
   try:
    trigger=_pc_parse_at(reminder['at']);seconds=int((trigger-start).total_seconds());sign='-'if seconds<0 else''
    lines+=['BEGIN:VALARM','ACTION:DISPLAY','DESCRIPTION:'+_pc_escape(title),'TRIGGER:'+sign+'PT'+str(abs(seconds))+'S','END:VALARM']
   except(ValueError,TypeError):pass
  lines+=['END:VEVENT'];count+=1
 lines+=['END:VCALENDAR'];body=('\r\n'.join(_pc_fold(x)for x in lines)+'\r\n').encode('utf-8');return body,{'exported':count,'excluded':excluded}

def _pc_duration(value):
 m=_pc_re.fullmatch(r'([+-])?P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?',value)
 if not m or not any(m[i]for i in range(2,7)):raise ValueError('暂不支持此持续时间格式')
 seconds=sum(int(m[i]or 0)*scale for i,scale in[(2,604800),(3,86400),(4,3600),(5,60),(6,1)])
 if seconds>366*86400:raise ValueError('持续时间过长')
 return _pc_dt.timedelta(seconds=-seconds if m[1]=='-'else seconds)
def _pc_ics_time(value,params,warnings):
 if params.get('VALUE')=='DATE'or _pc_re.fullmatch(r'\d{8}',value):return _pc_dt.datetime.strptime(value,'%Y%m%d').replace(tzinfo=_PC_BJ),True
 if value.endswith('Z'):return _pc_dt.datetime.strptime(value,'%Y%m%dT%H%M%SZ').replace(tzinfo=_PC_UTC).astimezone(_PC_BJ),False
 if _pc_re.fullmatch(r'\d{8}T\d{6}[+-]\d{4}',value):return _pc_dt.datetime.strptime(value,'%Y%m%dT%H%M%S%z').astimezone(_PC_BJ),False
 naive=_pc_dt.datetime.strptime(value,'%Y%m%dT%H%M%S');zone=params.get('TZID')
 if not zone:
  warnings.add('未标注时区的浮动时间按北京时间解释。');return naive.replace(tzinfo=_PC_BJ),False
 aliases={'China Standard Time':'Asia/Shanghai','Eastern Standard Time':'America/New_York','UTC':'UTC','Etc/UTC':'UTC'};zone=aliases.get(zone,zone)
 # Local desktop has no tzdata dependency; use the app's explicit US DST fallback.
 from timing_policy import local_datetime
 return local_datetime(naive.strftime('%Y-%m-%d'),naive.strftime('%H:%M:%S'),zone),False

def parse_calendar_ics(text):
 if not isinstance(text,str)or not text or len(text.encode('utf-8'))>_PC_MAX_ICS:raise ValueError('请选择2MB以内的UTF-8 .ics日历文件')
 raw=text.lstrip('\ufeff').replace('\r\n','\n').replace('\r','\n');lines=[]
 for line in raw.split('\n'):
  if len(line)>16000:raise ValueError('日历行过长')
  if line.startswith((' ','\t'))and lines:lines[-1]+=line[1:]
  else:lines.append(line)
 if not lines or lines[0].strip().upper()!='BEGIN:VCALENDAR'or'END:VCALENDAR'not in[ln.upper()for ln in lines]:raise ValueError('文件不是完整的iCalendar日历')
 blocks=[];current=None;alarm=None;errors=[];warnings=set();candidates=[]
 for line in lines:
  if not line:continue
  head,sep,value=line.partition(':')
  if not sep:continue
  parts=head.split(';');key=parts[0].upper();params={}
  for part in parts[1:]:
   k,eq,v=part.partition('=')
   if eq:params[k.upper()]=v.strip('"')
  tag=value.upper()
  if key=='BEGIN'and tag=='VEVENT':
   if current is not None:raise ValueError('日历事件嵌套无效')
   current={};alarm=None
  elif key=='END'and tag=='VEVENT':
   if current is None:raise ValueError('日历事件边界无效')
   blocks.append(current);current=None
   if len(blocks)>2000:raise ValueError('一次最多导入2000个原始事件')
  elif current is not None:
   if key=='BEGIN'and tag=='VALARM':alarm={}
   elif key=='END'and tag=='VALARM':current.setdefault('alarms',[]).append(alarm or{});alarm=None
   elif alarm is not None:alarm.setdefault(key,[]).append((params,value))
   else:current.setdefault(key,[]).append((params,value))
 if current is not None:raise ValueError('日历事件没有结束')
 def prop(block,name,default=''):
  rows=block.get(name)or[]
  if len(rows)>1 and name in('UID','DTSTART','DTEND','RRULE','SUMMARY'):raise ValueError(name+'字段重复')
  return rows[0]if rows else({},default)
 for index,block in enumerate(blocks):
  label='第'+str(index+1)+'项'
  try:
   title=_pc_text(_pc_unescape(prop(block,'SUMMARY')[1])or'未命名日程',180,'标题',True);label=title
   if prop(block,'STATUS')[1].upper()=='CANCELLED':warnings.add('已取消事件没有导入。');continue
   if block.get('RECURRENCE-ID')or block.get('RDATE'):raise ValueError('包含重复实例覆盖或额外重复日期，暂不导入以免错排')
   sp,sv=prop(block,'DTSTART');start,all_day=_pc_ics_time(sv,sp,warnings)
   ep,ev=prop(block,'DTEND');end=_pc_ics_time(ev,ep,warnings)[0]if ev else start+(_pc_duration(prop(block,'DURATION')[1])if block.get('DURATION')else _pc_dt.timedelta(days=1)if all_day else _pc_dt.timedelta(hours=1))
   if end<=start or end-start>_pc_dt.timedelta(days=366):raise ValueError('事件结束时间无效')
   uid=_pc_text(prop(block,'UID')[1]or _pc_hash.sha256(_pc_json.dumps(block,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),300,'UID',True)
   record={'title':title,'description':_pc_text(_pc_unescape(prop(block,'DESCRIPTION')[1]),2000,'说明'),'location':_pc_text(_pc_unescape(prop(block,'LOCATION')[1]),300,'地点'),'all_day':all_day,'important':False,'import_uid':uid,'origin_id':prop(block,'X-SHIXU-EVENT-ID')[1][:300]}
   starts=[(start,end,'')]
   rule=prop(block,'RRULE')[1]
   if rule:
    pairs=[part.split('=',1)for part in rule.upper().split(';')]
    if any(len(x)!=2 for x in pairs):raise ValueError('重复规则格式无效')
    spec=dict(pairs)
    if len(spec)!=len(pairs)or set(spec)-{'FREQ','COUNT','UNTIL','INTERVAL','BYDAY','WKST'}:raise ValueError('此重复规则暂不支持，未将其错误转换为单次事件')
    if spec.get('FREQ')not in('DAILY','WEEKLY'):raise ValueError('目前仅支持按日、按周重复；其他规则本次未导入')
    count=int(spec.get('COUNT','366'));interval=int(spec.get('INTERVAL','1'))
    if not 1<=count<=366 or not 1<=interval<=366:raise ValueError('重复次数/间隔超限')
    until=_pc_ics_time(spec['UNTIL'],{},warnings)[0]if spec.get('UNTIL')else start+_pc_dt.timedelta(days=366)
    if not spec.get('COUNT')and not spec.get('UNTIL'):warnings.add('无限重复事件仅展开开始日起366天；不会自动续建未来实例。')
    source_weekday=(_pc_dt.datetime.strptime(sv[:8],'%Y%m%d').weekday())
    weekdays={'MO':0,'TU':1,'WE':2,'TH':3,'FR':4,'SA':5,'SU':6};allowed={weekdays[x]for x in spec.get('BYDAY',list(weekdays)[source_weekday]).split(',')}
    if spec.get('WKST','MO')not in weekdays:raise ValueError('周起始日无效')
    if spec.get('WKST','MO')!='MO':raise ValueError('目前仅支持周一起始的重复规则')
    if spec['FREQ']=='DAILY'and 'BYDAY'in spec:raise ValueError('按日重复附加星期筛选暂不支持')
    starts=[];zone=sp.get('TZID');localbase=_pc_dt.datetime.strptime(sv,'%Y%m%dT%H%M%S')if zone else None
    for offset in range(366*3+1):
     naive=localbase+_pc_dt.timedelta(days=offset)if localbase else None
     at=_pc_ics_time(naive.strftime('%Y%m%dT%H%M%S'),sp,warnings)[0]if naive else start+_pc_dt.timedelta(days=offset)
     if at>until:break
     week=((source_weekday+offset)//7)
     valid=(offset%interval==0)if spec['FREQ']=='DAILY'else(week%interval==0 and (source_weekday+offset)%7 in allowed)
     if valid:starts.append((at,at+(end-start),at.isoformat()))
     if len(starts)>=count:break
    if len(starts)<count and until>start+_pc_dt.timedelta(days=366*3):warnings.add('重复日程仅展开三年内实例；更远实例未导入。')
   excluded=set()
   for xp,xv in block.get('EXDATE',[]):
    for val in xv.split(','):excluded.add(_pc_ics_time(val,xp,warnings)[0].isoformat())
   for at,finish,instance in starts:
    if at.isoformat()in excluded:continue
    _pc_day(at.date().isoformat());row={**record,'start_at':at.isoformat(),'end_at':finish.isoformat()};row['import_key']=_pc_hash.sha256(_pc_json.dumps([uid,instance],ensure_ascii=False).encode()).hexdigest();row['calendar_uid']=row['import_key']+'@shixu-instance'if instance else uid
    for alarm in block.get('alarms',[]):
     action=prop(alarm,'ACTION')[1].upper()
     if action not in('DISPLAY','AUDIO'):warnings.add('邮件或其他外部动作提醒不会执行。');continue
     ap,av=prop(alarm,'TRIGGER')
     if ap.get('RELATED','START')!='START':warnings.add('相对结束时间的提醒暂未导入。');continue
     alarm_at=_pc_ics_time(av,ap,warnings)[0]if ap.get('VALUE')=='DATE-TIME'else at+_pc_duration(av)
     row['reminder']={'at':alarm_at.isoformat(timespec='seconds'),'channels':['popup','sound']};break
    candidates.append(row)
    if len(candidates)>_PC_MAX_EVENTS:raise OverflowError('展开后超过2000项，请缩小日历文件范围')
  except OverflowError as error:raise ValueError(str(error))from None
  except(KeyError,ValueError,TypeError)as error:errors.append({'title':label[:180],'reason':str(error)[:180]})
 return {'items':candidates,'errors':errors[:100],'rejected':len(errors),'warnings':sorted(warnings),'count':len(candidates),'reminders':sum(bool(x.get('reminder'))for x in candidates),'source_events':len(blocks)}

def open_windows_calendar(root,body,*,platform=None,opener=None):
 platform=_pc_os.name if platform is None else platform
 if platform!='nt':return {'supported':False,'opened':False,'message':'请在Windows桌面版中使用系统日历；仍可下载标准.ics文件。','help_url':_PC_CALENDAR_HELP}
 if not isinstance(body,bytes)or not body.startswith(b'BEGIN:VCALENDAR')or len(body)>20_000_000:raise ValueError('导出文件无效')
 directory=_pc_Path(root)/'calendar-exports'
 if directory.is_symlink():raise ValueError('日历导出目录无效')
 directory.mkdir(parents=True,exist_ok=True);path=directory/('Shixu-'+_pc_uuid.uuid4().hex+'.ics')
 with path.open('xb')as out:out.write(body)
 try:
  (opener or _pc_os.startfile)(str(path))
  return {'supported':True,'opened':True,'path':str(path),'message':'已把.ics文件交给Windows默认日历软件。请在客户端选择目标日历并确认导入；尚不能确认已导入。','help_url':_PC_CALENDAR_HELP}
 except OSError:
  return {'supported':True,'opened':False,'path':str(path),'message':'文件已保存，但未能打开默认日历软件。可在Outlook的“添加日历→从文件上传”中选择此文件。','help_url':_PC_CALENDAR_HELP}

# END PERSONAL CALENDAR

class CalendarServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self, address, store, preview=False):
        self.store=store; self.slim=SlimCalendarAPI(store); self.token=secrets.token_urlsafe(32); self.preview=preview
        self.diagnostic_lock=threading.Lock()
        self.diagnostic_file=store.cache/'performance-last.json'
        self.diagnostic_previous=None
        try:
            if self.diagnostic_file.stat().st_size<=32768:
                prior=json.loads(self.diagnostic_file.read_text(encoding='utf-8'))
                if isinstance(prior,dict) and prior.get('schema')==1:self.diagnostic_previous=prior
        except (OSError,ValueError):pass
        super().__init__(address,CalendarHandler)

class CalendarHandler(BaseHTTPRequestHandler):
    server_version='EventCalendar/1.0'
    def log_message(self,*args): pass
    def _allowed(self):
        host=self.headers.get('Host','')
        try: name=urlsplit('http://'+host).hostname
        except ValueError: return False
        allowed={'127.0.0.1','localhost'}
        if self.server.preview: allowed.add('terminal.local')
        if name not in allowed: return False
        origin=self.headers.get('Origin')
        if origin and origin!='http://'+host: return False
        if self.headers.get('Sec-Fetch-Site')=='cross-site': return False
        return True
    def send_bytes(self,body,ctype='application/json; charset=utf-8',status=200,extra=None):
        self.send_response(status)
        self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body)))
        if 'Cache-Control' not in (extra or {}):self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        for k,v in (extra or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def js(self,value,status=200):
        body=json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
        if len(body)>4096 and 'gzip' in self.headers.get('Accept-Encoding','').lower():
            return self.send_bytes(gzip.compress(body,compresslevel=1,mtime=0),status=status,extra={'Content-Encoding':'gzip','Vary':'Accept-Encoding'})
        self.send_bytes(body,status=status)
    def do_GET(self):
        if not self._allowed(): return self.js({'error':'只允许本机同源访问'},403)
        path=urlsplit(self.path); qs=parse_qs(path.query,keep_blank_values=True)
        if path.path=='/api/performance': return self.js({'previous':self.server.diagnostic_previous})
        if path.path=='/api/health': return self.js({'ok':True,'app':'willance-event-calendar','version':VERSION})
        if path.path=='/api/bootstrap': return self.js({'token':self.server.token,'version':VERSION,'watchlist':self.server.store.watchlist,'watchlist_fact_date':self.server.store.watchlist.get('fact_date')})
        if path.path=='/api/almanac':
            try:return self.js(current_almanac(ROOT,qs.get('date',[None])[0]))
            except (ValueError,TypeError):return self.js({'error':'日期须为YYYY-MM-DD'},400)
        if path.path=='/api/updates/history':return self.js(self.server.store.updates.history())
        if path.path in ('/api/personal/status','/api/personal/events','/api/personal/removed'):
            try:
                personal=self.server.store.personal
                if path.path.endswith('/status'):return self.js(personal.state())
                if path.path.endswith('/removed'):return self.js(personal.removed(int(qs.get('page',['0'])[0])))
                rows=personal.records(qs.get('start',[None])[0],qs.get('end',[None])[0])
                page=max(0,int(qs.get('page',['0'])[0]));pages=max(1,(len(rows)+19)//20);page=min(page,pages-1)
                return self.js({'items':[personal_event(r)for r in rows[page*20:(page+1)*20]],'total':len(rows),'page':page,'pages':pages,'has_more':page+1<pages})
            except (ValueError,TypeError,RuntimeError,OSError):return self.js({'error':'本机日程暂时无法读取，原数据已保留'},400)
        if path.path=='/api/calendar/export':
            try:
                events,estimated=self.calendar_export_events(qs);body,meta=export_calendar_ics(events,estimated)
                return self.send_bytes(body,'text/calendar; charset=utf-8',extra={'Content-Disposition':'attachment; filename="Shixu-calendar.ics"','X-Shixu-Exported':str(meta['exported']),'X-Shixu-Excluded':str(meta['excluded'])})
            except(SlimAPIError,ValueError,TypeError,KeyError)as error:return self.js({'error':str(error)[:200]},400)
        if path.path=='/api/updates/status':
            if not self.server.store.offline:self.server.store.updates.start_background()
            return self.js(self.server.store.updates.status())
        if path.path=='/api/desktop/status':
            from desktop.launcher import desktop_status
            value=desktop_status()
            if self.server.preview:
                value.update(supported=False,state='preview',error=None,message='当前为界面预览，无法更改Windows桌面入口')
            return self.js(value)
        if path.path=='/api/macro':
            try:
                event=self.server.slim.query('/api/event',qs)['event']
                if not macro_supported(event) and not economic_kind(event):return self.js({'error':'该宏观指标暂未接入对应公布值源'},400)
                force=qs.get('refresh',['0'])[0]
                if force not in ('0','1'):return self.js({'error':'刷新参数无效'},400)
                service=self.server.store.macro if macro_supported(event)else self.server.store.economic
                return self.js(service.snapshot(event,refresh=force=='1'))
            except SlimAPIError as error:return self.js({'error':str(error)},error.status)
            except ValueError:return self.js({'error':'该宏观事件的日期或类型暂不受支持'},400)
        if path.path=='/api/quotes/status': return self.js(self.server.store.quotes.status())
        if path.path=='/api/status': return self.js(self.server.store.status())
        if path.path=='/api/favorites':
            try:return self.js(self.server.store.favorites.list())
            except (RuntimeError,OSError):return self.js({'error':'本机收藏暂时无法读取，原数据已保留，请稍后重试'},503)
        if path.path=='/api/options':
            try:
                event=self.server.slim.query('/api/event',qs)['event']
                if event.get('category')!='options':
                    return self.js({'error':'请选择一个期权到期事项'},400)
                force=qs.get('refresh',['0'])[0]
                if force not in ('0','1'):return self.js({'error':'刷新参数无效'},400)
                return self.js(self.server.store.options.snapshot(event,refresh=force=='1'))
            except SlimAPIError as error:
                return self.js({'error':str(error)},error.status)
            except ValueError:
                return self.js({'error':'该期权到期事项的标的或时间格式暂不受支持'},400)
        if path.path=='/api/earnings':
            try:
                # Resolve only an existing event in the requested calendar range.
                # Never accept arbitrary provider URLs or a bulk holdings list.
                event=self.server.slim.query('/api/event',qs)['event']
                if event.get('category')!='earnings' or not isinstance(event.get('company'),dict):
                    return self.js({'error':'请选择单家公司的财报事项'},400)
                force=qs.get('refresh',['0'])[0]
                if force not in ('0','1'):return self.js({'error':'刷新参数无效'},400)
                return self.js(self.server.store.earnings.snapshot(event,refresh=force=='1'))
            except SlimAPIError as error:
                return self.js({'error':str(error)},error.status)
            except ValueError:
                return self.js({'error':'该财报的证券代码或查询格式暂不受支持'},400)
        if path.path in ('/api/calendar','/api/day','/api/group','/api/event','/api/pending','/api/search'):
            try:
                return self.js(self.server.slim.query(path.path, qs))
            except SlimAPIError as error:
                return self.js({'error':str(error)}, error.status)
        if path.path in ('/api/events','/calendar.ics'):
            try: start,end=period(qs.get('start',[None])[0],qs.get('end',[None])[0])
            except (ValueError,TypeError): return self.js({'error':'无效日期范围，最大63天'},400)
            result=self.server.store.query(start,end,shared=True)
            if path.path=='/calendar.ics':
                # Export the same expiry focus as the main calendar, while the
                # raw API and favorite IDs keep every original listed expiry.
                export_events=[]; seen_expiries=set()
                for event in result['events']:
                    focus=option_expiry_focus(event)
                    if focus:
                        if focus['expiry_tier'] not in ('monthly','quarterly'): continue
                        key=(focus['expiry_venue'],focus['expiry_asset'],focus['expiry_at_utc'])
                        if key in seen_expiries: continue
                        seen_expiries.add(key)
                    export_events.append(event)
                return self.send_bytes(export_calendar_ics(export_events)[0],'text/calendar; charset=utf-8',extra={'Content-Disposition':'attachment; filename="willance-calendar.ics"'})
            return self.js(result)
        if path.path.startswith('/branding/'):
            name=path.path.removeprefix('/branding/')
            if not re.fullmatch(r'[A-Za-z0-9_.-]+',name):return self.js({'error':'未找到'},404)
            virtual=logo_asset(name)
            if virtual:
                body,mime,digest=virtual
                etag='"'+digest+'"'
                if self.headers.get('If-None-Match')==etag:
                    return self.send_bytes(b'',mime,status=304,extra={'ETag':etag,'Cache-Control':'private, max-age=86400'})
                return self.send_bytes(body,mime,extra={'ETag':etag,'Cache-Control':'private, max-age=86400'})
            file=ROOT/'branding'/name
            if not file.is_file() or file.suffix.lower() not in ('.svg','.ico','.png','.webp','.jpg'):return self.js({'error':'未找到'},404)
            mime={'.svg':'image/svg+xml','.ico':'image/x-icon','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg'}[file.suffix.lower()]
            body=file.read_bytes();etag='"'+hashlib.sha256(body).hexdigest()+'"'
            if self.headers.get('If-None-Match')==etag:
                return self.send_bytes(b'',mime,status=304,extra={'ETag':etag,'Cache-Control':'private, max-age=3600'})
            return self.send_bytes(body,mime,extra={'ETag':etag,'Cache-Control':'private, max-age=3600'})
        resources={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/perf_monitor.js':'perf_monitor.js','/style.css':'style.css','/favicon.ico':'favicon.ico'}
        if path.path not in resources: return self.js({'error':'未找到'},404)
        file=ROOT/'web'/resources[path.path]
        if not file.exists(): return self.js({'error':'未找到'},404)
        types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.ico':'image/x-icon'}
        return self.send_bytes(file.read_bytes(),types.get(file.suffix,'application/octet-stream'))
    def calendar_export_events(self,qs):
        scope=_slim_one(qs,'scope','personal');estimated=_slim_one(qs,'include_estimated','0')
        if estimated not in('0','1'):raise ValueError('预计记录选项无效')
        if scope=='personal':return [personal_event(r)for r in self.server.store.personal.records()],False
        if scope=='event':return [self.server.slim.query('/api/event',qs)['event']],estimated=='1'
        if scope=='favorites':return self.server.store.export_favorites(),estimated=='1'
        if scope!='visible':raise ValueError('请选择个人日程、收藏、当前筛选或单个事项')
        filters=_slim_filters(qs);start,end,dataset,payload=self.server.slim._load(qs)
        selection=dataset.selection(filters);return list(selection['events']),estimated=='1'

    def do_POST(self):
        if not self._allowed(): return self.js({'error':'只允许本机同源访问'},403)
        if not hmac.compare_digest(self.headers.get('X-Calendar-Token',''),self.server.token): return self.js({'error':'本机会话校验失败，请重新打开窗口'},403)
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: return self.js({'error':'请求无效'},400)
        request_path=urlsplit(self.path).path
        limit=3_000_000 if request_path=='/api/calendar/import' else 32768
        if length<0 or length>limit: return self.js({'error':'请求过大'},413)
        try: body=json.loads(self.rfile.read(length) or b'{}')
        except (ValueError,UnicodeError): return self.js({'error':'JSON无效'},400)
        path=urlsplit(self.path).path
        if path in ('/api/desktop/repair','/api/desktop/open-folder'):
            if self.server.preview or os.name!='nt':
                return self.js({'supported':False,'state':'unsupported','error':'请在Windows桌面版中使用此功能'},409)
            if not isinstance(body,dict) or body:
                return self.js({'error':'桌面入口操作不接受自定义路径或参数'},400)
            if path=='/api/desktop/repair':
                from desktop.launcher import request_desktop_repair
                return self.js(request_desktop_repair('http://127.0.0.1:'+str(self.server.server_port)+'/'),202)
            try:
                os.startfile(str(ROOT))
                return self.js({'ok':True,'install_dir':str(ROOT),'message':'已打开当前安装文件夹'})
            except OSError:
                return self.js({'error':'Windows未能打开安装文件夹，请复制显示的安装位置'},503)
        if path=='/api/performance':
            allowed={'schema','app_version','captured_at','uptime_ms','phase','measures','payloads','long_tasks','long_animation_frames','heartbeat','renderer','note'}
            if not isinstance(body,dict) or body.get('schema')!=1 or not set(body)<=allowed:
                return self.js({'error':'诊断格式无效'},400)
            try:
                with self.server.diagnostic_lock:atomic_json(self.server.diagnostic_file,body)
            except (OSError,ValueError,TypeError):return self.js({'error':'本机诊断保存未完成'},400)
            return self.js({'saved':True})
        if path=='/api/shutdown':
            self.js({'ok':True}); self.server.store.closed=True
            threading.Thread(target=self.server.shutdown,daemon=True).start(); return
        if path in ('/api/personal/save','/api/personal/remove','/api/personal/remove-group','/api/personal/restore','/api/calendar/import','/api/calendar/windows'):
            try:
                if not isinstance(body,dict):raise ValueError('请求格式无效')
                personal=self.server.store.personal
                if path=='/api/personal/save':return self.js(personal.save(body.get('event'),body.get('id')))
                if path=='/api/personal/restore':return self.js(personal.restore(body.get('id')))
                if path=='/api/personal/remove-group':
                    query={k:[body[k]]for k in('start','end','date','kind','group_market')if k in body}
                    group=self.server.slim.query('/api/group',query)
                    if not group['total']:raise ValueError('此分组已经没有可移除事件')
                    result=personal.remove_group(group['date'],group['market'],group['kind'],group['total'])
                    try:result['favorites_removed']=self.server.store.favorites.remove_group_favorites({'date':group['date'],'market':group['market'],'category':group['kind']})
                    except(RuntimeError,OSError):result['warning']='分组已移除；收藏清理未完成，后台已抑制相关提醒。'
                    return self.js(result)
                if path=='/api/personal/remove':
                    query={k:[body[k]]for k in('start','end')if k in body};query['id']=[body.get('event_id','')]
                    try:event=self.server.slim.query('/api/event',query)['event']
                    except SlimAPIError as error:
                        if error.status!=404:raise
                        start,end=period(body.get('start'),body.get('end'));pending=self.server.store.query(start,end,shared=True).get('pending',[])
                        event=next((e for e in pending if e.get('id')==body.get('event_id')),None)
                        if not event:raise error
                    result=personal.remove_event(event)
                    try:result['favorites_removed']=self.server.store.favorites.remove_event_favorites(event['id'])
                    except(RuntimeError,OSError):result['warning']='日程已移除；收藏清理未完成，后台已抑制该日程提醒。'
                    return self.js(result)
                if path=='/api/calendar/import':
                    if body.get('action')not in('preview','import'):raise ValueError('请选择预览或导入')
                    parsed=parse_calendar_ics(body.get('text'))
                    if body['action']=='preview':return self.js({**{k:v for k,v in parsed.items()if k!='items'},'items':[{k:x.get(k)for k in('title','start_at','end_at','all_day')}for x in parsed['items'][:20]]})
                    result=personal.import_records(parsed['items'],body.get('enable_reminders',False));return self.js({**result,'rejected':parsed['rejected'],'errors':parsed['errors'],'warnings':parsed['warnings']})
                query=body.get('selection')or{}
                if not isinstance(query,dict)or any(not isinstance(v,str)for v in query.values()):raise ValueError('导出筛选无效')
                events,estimated=self.calendar_export_events({k:[v]for k,v in query.items()});ics,meta=export_calendar_ics(events,estimated)
                if not meta['exported']:raise ValueError('所选范围没有可导出的日程；过期缓存或未确认事件默认不导出')
                result=open_windows_calendar(self.server.store.cache,ics,platform='preview'if self.server.preview else None)
                if not result['supported']:result['error']=result['message']
                return self.js({**result,**meta},200 if result['supported'] else 409)
            except SlimAPIError as error:return self.js({'error':str(error)},error.status)
            except(KeyError,ValueError,TypeError)as error:return self.js({'error':str(error)[:220]},400)
            except(RuntimeError,OSError):return self.js({'error':'本机日历未能完成操作，原记录已保留，请稍后重试'},503)
        if path=='/api/watchlist':
            try:return self.js({'watchlist':self.server.store.set_watchlist(body)})
            except (ValueError,TypeError,KeyError) as exc:return self.js({'error':str(exc)},400)
        if path=='/api/favorites':
            try:
                if not isinstance(body,dict):return self.js({'error':'收藏请求格式无效'},400)
                action=body.get('action');favorites=self.server.store.favorites
                if action=='save':
                    query={k:[body[k]] for k in ('start','end') if k in body}
                    query['id']=[body.get('event_id','')]
                    event=self.server.slim.query('/api/event',query)['event']
                    return self.js({'item':favorites.save(event),'favorites':favorites.list()})
                identifier=body.get('id')
                if action=='remove':result=favorites.remove(identifier)
                elif action=='remind':result=favorites.set_reminder(identifier,body.get('at'),body.get('channels',['popup','sound']))
                elif action=='dismiss':result=favorites.dismiss(identifier)
                elif action=='cancel':result=favorites.cancel_reminder(identifier)
                else:return self.js({'error':'未支持的收藏操作'},400)
                return self.js({'item':result,'favorites':favorites.list()})
            except SlimAPIError as error:return self.js({'error':str(error)},error.status)
            except (ValueError,KeyError,TypeError) as error:return self.js({'error':str(error)[:200]},400)
            except (RuntimeError,OSError):return self.js({'error':'本机收藏暂时无法保存，原数据已保留，请稍后重试'},503)
        if path=='/api/updates/rollback':
            try:return self.js(self.server.store.updates.request_rollback(body.get('id')),202)
            except (ValueError,TypeError,KeyError,OSError,UpdateError) as error:return self.js({'error':str(error)[:200]},400)
        if path=='/api/updates/check':
            if self.server.store.offline:return self.js({'status':'offline','current_version':VERSION,'error':'只读模式不检查更新'},202)
            self.server.store.updates.start_background(force=True)
            return self.js(self.server.store.updates.status(),202)
        if path=='/api/quotes/refresh':
            self.server.store.quotes.request(force=True)
            return self.js(self.server.store.quotes.status(),202)
        if path!='/api/refresh': return self.js({'error':'未找到'},404)
        try: start,end=period(body.get('start'),body.get('end'))
        except (ValueError,TypeError,AttributeError): return self.js({'error':'日期范围无效'},400)
        self.server.store.request_refresh(start,end,force=True)
        return self.js({'refreshing':self.server.store.running,'offline':self.server.store.offline},202)

def main(argv=None):
    parser=argparse.ArgumentParser(description='时序金融事件日历')
    parser.add_argument('--port',type=int,default=0)
    parser.add_argument('--ready-file',type=Path)
    parser.add_argument('--cache-dir',type=Path)
    parser.add_argument('--preview',action='store_true')
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--strictPort',action='store_true')
    parser.add_argument('--offline',action='store_true',help='只读已保存日程，不发网络请求')
    parser.add_argument('--reminder-worker',action='store_true',help='只处理本机已经设置的收藏提醒')
    args=parser.parse_args(argv)
    if not args.preview and args.host!='127.0.0.1': parser.error('桌面服务仅监听127.0.0.1')
    base=Path(os.environ.get('LOCALAPPDATA',Path.home()/'.local'/'share'))/'Willance'/'EventCalendarV1'/'data'
    if args.reminder_worker:
        run_reminder_worker(args.cache_dir or base,app_root=ROOT,personal_store=PersonalCalendarStore(args.cache_dir or base,app_root=ROOT))
        return
    verify_installed_baseline(ROOT)
    store=CalendarStore(args.cache_dir or base,args.offline)
    store.start_services()
    server=CalendarServer(('0.0.0.0' if args.preview else '127.0.0.1',args.port),store,args.preview)
    url='http://127.0.0.1:'+str(server.server_address[1])+'/'
    if args.ready_file: atomic_json(args.ready_file,{'url':url,'pid':os.getpid(),'version':VERSION})
    if os.name=='nt' and not args.preview:
        # The old launcher can still be in memory after applying an update.
        # Let the new, healthy service reconcile this app's own desktop identity.
        from desktop.launcher import start_branding_session
        start_branding_session(url,background=True,timeout=8.0)
    print('时序 '+url,flush=True)
    try: server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt: pass
    finally:
        store.closed=True;store._network_stop.set();store.quotes.close();store.earnings.close();store.options.close();store.macro.close();store.economic.close();server.server_close()
        if args.ready_file:
            try: args.ready_file.unlink(missing_ok=True)
            except OSError: pass

if __name__=='__main__': main()
